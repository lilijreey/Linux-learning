/**
 * @file     CIdcMatcher.h
 *           
 *
 * 进行IDC级的匹配
 * @author   lili <lilijreey@gmail.com>
 * @date     07/01/2018 07:51:47 PM
 *
 */

//Link


//IdcMatcher
//LocalMatcher

//IdcMatchedInfoReceiver// 发送本机matche info 到对应的IDC 节点
//IdcMatchedInfoSender //接受上游IDC节点返回的匹配信息

//HttpInfoSender
//HttpInfoReceiver

//void HandlePkg()

IdcMatchInfo* info = GetMatchInfo();

IdcMatchInfo *other = table.getMatcher(info);
if (other == nullptr)
{
  //not find matched
  return ;
}

table.erase(other);

if (info->GetIp() == other->GetIp())
{
  //same ip, matcher by local mather
  return;
}


SendMatchedInfoToReqNode(info, other);
{
  auto fd = info->getFd();

  auto it = conns.find(it);
  if (it == conns.end())
  {
    LOG_DBG("");
    //连接已断, TODO 记录这种情况
    return
  }

  return it->second->SendPkg(PackageInfo(other)))

}


//NetBuff
//PkgBuff

bool SendPkg( const char *data, size_t dataLen)
{
  //if ()
  buf= getSendBuf();
  buf.append(data, dataLen);

  //if (send)
  
  //以及发送还是缓存??
  //Conn.Flush
  //if (NowMsec > )

  if (-1 == NetSend(buf.GetData(), buf.GetDataLen()))
  {
    LOG_ERR("send data fd faild %d, close it", fd, ErrnoStr);
    return false;
  }
}


virtual bool OnAcceptSuccessed(CEpoll *epoll, int fd, sockaddr_in addr, socklen_t addrlen) 
{
  if (conns.count(fd))
  {
    LOG_ERR("fd %d already in conns, not shoud occus this, close it");
    return false;
  }

  auto conn = new DownstreamConn(fd);
  epoll->AddReadFd(fd, conn->GetEvHandler());
  conns[fd] = conn;
  return true;
}

virtual void OnBeforeCloseFd(CEpoll epoll, int fd)
{
  LOG_INFO("downstream %d will be closed", fd);
  auto it = conns.find(fd);
  if (it == conns.end())
    return;

  delete it->second; //upstreamConn
  conns.earse(it);
}

virtual bool OnEpollIn(CEpoll *epoll, int fd) 
{
  //1. read
  //2. unpack
  //3. dispatchPack
  
  Buff buf;
  int ret = buf.read(fd));
  if (ret == 0)
  {
    LOG_INFO("conn %d close by peer, it will be close\n", fd);
    goto error;
  }

  if (ret == -1)
  {
    LOG_INFO("conn %d has a error %d, will by close\n", fd, ErrnoStr);
    goto error;
  }

  //UnPkg
  while (hasAnCompletePkg(buf))
  {
    Pkg *pkg = getPkg(buf);
    if (not pkg->isAiled())
    {
      LOG_ERR("fd %d get a unvalied pkg close it");
      goto error;
    }

    //todo try is better?
    if (not DispatchPkg(pkg))
    {
      goto error;
    }
  }
  
  return true;

  //if (NetRecv(fd, buf, buf.WriteableLen()))

error:
    freeBuf();
    return false;
}

