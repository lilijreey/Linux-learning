
#include <stdio.h>
#include <assert.h>
#include "NetIO.h"


bool sendData(CEpoll *epoll, int fd, int events)
{
    if (CEpoll::IsErrEv(events))
    {
        int err = GetSocketErr(fd);
        printf("fd %d %s\n", fd, strerror(err));
        //TODO 重连
        
        return false;
    }

    printf("fd %d send \n", fd);
    if (-1 == send(fd, "hello\n", 6, MSG_NOSIGNAL))
    {
        printf("send fd %d failed %s\n", fd, ErrnoStr);
        return false;
    }

    return true;
}

#define CLOSE_FD  0

class Upstream : public ConnectHandler, public EpollHandler 
{
 public:
  Upstream(const std::string &ip, uint16_t port)
      :m_ip(ip), m_port(port)
  {
  }



  std::string m_ip;
  uint16_t m_port;


};

//template <class T>
//CEpoll::EvHandler EvHandlerMemFn(bool(T::*memFn)(CEpoll *, int, int), T *objPtr)
//{
//  return
//  std::bind(memFn, objPtr, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3);
//}

//template <class T, class SubT>
//CEpoll::EvHandler EvHandlerMemFn(bool(T::*memFn)(CEpoll *, int, int), SubT *objPtr)
//{
//  return
//  std::bind(memFn, objPtr, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3);
//}


int main(int argc, char *argv[])
{
    CEpoll epoll(23);

    
#if 0
    int fd = epoll.TcpNonblockConnect("127.0.0.1", 3345, 
                                 [](CEpoll *epoll, int fd, int events){
                                 if (CEpoll::IsErrEv(events))
                                 {
                                 int err = GetSocketErr(fd);
                                 printf("connect failed %s\n", strerror(err));
                                 return false;
                                 }
                                 printf("connect 127.0.0.1:3345 succcessed\n");
                                 //assert(not epoll->IsExistFd(fd));
                                 if (-1 == send(fd, "12345\n", 6, MSG_NOSIGNAL))
                                 {
                                 printf("send fd %d failedxx %s\n", fd, ErrnoStr);
                                 return false;
                                 }
                                 assert(epoll->ModEvRead(fd, [](CEpoll *epoll, int fd, int event){
                                                         printf("fd %d has event\n",fd);
                                                         return false;
                                                         }));
                                 printf("fd:%d add read ev ok\n", fd);
                                 return true;
                                 //epoll->SetEvHandler(fd, )
                                 });

#endif
    //EpollHandler epollHandler();
    Upstream upstream("127.0.0.1", 3345);

    //xx(&upstream, epoll, 1,1);
    int fd = epoll.TcpNonblockConnect(upstream.m_ip, upstream.m_port, upstream.ConnectHandler::GetEvHandler());

    printf("\n");
    if (fd != -1)
    {
        printf("connect fd %d ok\n", fd);
    }

    //int fd = TcpSocket("127.0.0.1", 3345);
    //assert(SetSocketNonbockable(fd));


    while (true)
    {
        if (not epoll.Wait(-1))
        {
            printf("epoll wait error exit");
            break;
        }
        sleep(1);
        printf("\nepoll agin\n");


    }



    
    return 0;
}
