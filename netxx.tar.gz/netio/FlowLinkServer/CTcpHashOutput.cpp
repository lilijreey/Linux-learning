/*
 * CTcpHashOutput.cpp
 *
 *  Created on: 2017��4��14��
 *      Author: stanzeng
 */

#include "CTcpHashOutput.h"

extern uint64_t g_ullSystemTime;

CTcpHashOutput::CTcpHashOutput(CFlowLinkSvrApp *pOwner)
{
	m_pOwner = pOwner;
    m_ulRecvPos = 0;
    m_ulRecvLen = 0;
	m_ulCurDataPos = 0;
	m_ulCurDataLen = 0;
	m_ullLastSendTime = 0;
}

CTcpHashOutput::~CTcpHashOutput()
{
	// TODO Auto-generated destructor stub
	LOG_INFO("free hash output obj");
}

bool CTcpHashOutput::CheckFlush()
{
	if(g_ullSystemTime - m_ullLastSendTime > 100000 || m_ulCurDataLen >= NOTIFY_SEND_BUFFER)
	{
		Flush();
	}
	return true;
}


void CTcpHashOutput::FixMemory()
{
    static uint8_t s_aucTempBuf[RECV_BUFFER_SIZE];
    
    if (m_ulRecvLen + m_ulRecvPos <= RECV_BUFFER_SIZE)
    {
        if (m_ulRecvPos > 0)
        {
            memmove(m_aucRecvBuffer, m_aucRecvBuffer + m_ulRecvPos, m_ulRecvLen);
            m_ulRecvPos = 0;
        }
    }
    else
    {
        uint32_t ulTailLen = RECV_BUFFER_SIZE - m_ulRecvPos;
        uint32_t ulHeadLen = m_ulRecvLen - ulTailLen;
        
        memcpy(s_aucTempBuf, m_aucRecvBuffer + m_ulRecvPos, ulTailLen);
        memmove(m_aucRecvBuffer + ulTailLen, m_aucRecvBuffer, ulHeadLen);
        memcpy(m_aucRecvBuffer, s_aucTempBuf, ulTailLen);
        m_ulRecvPos = 0;
    }
}


bool CTcpHashOutput::Flush()
{
	//LOG_INFO("flush data, system time = %lu, last flush = %lu", g_ullSystemTime, m_ullLastSendTime);
	if(m_ulCurDataLen == 0)
	{
		return true;
	}
	
	m_ullLastSendTime = g_ullSystemTime;
	if(!CanSend())
	{
		LOG_ERR("can not send, drop");
		m_ulCurDataPos = 0;
		m_ulCurDataLen = 0;
		return false;
	}
	
	if(!SendData((uint8_t *)m_szSendBuffer + m_ulCurDataPos, m_ulCurDataLen))
	{
		LOG_ERR("flush data failed, fd = %d", GetFd());
		m_ulCurDataPos = 0;
		m_ulCurDataLen = 0;
		return false;
	}
	
	m_ulCurDataPos = 0;
	m_ulCurDataLen = 0;
	return true;
}

bool CTcpHashOutput::ParseHashRsp()
{
	while(m_ulRecvLen >= sizeof(tLinkReply))
	{
		if(sizeof(tLinkReply) + m_ulRecvPos >= RECV_BUFFER_SIZE)
		{
			FixMemory();
		}
		
		tLinkReply *pHead = (tLinkReply *)(m_aucRecvBuffer + m_ulRecvPos);
		if(pHead->ulLen > m_ulRecvLen)
		{
			return true;
		}
	
		if(pHead->ulLen + m_ulRecvPos >= RECV_BUFFER_SIZE)
		{
			FixMemory();
		}
		
		pHead = (tLinkReply *)(m_aucRecvBuffer + m_ulRecvPos);
		ASSERT_RET(pHead->ulStx == LINK_REPLY_STX, false);
				
		//m_pOwner->NotityHashInput(pHead->astPeer->ulDstIP, pHead->astPeer->usPort, pHead->astPeer->astHash, pHead->astPeer->ulCount);
		
		
		int iPeerInfoLen = pHead->ulLen - sizeof(tLinkReply), iDealLen = 0;
		while(iDealLen < iPeerInfoLen)
		{
			tPeerInfo *pstData = (tPeerInfo *)((char *)pHead->astPeer + iDealLen);
			//LOG_INFO("peer info len = %d, iDealLen = %d, count = %u", iPeerInfoLen, iDealLen, pstData->ulCount);
			
//			if(pstData->ulCount == 0)
//			{
//				static char szTmp[10240];
//				int iTmpLen = 0;
//				for(int i = 0 ; i < pHead->ulLen; ++i)
//				{
//					iTmpLen += snprintf(szTmp + iTmpLen, sizeof szTmp - iTmpLen, "%02x", (m_aucRecvBuffer + m_ulRecvPos)[i] );
//				}
//				LOG_INFO("err pkg, hex = %s", szTmp);
//				LOG_INFO("peer info len = %d, iDealLen = %d, count = %u", iPeerInfoLen, iDealLen, pstData->ulCount);
//			}
			
			
			m_pOwner->NotityHashInput(pstData->ulDstIP, pstData->usPort, pstData->astHash, pstData->ulCount);
			iDealLen += sizeof(tPeerInfo) + sizeof(tHashType) * pstData->ulCount;			
		}
		
		m_ulRecvLen -= pHead->ulLen;
		m_ulRecvPos += pHead->ulLen;
	}

	return true;
}

bool CTcpHashOutput::HandleRead()
{
    if (m_ulRecvLen < RECV_BUFFER_SIZE)
    {
        int iRet, iRecvLen;
        if (m_ulRecvPos + m_ulRecvLen < RECV_BUFFER_SIZE)    // β��δ��, �յ�β��
        {
            iRet = recv(GetCurrentFd(), m_aucRecvBuffer + m_ulRecvLen + m_ulRecvPos, RECV_BUFFER_SIZE - (m_ulRecvLen + m_ulRecvPos), 0);
            iRecvLen = RECV_BUFFER_SIZE - (m_ulRecvLen + m_ulRecvPos);
        }
        else    // �յ�ͷ��
        {
            iRet = recv(GetCurrentFd(), m_aucRecvBuffer + m_ulRecvLen + m_ulRecvPos - RECV_BUFFER_SIZE, RECV_BUFFER_SIZE - m_ulRecvLen, 0);
            iRecvLen = RECV_BUFFER_SIZE - m_ulRecvLen;
        }
        
        if (iRet < 0)
        {
            if (errno == EAGAIN)
            {
                return true;
            }
            LOG_ERR("recv err:%d", errno);
            return false;
        }

        if (iRet == 0)
        {
        	LOG_INFO("recv fin pkg, notify to close, recv len = %d", iRecvLen);
            return false;
        }

        m_ulRecvLen += iRet;
    }
	
    ASSERT_RET(ParseHashRsp(), false);
    
    
	return true;
}



bool CTcpHashOutput::AppendData(void *pData, uint32_t ulLen)
{
	
	if(m_ulCurDataPos + m_ulCurDataLen + ulLen >= MAX_SEND_BUFFER)
	{
		Flush();	
	}
	
	memcpy(m_szSendBuffer + m_ulCurDataPos + m_ulCurDataLen , pData, ulLen);
	m_ulCurDataLen += ulLen;
	CheckFlush();
	
	return true;
}