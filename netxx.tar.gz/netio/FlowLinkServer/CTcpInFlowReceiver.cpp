/*
 * CTcpInFlowReceiver.cpp
 *
 *  Created on: 2017��4��18��
 *      Author: stanzeng
 */


#include "CTcpInFlowReceiver.h"
#include <netinet/tcp.h>

uint32_t CTcpInFlowReceiver::s_uConnCnt = 0; //��ǰ��������
uint32_t CTcpInFlowReceiver::s_uRecvBytes = 0;
//uint32_t CTcpInFlowReceiver::s_uSendBytes = 0;

CTcpInFlowReceiver::CTcpInFlowReceiver(CFlowLinkSvrApp *pOwner)
{
	// TODO Auto-generated constructor stub
	m_iFd = -1;
	m_pOwner = pOwner;
	m_bInitStaticData = false;
    m_ulCurrentPos = 0;
    m_ulDataLen = 0;
    m_ullTimestamp = 0;
    
    m_ulUncompressPos = 0;
    m_ulUncompressDataLen = 0;
}

CTcpInFlowReceiver::~CTcpInFlowReceiver()
{
	// TODO Auto-generated destructor stub
	
    if (m_iFd >= 0)
    {
        DelEvent();
        close(m_iFd);
        m_iFd = -1;   
        --s_uConnCnt;
    }
}


bool CTcpInFlowReceiver::Init(int iFd)
{
    m_iFd = iFd;
   	int iFlag = 1;
   	setsockopt(iFd, IPPROTO_TCP, TCP_NODELAY, (void *)&iFlag, sizeof(iFlag));
    ASSERT_RET(AddEvent(EPOLLIN), false);
    ++s_uConnCnt;
    return true;
}

void CTcpInFlowReceiver::FixupMemory()
{    
    static uint8_t s_aucTempBuf[DATA_BUFFER_SIZE];
    
    if (m_ulDataLen + m_ulCurrentPos <= DATA_BUFFER_SIZE)
    {
        if (m_ulCurrentPos > 0)
        {
            memmove(m_aucBuffer, m_aucBuffer + m_ulCurrentPos, m_ulDataLen);
            m_ulCurrentPos = 0;
        }
    }
    else
    {
        uint32_t ulTailLen = DATA_BUFFER_SIZE - m_ulCurrentPos;
        uint32_t ulHeadLen = m_ulDataLen - ulTailLen;
        
        memcpy(s_aucTempBuf, m_aucBuffer + m_ulCurrentPos, ulTailLen);
        memmove(m_aucBuffer + ulTailLen, m_aucBuffer, ulHeadLen);
        memcpy(m_aucBuffer, s_aucTempBuf, ulTailLen);
        m_ulCurrentPos = 0;
    }
}	


void CTcpInFlowReceiver::FixupUncompressMemory()
{    
    static uint8_t s_aucUncompressTempBuf[DATA_BUFFER_SIZE];
    
    if (m_ulUncompressDataLen + m_ulUncompressPos <= DATA_BUFFER_SIZE)
    {
        if (m_ulUncompressPos > 0)
        {
            memmove(m_aucUncompressBuffer, m_aucUncompressBuffer + m_ulUncompressPos, m_ulUncompressDataLen);
            m_ulUncompressPos = 0;
        }
    }
    else
    {
        uint32_t ulTailLen = DATA_BUFFER_SIZE - m_ulUncompressPos;
        uint32_t ulHeadLen = m_ulUncompressDataLen - ulTailLen;
        
        memcpy(s_aucUncompressTempBuf, m_aucUncompressBuffer + m_ulUncompressPos, ulTailLen);
        memmove(m_aucUncompressBuffer + ulTailLen, m_aucUncompressBuffer, ulHeadLen);
        memcpy(m_aucUncompressBuffer, s_aucUncompressTempBuf, ulTailLen);
        m_ulUncompressPos = 0;
    }
}	

/*
bool CTcpInFlowReceiver::ParseData()
{
	
	
	
    while (m_ulDataLen >= sizeof (tStaticDataHeader))
    {
        if (m_ulCurrentPos + sizeof (tStaticDataHeader) > DATA_BUFFER_SIZE )
        {
            FixupMemory();
        }
        
        ASSERT_RET(m_ulCurrentPos + sizeof (tStaticDataHeader) <= DATA_BUFFER_SIZE, false);        

        if(((uint16_t)(m_aucBuffer + m_ulCurrentPos)[0] & 0xFF ) == STATIC_DATA_STX)
        {
        	tStaticDataHeader *pstHead = (tStaticDataHeader *)(m_aucBuffer + m_ulCurrentPos);
        	uint32_t ulPkgLen = pstHead->ulDataLen;
        	if(ulPkgLen > DATA_BUFFER_SIZE)
        	{
        		LOG_ERR("Pkg too large:%u", pstHead->ulDataLen);
        		return false;
        	}

        	//��������
        	if(m_ulDataLen >= ulPkgLen)
        	{
        		//���δ����İ�����
                if (m_ulCurrentPos + ulPkgLen > DATA_BUFFER_SIZE )
                {
                    FixupMemory();		//����fixupmemory��ı�pstHeadָ������ݣ�ulPkgLen�������Ѿ�������������Ҫ�ں�������õ�pstHead
                }
                ASSERT_RET(m_ulCurrentPos + ulPkgLen <= DATA_BUFFER_SIZE, false);
        		
                
        		if(unlikely(!m_bInitStaticData))
        		{
        			//ASSERT_RET(m_stInitStaticData.InitFieldFromArray((const char *)(m_aucBuffer + m_ulCurrentPos), ulPkgLen));
        			if(m_stCurrentData.InitFieldFromArray((const char *)(m_aucBuffer + m_ulCurrentPos), ulPkgLen) < 0)
        			{
        				LOG_ERR("init field from array fail.");
        				return false;
        			}        			
        			LOG_INFO("init static data suc");
        			m_bInitStaticData = true;
        		}
                
        		int iRet = m_stCurrentData.ParseFromArray((const char *)(m_aucBuffer + m_ulCurrentPos), ulPkgLen);
        		if(iRet < 0)
        		{
        			LOG_ERR("ParseFromArray fail");
        			return false;
        		}
        		
                m_ulCurrentPos += ulPkgLen;
                m_ulDataLen -= ulPkgLen;
                
                m_pOwner->NotifyWriteLinkPkg(m_stCurrentData);
        	}
        	else
        	{
        		break;
        	}           
        }        
        else
        {
        	LOG_ERR("Err stx: hex = %02x", (uint8_t)((m_aucBuffer + m_ulCurrentPos)[0]));
        	static char szTmp[1024] = {0};
        	for(int i = 0 ; i < (int)m_ulDataLen && i < 100; ++i)
        	{
        		snprintf(szTmp + 2 * i, sizeof(szTmp) - 2 * i , "%02x" , (uint8_t)((m_aucBuffer + m_ulCurrentPos)[i]));
        	}
        	LOG_INFO("next hex = %s", szTmp);
        	
        	return false;
        }
        //LOG_INFO("parse one data");
    }	
    return true;
}
*/




bool CTcpInFlowReceiver::ParseData()
{
	
	while(m_ulDataLen >= sizeof(tFlowLinkDataHeader))
	{
        if (m_ulCurrentPos + sizeof (tFlowLinkDataHeader) >= DATA_BUFFER_SIZE )
        {
            FixupMemory();
        }
        
        ASSERT_RET(m_ulCurrentPos + sizeof (tFlowLinkDataHeader) <= DATA_BUFFER_SIZE, false);   
        
        if(  *(uint16_t*)((char *)m_aucBuffer + m_ulCurrentPos) == FLOW_LINK_STATICDATA_STX)
        {
        	tFlowLinkDataHeader *pstHead = (tFlowLinkDataHeader *)(m_aucBuffer + m_ulCurrentPos);
        	
        	uint32_t ulPkgLen = pstHead->ulLen;	        
        	
        	if(ulPkgLen > DATA_BUFFER_SIZE)
        	{
        		LOG_ERR("Pkg too large:%u", pstHead->ulLen);
        		return false;
        	}
        	
        	if(m_ulDataLen >= ulPkgLen)
        	{
                if (m_ulCurrentPos + ulPkgLen >= DATA_BUFFER_SIZE )
                {
                    FixupMemory();		//����fixupmemory��ı�pstHeadָ������ݣ�ulPkgLen�������Ѿ�������������Ҫ�ں�������õ�pstHead
                    pstHead = (tFlowLinkDataHeader *)(m_aucBuffer + m_ulCurrentPos);
                }
                ASSERT_RET(m_ulCurrentPos + ulPkgLen <= DATA_BUFFER_SIZE, false);
                
                
                //uncompress 
                
                size_t ulNextUncomLen = 0;
                
                if(pstHead->ucCompressBit == TYPE_SNAPPY)
                {                	
                	ASSERT_RET(snappy::GetUncompressedLength((const char *)m_aucBuffer + m_ulCurrentPos + pstHead->ucHeaderLen,
                			pstHead->ulLen - pstHead->ucHeaderLen, (size_t *)&ulNextUncomLen), false);
                }
                else
                {
                	ulNextUncomLen = pstHead->ulLen - pstHead->ucHeaderLen;
                }
                	
                //LOG_INFO("dataUncompress before = %u, after = %u", ulPkgLen, ulNextUncomLen);
				if(ulNextUncomLen > DATA_UNCOMPRESS_SIZE - m_ulUncompressDataLen)
				{
					LOG_ERR("too large after uncompress, len = %d, remain = %d", ulNextUncomLen , DATA_UNCOMPRESS_SIZE - m_ulUncompressDataLen);
					return false;
				}
                	
				
				if(m_ulUncompressPos + m_ulUncompressDataLen + ulNextUncomLen >= DATA_UNCOMPRESS_SIZE )
				{
					FixupUncompressMemory();
				}
				
				if(pstHead->ucCompressBit == TYPE_SNAPPY)
				{
					snappy::RawUncompress((const char *)m_aucBuffer + m_ulCurrentPos + pstHead->ucHeaderLen , 
							pstHead->ulLen - pstHead->ucHeaderLen, (char *)m_aucUncompressBuffer + m_ulUncompressPos + m_ulUncompressDataLen);
				}
				else
				{
					memcpy(m_aucUncompressBuffer + m_ulUncompressPos + m_ulUncompressDataLen, m_aucBuffer + m_ulCurrentPos + pstHead->ucHeaderLen , ulNextUncomLen);
				}
				
                
                m_ulDataLen -= ulPkgLen;
                m_ulCurrentPos += ulPkgLen;
                
                m_ulUncompressDataLen += ulNextUncomLen;
                
                
                //handlestatic data
                
                while (m_ulUncompressDataLen >= sizeof (tStaticDataHeader))
                {
                    if (m_ulUncompressPos + sizeof (tStaticDataHeader) >= DATA_UNCOMPRESS_SIZE )
                    {
                        FixupUncompressMemory();
                    }
                    
                    ASSERT_RET(m_ulUncompressPos + sizeof (tStaticDataHeader) <= DATA_UNCOMPRESS_SIZE, false);        

                    if(((uint16_t)(m_aucUncompressBuffer + m_ulUncompressPos)[0] & 0xFF ) == STATIC_DATA_STX)
                    {
                    	tStaticDataHeader *pstStaticDataHead = (tStaticDataHeader *)(m_aucUncompressBuffer + m_ulUncompressPos);
                    	uint32_t ulStaticDataPkgLen = pstStaticDataHead->ulDataLen;
                    	if(ulStaticDataPkgLen > DATA_UNCOMPRESS_SIZE)
                    	{
                    		LOG_ERR("Pkg too large:%u", pstStaticDataHead->ulDataLen);
                    		return false;
                    	}

                    	//��������
                    	if(m_ulUncompressDataLen >= ulStaticDataPkgLen)
                    	{
                    		//���δ����İ�����
                            if (m_ulUncompressPos + ulStaticDataPkgLen >= DATA_UNCOMPRESS_SIZE )
                            {
                            	FixupUncompressMemory();		//����FixupUncompressMemory��ı�pstStaticDataHeadָ������ݣ�ulStaticDataPkgLen�������Ѿ�������������Ҫ�ں�������õ�pstStaticDataHead
                            }
                            ASSERT_RET(m_ulUncompressPos + ulStaticDataPkgLen <= DATA_UNCOMPRESS_SIZE, false);
                    		
                            
                    		if(unlikely(!m_bInitStaticData))
                    		{
                    			//ASSERT_RET(m_stInitStaticData.InitFieldFromArray((const char *)(m_aucUncompressBuffer + m_ulUncompressPos), ulStaticDataPkgLen));
                    			if(m_stCurrentData.InitFieldFromArray((const char *)(m_aucUncompressBuffer + m_ulUncompressPos), ulStaticDataPkgLen) < 0)
                    			{
                    				LOG_ERR("init field from array fail.");
                    				return false;
                    			}        			
                    			LOG_INFO("init static data suc");
                    			m_bInitStaticData = true;
                    		}
                            
                    		int iRet = m_stCurrentData.ParseFromArray((const char *)(m_aucUncompressBuffer + m_ulUncompressPos), ulStaticDataPkgLen);
                    		if(iRet < 0)
                    		{
                    			LOG_ERR("ParseFromArray fail");
                    			return false;
                    		}
                    		
                            m_ulUncompressPos += ulStaticDataPkgLen;
                            m_ulUncompressDataLen -= ulStaticDataPkgLen;
                            
                            m_pOwner->NotifyWriteLinkPkg(m_stCurrentData);
                    	}
                    	else
                    	{
                    		break;
                    	}           
                    }        
                    else
                    {
                    	LOG_ERR("Err stx: hex = %02x", (uint8_t)((m_aucUncompressBuffer + m_ulUncompressPos)[0]));
                    	static char szTmp[1024] = {0};
                    	for(int i = 0 ; i < (int)m_ulUncompressDataLen && i < 100; ++i)
                    	{
                    		snprintf(szTmp + 2 * i, sizeof(szTmp) - 2 * i , "%02x" , (uint8_t)((m_aucUncompressBuffer + m_ulUncompressPos)[i]));
                    	}
                    	LOG_INFO("next hex = %s", szTmp);
                    	
                    	return false;
                    }
                    //LOG_INFO("parse one data");
                }	
               
        	}
        	else
        	{
        		break;
        	}

        }
        else
        {											   
        	LOG_ERR("Err stx: hex = %d, require = %d", *(uint16_t*)((char *)m_aucBuffer + m_ulCurrentPos), FLOW_LINK_STATICDATA_STX);
        	static char szTmp[1024] = {0};
        	for(int i = 0 ; i < (int)m_ulDataLen && i < 100; ++i)
        	{
        		snprintf(szTmp + 2 * i, sizeof(szTmp) - 2 * i , "%02x" , (uint8_t)((m_aucBuffer + m_ulCurrentPos)[i]));
        	}
        	LOG_INFO("next hex = %s", szTmp);
        	
        	return false;
        }
        
	}
	

    return true;
}




bool CTcpInFlowReceiver::HandleRead()
{
	int iRet;
    if (m_ulDataLen < DATA_BUFFER_SIZE)
    {
        if (m_ulCurrentPos + m_ulDataLen < DATA_BUFFER_SIZE)    // β��δ��, �յ�β��
        {
            iRet = recv(m_iFd, m_aucBuffer + m_ulDataLen + m_ulCurrentPos, DATA_BUFFER_SIZE - (m_ulDataLen + m_ulCurrentPos), 0);
        }
        else    // �յ�ͷ��
        {
            iRet = recv(m_iFd, m_aucBuffer + m_ulDataLen + m_ulCurrentPos - DATA_BUFFER_SIZE, DATA_BUFFER_SIZE - m_ulDataLen, 0);
        }
        
        if (iRet < 0)
        {
            if (errno == EAGAIN)
            {
                return true;
            }
            LOG_ERR("recv err:%d", errno);
            return false;
        }

        if (iRet == 0)
        {
        	LOG_INFO("recv fin pkg, notify to close");
            return false;
        }

        m_ulDataLen += iRet;
        s_uRecvBytes += iRet;
    }
	
    //LOG_INFO("handle read, fd = %d, read len = %d", m_iFd, iRet);
    ASSERT_RET(ParseData(), false);
    
    
	return true;
}

void CTcpInFlowReceiver::HandleClose()
{
	LOG_WARN("recv close event, fd = %d", m_iFd);
	delete this;
}

