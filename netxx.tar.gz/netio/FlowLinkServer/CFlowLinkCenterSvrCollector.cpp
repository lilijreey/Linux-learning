/*
 * CFlowLinkCenterSvrCollector.cpp
 *
 *  Created on: 2017��4��21��
 *      Author: stanzeng
 */

#include "CFlowLinkCenterSvrCollector.h"
#include <algorithm>

const uint32_t CHECK_CENTER_SERVER_INTERVAL = 5 * 60;
const char *FLOW_LINK_PATH_PREFIX = "/argus/flow_link"; 
const uint32_t CHECK_UDPATE_INTERVAL = 30;

uint32_t g_ulLastPathNotifyTime;
extern uint32_t g_ulSystemTime32;

void static s_RegPath(CZookeeper *pObj, const char *szPath, emZkEvent ucEvent, const void *pData, int iDataLen)
{
	CFlowLinkCenterSvrCollector *pInfoCollectorObj = *(CFlowLinkCenterSvrCollector**)pData;
	Attr_API(ATTR_FLOW_LINK_ZKNODE_UPDATE, 1);
    LOG_INFO("watch notify");
    g_ulLastPathNotifyTime = g_ulSystemTime32;
}

CFlowLinkCenterSvrCollector::CFlowLinkCenterSvrCollector()
{
	// TODO Auto-generated constructor stub
	m_pZk = NULL;
	m_ulLastChcekTime = 0;
	m_iIDCID =0 ;
	m_bHasInTraffic = true;
	m_bHasOutTraffic = true;
}

CFlowLinkCenterSvrCollector::~CFlowLinkCenterSvrCollector()
{
	// TODO Auto-generated destructor stub
}



bool CFlowLinkCenterSvrCollector::Init(int iShmKey, CZookeeper *pZk, string sRegPath, int iIDCID)
{
	ASSERT_RET(m_stServerInfo.Init(iShmKey), false);
	ASSERT_RET(pZk, false);
	m_pZk = pZk;
	m_sRegPath = FixupPath(sRegPath + "/online"); // /argus/flow_link/groups/<ids>/online/<ip>=
	
	int iRet = -1;
	if((iRet = m_pZk->ExistsNode(m_sRegPath)))
	{
		LOG_ERR("get node = %s failed, iRet = %d", m_sRegPath.c_str(), iRet);
		return false;
	}
	
	CFlowLinkCenterSvrCollector *pObj = this;
	iRet = m_pZk->WatchChild(m_sRegPath, s_RegPath, &pObj, sizeof pObj);
	if(iRet != 0)
	{
		LOG_ERR("watch child failed, path = %s, iRet = %d", m_sRegPath.c_str(), iRet);
		return false;
	}
	
	m_iIDCID = iIDCID;
	return true;
}

bool CFlowLinkCenterSvrCollector::RefreshPath()
{
	m_vecCurIPList.clear();
	vector<string> vecIPList;
	vector<uint64_t> vecPortList;
	int iRet = m_pZk->GetChild(m_sRegPath, vecIPList);
	if(iRet != 0)
	{
		LOG_ERR("read child failed, path = %s, iRet = %d", m_sRegPath.c_str(), iRet);
		return false;
	}
	
    //sync /argus/flow_link/groups/<idc>/online/<ip> =listenPort1,listenPort2,...
	for(vector<string>::iterator Iter = vecIPList.begin(); Iter != vecIPList.end(); Iter++)
	{
		if((iRet = m_pZk->ReadUintList(m_sRegPath + "/" + *Iter, vecPortList)))
		{
			LOG_ERR("read port list failed, iRet = %d", iRet);
			continue;
		}	
		
		for(uint32_t i = 0 ; i < vecPortList.size(); ++i)
		{
			uint32_t ulIP = inet_network(Iter->c_str());
			m_vecCurIPList.push_back(pair<uint32_t, uint16_t>(ulIP, vecPortList[i]));
		}
	}
	
	sort(m_vecCurIPList.begin(), m_vecCurIPList.end());
	
    //check is changed
	bool bNeedUpdate = false;
	if(m_vecCurIPList.size() != m_vecPreIPList.size())
	{
		bNeedUpdate = true;
	}
	else
	{
		for(uint32_t i = 0 ; !bNeedUpdate && i < m_vecCurIPList.size(); ++i)
		{
			if(m_vecCurIPList[i].first != m_vecPreIPList[i].first || m_vecCurIPList[i].second != m_vecPreIPList[i].second)
			{
				bNeedUpdate = true;
			}
		}
	}
	
	if(bNeedUpdate)
	{
		LOG_INFO("update avail ip list , pre cnt = %d, cur cnt = %d", m_vecPreIPList.size(), m_vecCurIPList.size());
		m_vecPreIPList.assign(m_vecCurIPList.begin(), m_vecCurIPList.end());
		m_stServerInfo.SetAvailServer(m_vecCurIPList);
	}
	else
	{
		LOG_INFO("no need to update");
	}
	
	g_ulLastPathNotifyTime = 0;
 	return true;
}



bool CFlowLinkCenterSvrCollector::RefreshReceiverTrafficInfo()
{
	//string sPrefix = "/argus/conf/flowlink/";
	char szTmp[256];
	snprintf(szTmp, sizeof szTmp, "/argus/conf/flowlink/%d", m_iIDCID);

	string sValue;
	ASSERT_RET(m_pZk->ReadString(szTmp, sValue) == 0, false);
	if(!sValue.length())
	{
		LOG_INFO("path = %s has no value", szTmp);
		return false;
	}
	
	transform(sValue.begin(), sValue.end(), sValue.begin(), ::toupper);
	
	uint16_t usFlag = 0;
	
	if(sValue.find("IN") != string::npos)
	{
		m_bHasInTraffic = true;
		usFlag |= EM_TRAFFIC_IN;
	}
	else
	{
		m_bHasInTraffic = false;
	}
	
	if(sValue.find("OUT") != string::npos)
	{
		m_bHasOutTraffic = true;
		usFlag |= EM_TRAFFIC_OUT;
	}
	else
	{
		m_bHasOutTraffic = false;
	}
	
	m_stServerInfo.SetTrafficBit(usFlag);
	
	LOG_INFO("refresh traffic info, bit = %u", usFlag);
	return true;
}

bool CFlowLinkCenterSvrCollector::RefreshFilterCond()
{
	string sFilterFilePath = "/argus/conf/flowlink/filter_file";
	string sKeyHostPath = "/argus/conf/flowlink/key_host";
	
	string sFilterFile, sKeyHost;
	ASSERT_RET(m_pZk->ReadString(sFilterFilePath, sFilterFile) == 0, false);
	
	LOG_INFO("filter file = %s", sFilterFile.c_str());
	if(sFilterFile.empty())
	{
		LOG_INFO("no need to filter file");
	}

	//�յ�Ҳȥ���ã��п��ܴ���Ҫ���˸ĳɲ���Ҫ����
	m_stServerInfo.SetFilterFile(sFilterFile);
	
	ASSERT_RET(m_pZk->ReadString(sKeyHostPath, sKeyHost) == 0, false);
	
	LOG_INFO("key host = %s", sKeyHost.c_str());
	if(sKeyHost.empty())
	{
		LOG_INFO("no key host conf");
	}
	
	m_stServerInfo.SetKeyHost(sKeyHost);
	
	return true;
}


bool CFlowLinkCenterSvrCollector::RefreshOutputCompressBit()
{
	string sCompressBitPath = "/argus/conf/flowlink/compress";

	uint64_t ullCompressBit;
	ASSERT_RET(m_pZk->ReadUint(sCompressBitPath, ullCompressBit) == 0, false);
	
	LOG_INFO("compress conf = %d", ullCompressBit);
	//�յ�Ҳȥ����
	m_stServerInfo.SetCompressBit((uint8_t)ullCompressBit);

	
	return true;
}

bool CFlowLinkCenterSvrCollector::HandleLoop()
{
	if(g_ulSystemTime32 == m_ulLastChcekTime)
	{
		return true;
	}
	
	if((g_ulLastPathNotifyTime == 0 && g_ulSystemTime32 - m_ulLastChcekTime >= CHECK_CENTER_SERVER_INTERVAL) || 
       (g_ulLastPathNotifyTime != 0 && g_ulSystemTime32 - g_ulLastPathNotifyTime  >= CHECK_UDPATE_INTERVAL))
	{
		m_ulLastChcekTime = g_ulSystemTime32;
		RefreshPath();
		RefreshReceiverTrafficInfo();
		RefreshFilterCond();
		RefreshOutputCompressBit();
	}	
	
	return true;
}

