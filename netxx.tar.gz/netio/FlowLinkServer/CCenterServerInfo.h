/*
 * CCenterServerInfo.h
 *
 *  Created on: 2017��4��23��
 *      Author: stanzeng
 */

#ifndef TRUNK_DEV_FLOWLINKSERVER_CCENTERSERVERINFO_H_
#define TRUNK_DEV_FLOWLINKSERVER_CCENTERSERVERINFO_H_

#include "TrafficRelateSrvApp_comm.h"
#include <sys/ipc.h>
#include <sys/shm.h>
#include <vector>
using namespace std;


const uint32_t SHM_SIZE = 1024 * 1024 * 16;
const uint32_t SHM_MAGIC_STX = 0x9a4c3242;

class CCenterServerInfo
{
public:
	CCenterServerInfo();
	virtual ~CCenterServerInfo();
	
	int Init(int iShmKey);
	
	bool SetAvailServer(const vector<pair<uint32_t, uint16_t> > &vAvailServerList);
	bool GetAvailServer(vector< pair<uint32_t, uint16_t> > &vAvailServerList);
	
	uint32_t GetUpdateTime();
	bool SetTrafficBit(uint16_t usBit);
	uint16_t GetTrafficBit();
	
	bool SetFilterFile(const string &sFilterFile);
	bool GetFilterFile(string &sFilterFile);
	
	bool SetKeyHost(const string &sKeyHost);
	bool GetKeyHost(string &sKeyHost);
	
	bool SetCompressBit(const uint8_t ucCompressBit);
	bool GetCompressBit(uint8_t &ucCompressBit);
		
private:
	
#pragma pack(1)
	struct SServerInfo
	{
		uint32_t ulIP;
		uint16_t usPort;
	};
	
	struct SFlowLinkInfo
	{
		uint32_t ulStx;
		uint32_t ulLastUpdateTime;
		uint16_t usTrafficBit;
		uint8_t ucCompressBit;
		char 	 aszFilterFile[2 * 1024 * 1024];
		char 	 aszKeyHost[8 * 1024 * 1024];
		uint16_t usServerCount;
		SServerInfo astData[0];
	};
#pragma pack()
	
	SFlowLinkInfo* m_pInfo;
};

#endif /* TRUNK_DEV_FLOWLINKSERVER_CCENTERSERVERINFO_H_ */
