#ifndef _C_TCP_SENDER_
#define _C_TCP_SENDER_
#include "TrafficRelateSrvApp_comm.h"
#include "CEpollEventHandler.h"


class CTcpOutput;

class CTcpSender : public CEpollEventHandler
{
public:

    CTcpSender();
    ~CTcpSender();
    
    enum emStatus
    {
        TCP_CLOSED = 0,     // ���Ӵ��ڹر�״̬
        TCP_CONNECTING,     // ����������
        TCP_CONNECTED,          // ����, ���Է�������

    };

    enum 
    {
        SEND_BUFFER_SIZE = 1024 * 1024,
        MIN_BUFFER_SIZE = 256 * 1024,
    };
    
    bool Init(uint32_t ulMasterIP, uint16_t usMasterPort, uint32_t ulSlaveIP, uint16_t usSlavePort);

    bool SendData(const uint8_t *pPkg, uint32_t ulLen);

    bool CanSend();

    emStatus GetStatus() const {return m_ucStatus;}

    void HandleClose();

    uint32_t GetBufferSpace() const {ASSERT_RET(m_ulDataLen <= SEND_BUFFER_SIZE, 0); return SEND_BUFFER_SIZE - m_ulDataLen;}

    void HandleLoop();

    static uint32_t GetConnCnt() {return s_uConnCnt;}
    static uint32_t GetSendBytes() {return s_uSendBytes;}
	
    
protected:
    virtual bool HandleRead();

    virtual bool HandleWrite();

    int GetCurrentFd() {return m_iFd;}
    
    int GetFailTime() {return m_ulConnFailedTimes;};
    
    static uint32_t s_uConnCnt; //��ǰ��������
    static uint32_t s_uSendBytes;
    //static uint32_t s_uRecvBytes;

private:
    
    bool Reconnect();

    uint8_t         m_aucBuffer[SEND_BUFFER_SIZE];
    uint32_t        m_ulCurrentPos;
    uint32_t        m_ulDataLen;
    uint32_t        m_ulLastConnectTime;
    sockaddr_in     m_stMasterAddr;
    sockaddr_in     m_stSlaveAddr;
    sockaddr_in *   m_pstCurrAddr;
    
    int             m_iFd;
    emStatus        m_ucStatus;

    uint32_t        m_ulConnFailedTimes;
    
    
};

#endif

