/*
 * CCenterServerInfo.cpp
 *
 *  Created on: 2017��4��23��
 *      Author: stanzeng
 */

#include "CCenterServerInfo.h"

extern uint32_t g_ulSystemTime32;

CCenterServerInfo::CCenterServerInfo()
{
	m_pInfo = NULL;
}

CCenterServerInfo::~CCenterServerInfo()
{
}

int CCenterServerInfo::Init(int iShmKey)
{
	bool bCreate = false;
	
	int iShmID = shmget(iShmKey, SHM_SIZE, 0660); 
	if(iShmID == -1)
	{
		iShmID = shmget(iShmKey, SHM_SIZE, IPC_CREAT | 0660); 
		if(iShmID == -1)
		{
			LOG_ERR("shmget failed, errno = %d, err msg = %s", errno, strerror(errno));
			return false;
		}
		else
		{
			bCreate = true;
		}
	}
	
	m_pInfo = (SFlowLinkInfo*) shmat(iShmID, NULL, 0);
	if((void *)m_pInfo == (void *)-1)
	{
		LOG_ERR("shmat failed, errno = %d, err msg = %s", errno, strerror(errno));
		return false;
	}
	
	if(bCreate)
	{
		*(uint32_t *)m_pInfo = SHM_MAGIC_STX;
	}
	
	return true;
}

bool CCenterServerInfo::SetAvailServer(const vector<pair<uint32_t, uint16_t> > &vecAvailServerList)
{
	ASSERT_RET(m_pInfo && m_pInfo->ulStx == SHM_MAGIC_STX, false);
	SFlowLinkInfo *pInfo = (SFlowLinkInfo *) m_pInfo;
	
	ASSERT_RET(SHM_SIZE >= sizeof(SFlowLinkInfo) + sizeof(SServerInfo) * vecAvailServerList.size() , false);
	pInfo->usServerCount = vecAvailServerList.size();
	
	for(uint32_t i = 0 ; i < vecAvailServerList.size(); ++i)
	{
		pInfo->astData[i].ulIP = vecAvailServerList[i].first;
		pInfo->astData[i].usPort = vecAvailServerList[i].second;
	}
	pInfo->ulLastUpdateTime = g_ulSystemTime32;
	
	return true;
}

bool CCenterServerInfo::GetAvailServer(vector<pair<uint32_t, uint16_t> > &vecAvailServerList)
{
	ASSERT_RET(m_pInfo && m_pInfo->ulStx == SHM_MAGIC_STX, false);
	
	vecAvailServerList.clear();
	for(uint32_t i = 0 ; i < m_pInfo->usServerCount; ++i)
	{
		vecAvailServerList.push_back(pair<uint32_t, uint16_t>(m_pInfo->astData[i].ulIP, m_pInfo->astData[i].usPort));
	}
	
	return true;
}

uint32_t CCenterServerInfo::GetUpdateTime()
{
	ASSERT_RET(m_pInfo && m_pInfo->ulStx == SHM_MAGIC_STX, 0);
	return m_pInfo->ulLastUpdateTime;
}

bool CCenterServerInfo::SetTrafficBit(uint16_t usBit)
{
	ASSERT_RET(m_pInfo && m_pInfo->ulStx == SHM_MAGIC_STX, false);
	m_pInfo->usTrafficBit = usBit;
	
	SFlowLinkInfo *pInfo = (SFlowLinkInfo *) m_pInfo;
	pInfo->ulLastUpdateTime = g_ulSystemTime32;
	return true;
}

uint16_t CCenterServerInfo::GetTrafficBit()
{
	ASSERT_RET(m_pInfo && m_pInfo->ulStx == SHM_MAGIC_STX, 0);
	return m_pInfo->usTrafficBit;
}


bool CCenterServerInfo::SetFilterFile(const string &sFilterFile)
{
	ASSERT_RET(m_pInfo && m_pInfo->ulStx == SHM_MAGIC_STX, false);
	if(sFilterFile.empty())
	{
		m_pInfo->aszFilterFile[0] = '\0';
	}
		
	if(sFilterFile.length() > sizeof(m_pInfo->aszFilterFile) - 1)
	{
		LOG_ERR("Filter File size exceed, len = %d", sFilterFile.length());
        string::size_type iPos = sFilterFile.rfind(',', sizeof(m_pInfo->aszFilterFile) - 1);
		if(iPos != string::npos)
		{
			memcpy(m_pInfo->aszFilterFile, sFilterFile.c_str(), iPos);
			m_pInfo->aszFilterFile[iPos] = '\0';
		}
	}
	else
	{
		snprintf(m_pInfo->aszFilterFile, sizeof(m_pInfo->aszFilterFile), "%s", sFilterFile.c_str());
	}
	
	return true;
}


bool CCenterServerInfo::GetFilterFile(string &sFilterFile)
{
	ASSERT_RET(m_pInfo && m_pInfo->ulStx == SHM_MAGIC_STX, false);
	sFilterFile = m_pInfo->aszFilterFile;
	return true;
}


bool CCenterServerInfo::SetKeyHost(const string &sKeyHost)
{
	ASSERT_RET(m_pInfo && m_pInfo->ulStx == SHM_MAGIC_STX, false);
	if(sKeyHost.empty())
	{
		m_pInfo->aszKeyHost[0] = '\0';
	}
	
	if(sKeyHost.length() > sizeof(m_pInfo->aszKeyHost) - 1)
	{
		LOG_ERR("Filter File size exceed, len = %d", sKeyHost.length());
        string::size_type iPos = sKeyHost.rfind(',', sizeof(m_pInfo->aszKeyHost) -1);
		if(iPos != string::npos)
		{
			memcpy(m_pInfo->aszKeyHost, sKeyHost.c_str(), iPos);
			m_pInfo->aszKeyHost[iPos] = '\0';
            LOG_INFO("set host key by truncate len %lu", iPos);
		}
	}
	else
	{
		snprintf(m_pInfo->aszKeyHost, sizeof(m_pInfo->aszKeyHost), "%s", sKeyHost.c_str());
	}
	return true;
}
bool CCenterServerInfo::GetKeyHost(string &sKeyHost)
{
	ASSERT_RET(m_pInfo && m_pInfo->ulStx == SHM_MAGIC_STX, false);
	sKeyHost = m_pInfo->aszKeyHost;
	return true;
}
	
bool CCenterServerInfo::SetCompressBit(const uint8_t ucCompressBit)
{
	ASSERT_RET(m_pInfo && m_pInfo->ulStx == SHM_MAGIC_STX, false);
	m_pInfo->ucCompressBit = ucCompressBit;
	return true;
}
bool CCenterServerInfo::GetCompressBit(uint8_t &usCompressBit)
{
	ASSERT_RET(m_pInfo && m_pInfo->ulStx == SHM_MAGIC_STX, false);
	usCompressBit = m_pInfo->ucCompressBit;
	return true;
}
	
