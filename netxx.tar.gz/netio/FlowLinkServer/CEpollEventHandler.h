#ifndef _C_EPOLL_EVENT_HANDLER_H_
#define _C_EPOLL_EVENT_HANDLER_H_

#include <sys/epoll.h>

class CEpollEventHandler
{
public:
    CEpollEventHandler();
    virtual ~CEpollEventHandler();

    virtual bool HandleRead() { return true;};

    virtual bool HandleWrite() {return true;};

    virtual void HandleClose() = 0;

    int GetFd();
    
    int  GetEvent() const {return m_iEpollSet;}
    
protected:

    virtual int GetCurrentFd() = 0;

    bool AddEvent(int iEvent);

    bool DelEvent(int iEvent);

    bool DelEvent();

    

private:

    
    
    int         m_iEpollSet;
    int         m_iLastFd;
};

#endif

