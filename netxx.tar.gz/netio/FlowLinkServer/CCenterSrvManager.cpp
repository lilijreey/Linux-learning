#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <assert.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include "TrafficRelateSrvApp_comm.h"
#include "CommUtils.h"
#include "CSimpleApp.h"
#include "CFlowLinkCenterSvrCollector.h"
#include "SocketApiWrapper.h"
#include "CCenterServerInfo.h"

uint32_t g_ulSystemTime32;


class CCenterSrvManagerApp : public CSimpleApp
{
public:

    bool InitServer()
    {
        g_ulSystemTime32 = time(NULL);
        CConfig *pConfig = GetConfig();

        string sProxyConf = pConfig->GetVal("LOCAL_SERVER", "proxy_conf");
        if (sProxyConf.empty())
        {
            LOG_INFO("Do not use proxy.");
        }
        else if (access(sProxyConf.c_str(), F_OK | R_OK) != 0)
        {
            LOG_ERR("Can not access conf file:%s, err:%s.", sProxyConf.c_str(), strerror(errno));
        }
        else
        {
            LOG_INFO("Use proxy conf:%s", sProxyConf.c_str());
            if (!init_socket_api(sProxyConf.c_str()))
            {
                LOG_ERR("init_socket_api err:%s, conf:%s", get_last_error(), sProxyConf.c_str());
                return false;
            }
        }
        
        string sZkHost = pConfig->GetVal("ZOOKEEPER", "host");
        int iTimeout   = pConfig->GetIntVal("ZOOKEEPER", "timeout");
        
        if (!m_Zookeeper.Init(sZkHost, iTimeout))
        {
            LOG_ERR("Init zk (%s) err", sZkHost.c_str());
            return false;
        }

        int iShmKey = pConfig->GetIntVal("CENTER_SERVER_INFO", "shm_key");
        ASSERT_RET(iShmKey > 0, false);

        
//        vector<uint32_t> EthIPList;
//        EthIPList.push_back(GetLocalIP("eth0"));
//        EthIPList.push_back(GetLocalIP("eth1"));
        
        vector<uint32_t> EthIPList;
        
        CConfig MachineCfg;
        if(MachineCfg.LoadFile("/home/oicq/argus/argus.conf"))
        {
            string sLocalEth = MachineCfg.GetVal("COMMON", "local_eth");
            string sOutEth = MachineCfg.GetVal("COMMON", "out_eth");
            EthIPList.push_back(GetLocalIP(sLocalEth.c_str()));
            
            if(sOutEth != sLocalEth)
            {
            	EthIPList.push_back(GetLocalIP(sOutEth.c_str()));
            }
        }
        else
        {
            EthIPList.push_back(GetLocalIP("eth0"));
            EthIPList.push_back(GetLocalIP("eth1"));
        }
        
        
        
        string sRegPath;
        
        for(uint32_t i = 0; i < EthIPList.size(); ++i)
        {
        	if(EthIPList[i] == 0)
        	{
        		continue;
        	}
        	struct in_addr in;
        	in.s_addr = htonl(EthIPList[i]);
        	string sIP = inet_ntoa(in);
        	LOG_INFO("eth%d ip = %s", i, sIP.c_str());
     
        	if(m_Zookeeper.ReadString("/argus/flow_link/reg_path/" + sIP, sRegPath) == 0)
        	{
        		if(sRegPath.empty())
        		{
        			LOG_INFO("ip = %s gets no register path", sIP.c_str());
        		}
        		else
        		{
        			LOG_INFO("get reg path, ip = %s, path = %s", sIP.c_str(), sRegPath.c_str());
                    break;
        		}
        	}
        	else
        	{
        		LOG_ERR("read register path err");
        		return false;
        	}
        }
        
        if(sRegPath.empty())
        {
        	LOG_ERR("reg path empty");
        	return false;
        }
        
        CConfig AgentCfg;
        if(!AgentCfg.LoadFile("/home/oicq/argus/ArgusAgent/conf/ArgusAgent.conf"))
        {
        	LOG_ERR("no ArgusAgent.conf file");
        	return false;
        }
        
        int iIDCID = AgentCfg.GetIntVal("COMMON", "idc_id");
        if(iIDCID == 0)
        {
        	LOG_ERR("no idcid conf");
        	return false;
        }
        
                
        if (!m_Collector.Init(iShmKey, &m_Zookeeper, sRegPath, iIDCID))
        {
            LOG_ERR("Init Collector err.");
            return false;
        }

        
    	struct flock _flock;
    	_flock.l_type =  F_WRLCK;
    	_flock.l_whence = SEEK_SET;
    	_flock.l_len = 1;
    	_flock.l_start = 0;
    	
    	int iFileFd = open( "/home/oicq/argus/FlowLinkServer/conf/lock_manager", O_CREAT|O_RDWR, S_IRWXU|S_IRGRP|S_IWGRP|S_IRWXO);
        if (iFileFd < 0 )
        {
        	LOG_ERR("open file failed, errno = %d", errno);
            return false;
        }
    	
    	if(fcntl(iFileFd, F_SETLK, &_flock) != -1)
    	{
    		LOG_INFO("lock suc");
    	}
    	else 
    	{
    		LOG_ERR("lock failed");
    		return false;
    	}
        
        
        
        return true;
    }

    
    bool HandleLoop(void)
    {
        g_ulSystemTime32 = time(NULL);
        m_Zookeeper.WatchLoop();
        m_Collector.HandleLoop();
        return false;
    }

    void AdjustLogFile(string &sLogPath)
    {
        sLogPath += "_center_srv_manager";
    }

private:

    CZookeeper              m_Zookeeper;
    CFlowLinkCenterSvrCollector     m_Collector;
    //map<string, uint32_t> 	m_IPIdcIDSet;
};


int main(int argc, char *argv[])
{
	CCenterSrvManagerApp s_Manager;
    s_Manager.Run(argc, argv);
    return 0;
}


