/*
 * main.cpp
 *
 *  Created on: 2017��3��14��
 *      Author: stanzeng
 */




#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdint.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <string.h>
#include <stdarg.h>
#include <netdb.h>
#include <sys/socket.h> 
#include <iostream>

#include "svr_dev.h"
#include "CFlowLinkSvrApp.h"

using namespace std;

// ���������ģ��
CFlowLinkSvrApp g_FlowLinkSrvApp;


int main(int argc, char *argv[])
{
	g_FlowLinkSrvApp.Run(argc, argv);
    return 0;
}


