/*
 * CFlowLinkSvrApp.h
 *
 *  Created on: 2017��3��30��
 *      Author: stanzeng
 */

#ifndef TRUNK_DEV_TRAFFICRELATE_CTRAFFICRELATEHASHSVRAPP_H_
#define TRUNK_DEV_TRAFFICRELATE_CTRAFFICRELATEHASHSVRAPP_H_

#include "TrafficRelateSrvApp_comm.h"
#include "CStaticDataIOReader.h"
#include "CLruHashTable.h"
#include "CSimpleApp.h"
#include "CTcpHashOutput.h"
#include "CLocalOutput.h"
#include "CTcpOutput.h"


using namespace IO_NAMESPACE;
class CTcpHashOutput;
class CTcpOutput;
class CLocalOutput;


class CFlowLinkSvrApp : public CSimpleApp
{

public:
	enum emPkgDirection
	{
        //not change order
		DIR_IN = 0,
		DIR_OUT,
		DIR_END,
	};
	
public:
	bool InitServer();
	
	CFlowLinkSvrApp();
	~CFlowLinkSvrApp();
	uint64_t GetHashFromHttpReqStaticData(const CStaticData &stData);
	uint64_t GetHashFromFieldSelectorStaticData(const CStaticData &stData);
	
	
	uint64_t Hash(uint32_t ulIP1, uint16_t usPort1, uint32_t ulIP2, uint16_t usPort2, uint32_t ulSeq);
	bool InitReaderAndWrite();
	
	//��IO�ж�ȡhashֵ��Ӧ������staticdata�����ݺͳ���
	int GetHashDataInfoAndDelete(uint64_t ullHash, int& iDir, char *pBuf, uint32_t ulLen);
	
	
	bool NotityHashInput(uint32_t ulIP, uint16_t ulPort, tHashType *pHashData, uint32_t ulHashCount);
	bool NotifyWriteLinkPkg(CStaticData &stData);

	uint64_t GetDstAddr(uint64_t ullSrcAddr);
	

    bool AddEvent(int iFd, uint32_t ulEvent, CEpollEventHandler *pArg = NULL);
    
    bool ModEvent(int iFd, uint32_t ulEvent, CEpollEventHandler *pArg = NULL);
    
    bool DelEvent(int iFd);

    bool AddReadEvent(int iFd, CEpollEventHandler *pArg = NULL) {return AddEvent(iFd, EPOLLIN, pArg);}

    bool AddWriteEvent(int iFd, CEpollEventHandler *pArg = NULL) {return AddEvent(iFd, EPOLLOUT, pArg);}

    bool AddReadWriteEvent(int iFd, CEpollEventHandler *pArg = NULL) {return AddEvent(iFd, EPOLLIN | EPOLLOUT, pArg);}

    void AdjustLogFile(string &sLogPath)
    {
    	char szTmp[256];
    	snprintf(szTmp, sizeof szTmp, "_%d", m_ulPortStep);
        sLogPath = sLogPath + (m_emDirection == DIR_IN ? "_in" : "_out") + string(szTmp);
    }
   
    bool LockFile();

private:

    bool CheckTestRequest(const CStaticData &stData);
    
    void WriteAttrInfo();
    
	bool ProcessAccept();

	bool GetAliveServer();
	
	bool CheckAvailCenterServer();
	
	void CheckCompressConf();
	
	void CheckFilterCond();
	
	bool SetPriority();

    void ReportInfo() const;
	
	emPkgDirection m_emDirection;
	vector<CStaticDataIOReader*> m_HashFlowInIOReaderList ; //��������IO���б� //;m_HashIOReaderList;
	vector<CStaticDataIOReader*> m_HashFlowOutIOReaderList;
	
	
	vector<CLocalOutput *> 		m_LocalFlowInList;	
	vector<CLocalOutput *> 		m_LocalFlowOutList;	
	//vector<CStaticDataIOReader*> m_DataIOReaderList;	
	
	map<uint64_t, CTcpHashOutput *> m_AvailHashOutputList;
	map<uint64_t, CTcpHashOutput *> m_ToWakeUpHashOutputList;
	vector<CTcpHashOutput *> 		m_AliveHashSeqList;
	
	
	
	uint32_t m_ulIOTotalCount;
	uint32_t m_ulProcessCnt;
	SHashData	m_stHashData;
	
	struct tHashPack m_stHashPack;
	
	map<uint64_t, CTcpOutput*> m_TcpFlowOutput;
	

	
	
	uint32_t					m_ulLocalOutputCount;
	CStaticData					m_FlowLinkData;			//��Ϻ�İ�

	vector<uint32_t>			m_InFlowNeedFieldList;
	vector<uint32_t>			m_OutFlowNeedFieldList;
	CCenterServerInfo			m_stCenterServerInfo;
	uint32_t					m_ulLastCheckConfUpdateTime; //���FlowLinkCenter,�����ļ���׺�����������Ƿ��и���ʱ��
	uint32_t					m_ulLastUpdateAvailSrvTime;						
	
	
    int                 m_iListenFd;
    int                 m_iEpollFd;
    int                 m_iMaxFds;
    epoll_event *       m_astEvents;
    uint16_t			m_usBindPort;
    map<uint64_t, uint64_t> 	m_DstAddrList;
	
    uint32_t m_ulLastCheckAliveTime;
    string				m_sLocalIP;
    uint32_t 			m_ulLastTimestampWritten;
    uint32_t 			m_ulLastWriteLogTime;
    
    uint64_t			m_ullLastCheckFlushTime;
    int 				m_iLockFileFd;
    
    uint64_t			m_ullInHttpReqRead;
    uint64_t			m_ullInHttpRspRead;
    uint64_t			m_ullOutHttpReqRead;
    uint64_t			m_ullOutHttpRspRead;
    uint64_t			m_ullInFlowMatchCnt;
    uint64_t			m_ullOutFlowMatchCnt;
    uint64_t 			m_ullFilterByCgi;
    uint64_t 			m_ullFilterByHost;
    
    
    //map<uint64_t, uint32_t> m_TestReqList;
    
    string				m_sFilterFile, m_sKeyHost;
    CSuffixFind*		m_pFilterFileNode;
	CSuffixFind*		m_pKeyHostNode;
    uint32_t 			m_ulLastCheckFilterCondTime;
    uint8_t				m_ucCompressBit;


    HashTable<SHashData	, tHashType>     m_LinkHashTable; //Ŀǰ������ʱ��û�����ַ���
protected:
	bool HandleLoop(void);
};

#endif /* TRUNK_DEV_TRAFFICRELATE_CTRAFFICRELATEHASHSVRAPP_H_ */
