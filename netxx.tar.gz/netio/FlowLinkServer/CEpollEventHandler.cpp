#include "CEpollEventHandler.h"
#include "CFlowLinkSvrApp.h"

extern CFlowLinkSvrApp g_FlowLinkSrvApp;

CEpollEventHandler::CEpollEventHandler()
{
    m_iEpollSet = 0;
    m_iLastFd = -1;
}

CEpollEventHandler::~CEpollEventHandler()
{
    if (m_iLastFd >= 0 && m_iEpollSet)
    {
        g_FlowLinkSrvApp.DelEvent(m_iLastFd);
    }
}

int CEpollEventHandler::GetFd()
{
    int iFd = GetCurrentFd();
    ASSERT_RET(iFd >= 0, -1);
    if (iFd != m_iLastFd && m_iEpollSet)
    {
        g_FlowLinkSrvApp.DelEvent(m_iLastFd);
        m_iEpollSet = 0;
    }

    return m_iLastFd = iFd;
}

bool CEpollEventHandler::AddEvent(int iEvent)
{
    int iFd = GetFd();
    ASSERT_RET(iFd >= 0, false);

    if ((m_iEpollSet | iEvent) == m_iEpollSet)
    {
        return true;
    }
    LOG_TRACE("AddEvent, fd:%d, event:%d", iFd, iEvent);
    bool bRet;
    if (m_iEpollSet)
    {
         bRet = g_FlowLinkSrvApp.ModEvent(iFd, m_iEpollSet | iEvent, this);
    }
    else
    {
         bRet = g_FlowLinkSrvApp.AddEvent(iFd, m_iEpollSet | iEvent,  this);
    }
    
    if (bRet)
    {
        m_iEpollSet |= iEvent;
    }
    return bRet;
}


bool CEpollEventHandler::DelEvent(int iEvent)
{
    int iFd = GetFd();
    ASSERT_RET(iFd >= 0, false);

    if ((m_iEpollSet & ~iEvent) == m_iEpollSet)
    {
        return true;
    }
    LOG_TRACE("DelEvent, fd:%d, event:%d", iFd, iEvent);
    bool bRet;
    if (m_iEpollSet & ~iEvent)
    {
         bRet = g_FlowLinkSrvApp.ModEvent(iFd, m_iEpollSet & ~iEvent, this);
    }
    else
    {
         bRet = g_FlowLinkSrvApp.DelEvent(iFd);
    }
    
    if (bRet)
    {
        m_iEpollSet &= ~iEvent;
    }
    return bRet;
}


bool CEpollEventHandler::DelEvent()
{
    if (m_iEpollSet == 0)
    {
        return true;
    }
    int iFd = GetFd();
    ASSERT_RET(iFd >= 0, false);
    LOG_TRACE("DelAllEvent, fd:%d", iFd);
    if (g_FlowLinkSrvApp.DelEvent(iFd))
    {
        m_iEpollSet = 0;
        return true;
    }
    else
    {
        return false;
    }
}

