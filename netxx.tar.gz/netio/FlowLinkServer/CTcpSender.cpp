#include "CTcpSender.h"
#include "CTcpOutput.h"

const uint32_t MAX_RECONNECT_TIME = 10;
extern uint32_t g_ulSystemTime32;
const uint32_t MAX_RETRY_TIMES = 3;

uint32_t CTcpSender::s_uConnCnt=0; //��ǰ��������
uint32_t CTcpSender::s_uSendBytes=0;

CTcpSender::CTcpSender()
{
    m_ulLastConnectTime = 0;
    m_iFd = -1;
    m_ulConnFailedTimes = 0;
    memset(&m_stMasterAddr, 0, sizeof m_stMasterAddr);
    memset(&m_stSlaveAddr, 0, sizeof m_stSlaveAddr);
}

CTcpSender::~CTcpSender()
{
    if (m_iFd >= 0)
    {
        if (m_ulDataLen > 0)    // �������ݵĻ�, �����һ���ٹر�, �ܷ����پͷ����ٰ�, ������Ҳ������
        {
            uint32_t ulSendLen = m_ulDataLen;
            ASSERT(m_ulCurrentPos <= SEND_BUFFER_SIZE);
            
            if (ulSendLen > SEND_BUFFER_SIZE - m_ulCurrentPos)
            {
                ulSendLen = SEND_BUFFER_SIZE - m_ulCurrentPos;
            }
            int iRet = send(m_iFd, m_aucBuffer + m_ulCurrentPos, ulSendLen, 0);

            if (iRet == (int)ulSendLen)
            {
                m_ulCurrentPos += iRet;
                m_ulDataLen -= iRet;

                if (m_ulCurrentPos >= SEND_BUFFER_SIZE)
                {
                    ASSERT(m_ulCurrentPos == SEND_BUFFER_SIZE);
                    m_ulCurrentPos = 0;
                    if (m_ulDataLen)
                    {
                        send(m_iFd, m_aucBuffer + m_ulCurrentPos, m_ulDataLen, 0);
                    }
                }
            }
        }
        
        DelEvent();
        close(m_iFd);
        --s_uConnCnt;
    }
}


bool CTcpSender::Init(uint32_t ulMasterIP, uint16_t usMasterPort, uint32_t ulSlaveIP, uint16_t usSlavePort)
{
    m_ucStatus = TCP_CLOSED;
    
    m_stMasterAddr.sin_family      = AF_INET;
    m_stMasterAddr.sin_addr.s_addr = htonl(ulMasterIP);
    m_stMasterAddr.sin_port        = htons(usMasterPort);
    
    m_stSlaveAddr.sin_family      = AF_INET;
    m_stSlaveAddr.sin_addr.s_addr = htonl(ulSlaveIP);
    m_stSlaveAddr.sin_port        = htons(usSlavePort);

    m_pstCurrAddr = &m_stMasterAddr;        // Ĭ������
    
    m_ulCurrentPos = 0;
    m_ulDataLen = 0;
    //LOG_INFO("init tcpsender, master info = %s, slave info = %s", HashToAddr(((uint64_t)ulMasterIP << 32) | usMasterPort).c_str(), 
    //		HashToAddr(((uint64_t)ulSlaveIP << 32) | usSlavePort).c_str());

    return true;
}


bool CTcpSender::HandleRead()
{
    char szBuffer[4096];
    ASSERT_RET(m_iFd >= 0, false);

    // �����ϲ�����յ�����, �յ����ݵĻ�, ֱ�Ӷ�����    
    int iRet = recv(m_iFd, szBuffer, sizeof szBuffer, 0);
    if (iRet <= 0)
    {
    	return false;
    }
    //LOG_INFO("read data, fd = %d, last bytes = %02x, len = %d", m_iFd, ((uint8_t *)szBuffer)[iRet - 1], iRet);
    return true;
}

bool CTcpSender::HandleWrite()
{
    m_ulConnFailedTimes = 0;        // ֻҪ���ӳɹ�, ��ô����ʧ�ܵĴ�������0
    
    ASSERT_RET(m_iFd >= 0, false);

    if (m_ucStatus != TCP_CONNECTED)
    {
        m_ucStatus = TCP_CONNECTED;
    }
    
    if (m_ulDataLen)
    {
        uint32_t ulSendLen = m_ulDataLen;
        ASSERT_RET(m_ulCurrentPos <= SEND_BUFFER_SIZE, false);
        
        if (ulSendLen > SEND_BUFFER_SIZE - m_ulCurrentPos)
        {
            ulSendLen = SEND_BUFFER_SIZE - m_ulCurrentPos;
        }
        int iRet = send(m_iFd, m_aucBuffer + m_ulCurrentPos, ulSendLen, 0);

        if (iRet < 0)
        {
            if (errno == EAGAIN)
            {
                return true;
            }
            return false;
        }
        m_ulCurrentPos += iRet;
        m_ulDataLen -= iRet;

        if (m_ulCurrentPos >= SEND_BUFFER_SIZE)
        {
            ASSERT_RET(m_ulCurrentPos == SEND_BUFFER_SIZE, false);
            m_ulCurrentPos = 0;
            if (m_ulDataLen)
            {
                iRet = send(m_iFd, m_aucBuffer + m_ulCurrentPos, m_ulDataLen, 0);
                if (iRet < 0)
                {
                    if (errno == EAGAIN)
                    {
                        return true;
                    }
                    return false;
                }
                m_ulCurrentPos += iRet;
                m_ulDataLen -= iRet;
                s_uSendBytes += iRet;
            }
        }
    }

    if (m_ulDataLen == 0)
    {
        ASSERT_RET(DelEvent(EPOLLOUT), false);
    }


    return true;
}

void CTcpSender::HandleClose()
{
	LOG_WARN("tcp conn close by peer, fd = %d", m_iFd);
    if (m_iFd >= 0)
    {
        DelEvent();
        close(m_iFd);
        m_iFd = -1;
        --s_uConnCnt;
    }
    m_ucStatus = TCP_CLOSED;
    m_ulCurrentPos = 0;
    m_ulDataLen = 0;
}

void CTcpSender::HandleLoop()
{

}
    

bool CTcpSender::CanSend()
{
    if (-1 == m_iFd)
    {
        Reconnect();
        return false;
    }
    
    return TCP_CONNECTED == m_ucStatus && m_ulDataLen + MIN_BUFFER_SIZE < SEND_BUFFER_SIZE;
}

bool CTcpSender::SendData(const uint8_t *pPkg, uint32_t ulLen)
{
    // Ϊȷ�������һ������������, ���ȱ���С�ڵ���Buffer����
    if (ulLen > SEND_BUFFER_SIZE - m_ulDataLen)
    {
        return false;
    }

    ASSERT_RET(m_iFd >= 0, false);

    if (0 == m_ulDataLen)
    {
        int iRet = send(m_iFd, pPkg, ulLen, 0);
        if (iRet == (int)ulLen)
        {
            return true;
        }

        if (iRet < 0)
        {
            if (errno == EAGAIN)
            {
                iRet = 0;
            }
            else
            {
                LOG_ERR("Send err :%s", strerror(errno));
                Reconnect();
                return false;
            }
        }
        pPkg += iRet;
        ulLen -= iRet;
    }

    if (ulLen > 0)
    {
        uint32_t ulEndPos = (m_ulCurrentPos + m_ulDataLen) % SEND_BUFFER_SIZE;
        
        uint32_t ulCopyLen = ulLen;
        ASSERT_RET(ulEndPos <= SEND_BUFFER_SIZE, false);
        
        if (ulCopyLen > SEND_BUFFER_SIZE - ulEndPos)
        {
            ulCopyLen = SEND_BUFFER_SIZE - ulEndPos;
        }
        memcpy(m_aucBuffer + ulEndPos, pPkg, ulCopyLen);
        pPkg += ulCopyLen;
        ulLen -= ulCopyLen;
        m_ulDataLen += ulCopyLen;
        ulEndPos += ulCopyLen;
        
        if (ulEndPos >= SEND_BUFFER_SIZE && ulLen > 0)
        {
            ASSERT_RET(ulEndPos == SEND_BUFFER_SIZE, false);
            ulEndPos = 0;
            memcpy(m_aucBuffer + ulEndPos, pPkg, ulLen);
            m_ulDataLen += ulLen;
            ulEndPos += ulLen;
            ulLen = 0;
        }
        ASSERT_RET(ulLen == 0, false);
    }

    if (m_ulDataLen > 0)
    {
        ASSERT_RET(AddEvent(EPOLLIN | EPOLLOUT), false);
    }
    
    return true;
}


bool CTcpSender::Reconnect()
{
	//LOG_INFO("check reconnect");
    if (m_iFd != -1)
    {
        DelEvent();
        close(m_iFd);
        m_iFd = -1;
        --s_uConnCnt;
    }
    m_ucStatus = TCP_CLOSED;
    // clear buffer.
    m_ulDataLen = 0;
    m_ulCurrentPos = 0;

    if (m_ulLastConnectTime + MAX_RECONNECT_TIME >= g_ulSystemTime32)
    {
        return false;
    }
    m_ulLastConnectTime = g_ulSystemTime32;

    
    
    m_iFd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0);

    ASSERT_RET(m_iFd != -1, false);

    // ѡ������Ŀ��, ����, ȡ���ڵ�ǰ���ԵĴ���
    if (m_stSlaveAddr.sin_addr.s_addr == 0)
    {
        m_pstCurrAddr = &m_stMasterAddr;    //����Ч, ��ֻ��ѡ������
    }
    else
    {
        uint32_t ulIdx =  m_ulConnFailedTimes / MAX_RETRY_TIMES; // ���������� MAX_RETRY_TIMES ��

        if (ulIdx % 2 == 0)
        {
            m_pstCurrAddr = &m_stMasterAddr;
        }
        else
        {
            m_pstCurrAddr = &m_stSlaveAddr;
        }
    }
    
    m_ulConnFailedTimes++;
    

    if (-1 == connect(m_iFd, (sockaddr *)m_pstCurrAddr, sizeof (sockaddr_in)) && errno != EINPROGRESS)
    {
        LOG_ERR("connect to %s:%u err:%d", 
        		inet_ntoa(m_pstCurrAddr->sin_addr), ntohs(m_pstCurrAddr->sin_port), errno);
        close(m_iFd);
        m_iFd = -1;
        return false;
    }

    ++s_uConnCnt;

    ASSERT_RET(AddEvent(EPOLLIN | EPOLLOUT), false);
    m_ucStatus = TCP_CONNECTING;

    LOG_INFO("check conn to %s:%u", inet_ntoa(m_pstCurrAddr->sin_addr), ntohs(m_pstCurrAddr->sin_port));
    return true;
}




