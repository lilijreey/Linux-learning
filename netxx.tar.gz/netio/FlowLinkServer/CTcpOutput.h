#ifndef _C_TCP_OUTPUT_H_
#define _C_TCP_OUTPUT_H_

#include "CDataOutputBase.h"
#include "CTcpSender.h"
#include "snappy.h"

using namespace ARGUS;

const uint32_t STATIC_DATA_BUFFER_SIZE = 64 * 1024;		//���ܿ��ȶԷ��������ջ������󣬲�Ȼ�Է�������Զû��������һ����
const uint32_t MAX_BUF_SIZE =  64 * 1024 + 256;			
const uint32_t MIN_COMPRESS_BYTES = 300;
const uint32_t BLOCK_SIZE = 1048576; 

class CTcpOutput : public CDataOutputBase
{
public:
    CTcpOutput();
    ~CTcpOutput();
    
    bool Init(uint32_t ulIP, uint16_t usPort);

    bool CanWrite();

    bool Output(const CStaticData &Data) {return true;};
    
    bool OutputData(const char *pData, uint32_t ulLen, emCompressType emType);

    bool OutputTime(uint32_t ulTime)
    {
    	return true;
    }
    
    void Flush();

    void HandleLoop();
    
    virtual uint64_t GetTrafficCnt()
    {
    	return m_ullTrafficCnt;
    }
    
    virtual void ResetTrafficCnt()
    {
    	m_ullTrafficCnt = 0;
    }

    emOutputType GetOutputType() {return eTypeTCP;}
    
    void CheckFlush();
    
private:
    enum
    {
        MAX_TCP_CONNECTION = 1, // ��ཨ��5�����Ӵ�������
    };

    bool Send(const void *pHeadPkg, uint32_t ulHeadLen, CTcpSender *pSender = NULL);

    uint32_t            m_ulIP;
    uint16_t            m_usPort;
    CTcpSender *        m_apSender[MAX_TCP_CONNECTION];
    uint32_t            m_ulSenderTot;
    uint32_t            m_ulLastTime;
    
    char 				m_pBuffer[STATIC_DATA_BUFFER_SIZE];	//û��Muti FlowData�ˣ��Լ����������buffer
    uint32_t			m_ulBufferLen;
    uint64_t 			m_ullTrafficCnt;
    uint32_t 			m_ulBeforeCom;
    uint32_t 			m_ulAfterCom;
    uint64_t 			m_ullLastSendTime;
    
    uint64_t			m_ullSendBytes;
    emCompressType 		m_emType;
};

#endif

