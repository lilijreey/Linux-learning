/*
 * CTcpInFlowReceiver.h
 *
 *  Created on: 2017��4��18��
 *      Author: stanzeng
 */

#ifndef TRUNK_DEV_TRAFFICRELATE_CTCPINFLOWRECEIVER_H_
#define TRUNK_DEV_TRAFFICRELATE_CTCPINFLOWRECEIVER_H_

#include "CStaticData.h"
#include "CEpollEventHandler.h"
#include "CFlowLinkSvrApp.h"

using namespace ARGUS;

//һ��TCP���Ӷ�Ӧһ��CTcpInFlowReceiver
class CTcpInFlowReceiver: public CEpollEventHandler
{
public:
	CTcpInFlowReceiver(CFlowLinkSvrApp *pOwner);
	virtual ~CTcpInFlowReceiver();
	
	bool Init(int iFd);
	
	bool HandleRead();
	
	bool ParseData();

	void HandleClose();

    static uint32_t GetConnCnt() {return s_uConnCnt;}
    static uint32_t GetRecvBytes() {return s_uRecvBytes;}
    //uint32_t getSendBytes() {return s_uSendBytes;}
	
protected:
	
	int GetCurrentFd() {return m_iFd;};

    static uint32_t s_uConnCnt; //��ǰ��������
    //static uint32_t s_uSendBytes;
    static uint32_t s_uRecvBytes;

	
private:
	
	void FixupMemory();
	
	void FixupUncompressMemory();

	bool NotifyWrite();
	
	int m_iFd;
	
    enum 
    {
        DATA_BUFFER_SIZE = 128 * 1024,			//���ܵ�������
		DATA_UNCOMPRESS_SIZE = 128 * 1024,		//��ѹ���������
    };

	
    uint8_t         m_aucBuffer[DATA_BUFFER_SIZE];
    uint32_t        m_ulCurrentPos;
    uint32_t        m_ulDataLen;
    
    uint8_t			m_aucUncompressBuffer[DATA_UNCOMPRESS_SIZE];
    uint32_t 		m_ulUncompressPos;
    uint32_t 		m_ulUncompressDataLen;

    
    CStaticData 	m_stCurrentData;
    uint64_t 		m_ullTimestamp;
    CFlowLinkSvrApp* m_pOwner;
    bool m_bInitStaticData;
};

#endif /* TRUNK_DEV_TRAFFICRELATE_CTCPINFLOWRECEIVER_H_ */
