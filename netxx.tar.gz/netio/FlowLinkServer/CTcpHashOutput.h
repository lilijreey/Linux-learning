/*
 * CTcpHashOutput.h
 *
 *  Created on: 2017��4��14��
 *      Author: stanzeng
 */

#ifndef TRUNK_DEV_TRAFFICRELATE_CTCPHASHOUTPUT_H_
#define TRUNK_DEV_TRAFFICRELATE_CTCPHASHOUTPUT_H_


//const uint32_t MAX_SEND_BUFFER = 8 * 1024 * sizeof(tHashType);
//const uint32_t NOTIFY_SEND_BUFFER = 1024 * sizeof(tHashType); 
#include "CTcpSender.h"
#include "CFlowLinkSvrApp.h"

class CFlowLinkSvrApp;

class CTcpHashOutput : public CTcpSender
{
public:
	CTcpHashOutput(CFlowLinkSvrApp * pOwner);
	virtual ~CTcpHashOutput();
	
	bool Init(uint32_t ulIP, uint16_t usPort){ return CTcpSender::Init(ulIP, usPort, 0, 0);};
	bool IsTarget(uint32_t ulIP, uint16_t usPort);
	bool IsDead() {return !CanSend() && GetFailTime() >= 3;};
	uint32_t LeafBuffer() { return MAX_SEND_BUFFER - m_ulCurDataLen;} ;
	bool AppendData(void *pData, uint32_t ulLen);
	bool Flush();
	bool CheckFlush();
	void FixMemory();
	bool HandleRead();
	bool ParseHashRsp();
	
	
	
	
private:
    enum 
    {
        RECV_BUFFER_SIZE = 128 * 1024,
		MAX_SEND_BUFFER = 8 * 1024 * sizeof(tHashType),
		NOTIFY_SEND_BUFFER = 1024 * sizeof(tHashType), 
    };

    uint8_t         m_aucRecvBuffer[RECV_BUFFER_SIZE];
    uint32_t        m_ulRecvPos;
    uint32_t        m_ulRecvLen;
	char m_szSendBuffer[MAX_SEND_BUFFER];
	uint32_t m_ulCurDataPos;
	uint32_t m_ulCurDataLen;
	uint64_t m_ullLastSendTime;
	CFlowLinkSvrApp *m_pOwner;
};

#endif /* TRUNK_DEV_TRAFFICRELATE_CTCPHASHOUTPUT_H_ */
