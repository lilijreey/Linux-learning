/*
 * CFlowLinkSvrApp.cpp
 *
 *  Created on: 2017��3��30��
 *      Author: stanzeng
 */

#include "CFlowLinkSvrApp.h"
#include "def_config.h"
#include "NameHash.h"
#include "CTcpInFlowReceiver.h"
#include "ProcessLimit.h"
#include <pthread.h>
#include <sstream>
#include "CUsProto.h"

class CTcpInFlowReceiver;
const uint32_t EPOLL_WAIT_TIME = 100;
uint32_t g_ulSystemTime32;
uint64_t g_ullSystemTime;
const uint32_t CHECK_CENTER_SERVER_ALIVE_INTERVAL = 60;
const uint32_t CHECK_FILTER_COND_INTERVAL = 300;
static uint32_t g_ulIDCID =0;
static uint32_t s_ulLastReportTime=0;

#define 8 HASH_TIMES

static uint64_t GetCpuTime()
{
	char szFileName[40];
	char szLine[256];
	FILE * pFile = NULL;
	// Get process CPU usage.
	snprintf(szFileName, sizeof(szFileName), "/proc/stat");
	pFile = fopen(szFileName, "r");
	if (pFile == NULL)
	{
		LOG_ERR("Open file %s failed\n", szFileName);
		return -1;
	}
	if (fgets(szLine, sizeof(szLine), pFile) == NULL)
	{
		LOG_ERR("Read file %s failed\n", szFileName);
		fclose(pFile);
		return -1;
	}
	uint64_t ullUser, ullNice, ullSys, ullIdle, ullIowait, ullIrq, ullSoftirq, ullStealstolen, ullGuest;
	std::stringstream ssTmp(std::stringstream::in | std::stringstream::out);
	ssTmp << szLine;
	std::string strTmp;
	ssTmp >> strTmp >> ullUser >> ullNice >> ullSys >> ullIdle >> ullIowait
			>> ullIrq >> ullSoftirq >> ullStealstolen >> ullGuest;
	uint64_t ullCpuTime = ullUser + ullNice + ullSys + ullIdle + ullIowait + ullIrq
			+ ullSoftirq + ullStealstolen + ullGuest;
	fclose(pFile);
	return ullCpuTime;
}

static int GetProcessCpuTime(int iPid, uint64_t & ullTotalProcessTime)
{
	char szFileName[40];
	char szLine[256];
	FILE * pFile = NULL;
	// Get process CPU time.
	int iUtime = 0, iStime = 0, iCutime, iCstime = 0;
	snprintf(szFileName, sizeof(szFileName), "/proc/%d/stat", iPid);
	pFile = fopen(szFileName, "r");
	if (pFile == NULL)
	{
		LOG_ERR("Open file %s failed: %s\n", szFileName, strerror(errno));
		return -1;
	}
	if (fgets(szLine, sizeof(szLine), pFile) == NULL)
	{
		LOG_ERR("Read file %s failed: %s\n", szFileName, strerror(errno));
		fclose(pFile);
		return -1;
	}
	// Forgive me :). It's not elegant, but it saves a lot of codes.
	sscanf(szLine,
			"%*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %*s %d %d %d %d %*s %*s %*s %*s %*s",
			&iUtime, &iStime, &iCutime, &iCstime);

	ullTotalProcessTime = (uint64_t) (iUtime + iStime + iCutime + iCstime);
	fclose(pFile);
	return 0;
}

/*
 * reference: http://www.blogjava.net/fjzag/articles/317773.html
 */
static int GetProcessCpuUsage(pid_t pid, int &iCpuUsage, uint64_t &lastCpuTime, uint64_t &lastProcTime)
{
	static uint64_t s_ullCpuNum = (uint64_t) sysconf(_SC_NPROCESSORS_ONLN);
	uint64_t ullTmpProcessTime = 0;
	uint64_t ullTmpCpuTime = GetCpuTime();
    if (ullTmpCpuTime == (uint64_t)-1) 
    {
        LOG_ERR("GetCpuTime failed");
        return -1;
    }

	int iRet = GetProcessCpuTime(pid, ullTmpProcessTime);
    if (iRet != 0)
    {
        LOG_ERR("GetProcessCpuUsage failed for process %d", pid);
        return -1;
    }

	if (lastCpuTime != 0 && ullTmpCpuTime > lastCpuTime && ullTmpProcessTime > lastProcTime)
	{
		uint64_t ullCpuUsage = (s_ullCpuNum * 100 * (ullTmpProcessTime - lastProcTime)) / (ullTmpCpuTime - lastCpuTime);
		if (ullCpuUsage <= s_ullCpuNum * 100)
		{
			iCpuUsage = (int)ullCpuUsage;
		}
		else
		{
            LOG_ERR("GetProcessCpuUsage failed because too large cpu usage");
			iCpuUsage = 0;
		}
	}
	else
	{
        LOG_DBG("set usage = 0, nowProcTime:%lu lastProcTime:%lu, nowCpuTIme:%lu lastCpuTime:%lu", ullTmpCpuTime, lastCpuTime, ullTmpProcessTime, lastProcTime);
		iCpuUsage = 0;
	}

    lastCpuTime = ullTmpCpuTime;
	lastProcTime = ullTmpProcessTime;
	return 0;
}

/*
 * Reference: http://stackoverflow.com/questions/63166/how-to-determine-cpu-and-memory-consumption-from-inside-a-process
 */
static int GetProcessRSSMemInKB(int iPid, size_t &ulMemUsage)
{
	char szFileName[40];
	char szLine[256];
    ulMemUsage = 0;
	// Get process memory usage(unit is KB).
	snprintf(szFileName, sizeof(szFileName), "/proc/%d/status", iPid);
    struct stat stStat;
    if (stat(szFileName, &stStat) != 0)
    {
    	return -1;
    }
    FILE * pFile = fopen(szFileName, "r");
    if (pFile == NULL)
    {
    	LOG_WARN("Open file %s failed", szFileName);
    	return -1;
    }
	while (fgets(szLine, sizeof(szLine), pFile) != NULL)
	{
		if (strncmp(szLine, "VmRSS:", 6) == 0)
		{
			sscanf(szLine, "%*s %lu", &ulMemUsage);
			fclose(pFile);
			return 0;
		}
	}
    fclose(pFile);
    return -1;
}

CFlowLinkSvrApp::CFlowLinkSvrApp()
{
	m_ulLastCheckConfUpdateTime = 0;
	m_ulLastUpdateAvailSrvTime = 0;
	m_ulLastCheckAliveTime = 0;
	m_ulLastTimestampWritten = 0;
	m_ullLastCheckFlushTime = 0;
	m_ulLastCheckFilterCondTime = 0;
	m_ullInHttpReqRead = 0;
	m_ullInHttpRspRead = 0;
	m_ullOutHttpReqRead = 0;
	m_ullOutHttpRspRead = 0;
	m_ullFilterByCgi = 0;
	m_ullFilterByHost = 0;
	m_ullInFlowMatchCnt = 0;
	m_ullOutFlowMatchCnt = 0;
	m_pFilterFileNode = NULL;
	m_pKeyHostNode 		= NULL;
	m_ucCompressBit = TYPE_SNAPPY;
}

CFlowLinkSvrApp::~CFlowLinkSvrApp()
{
	for(vector<CStaticDataIOReader* >::iterator Iter = m_HashFlowInIOReaderList.begin(); Iter != m_HashFlowInIOReaderList.end(); Iter++)
	{
		delete *Iter;
	}
	
	for(vector<CStaticDataIOReader* >::iterator Iter = m_HashFlowOutIOReaderList.begin(); Iter != m_HashFlowOutIOReaderList.end(); Iter++)
	{
		delete *Iter;
	}
}

bool CFlowLinkSvrApp::InitServer()
{
    InitLog();

    CConfig *pConfig = GetConfig();
	//������־�澯����
	CLog *pLog =CLog::Instance();
    
	pLog->SetMntAttr(LOG_LEVEL_ASSERT, MONITOR_ASSERT_LOG);
	pLog->SetMntAttr(LOG_LEVEL_WARN, MONITOR_WARN_LOG);
	pLog->SetMntAttr(LOG_LEVEL_ERR, MONITOR_ERR_LOG);
	
    // io
    string sShmFile = pConfig->GetVal("IO", "shm_file");
    ASSERT_RET(!sShmFile.empty(), false);
    
    vector<string> vecMapList;
    for (int i = 0; ; ++i)
    {
        bool bExist = false;
        string sMapFile = pConfig->GetValEx("IO", "map_file_list", i, &bExist);
        if (!bExist)
        {
            break;
        }

        vecMapList.push_back(sMapFile);
    }

    vector<int> vecShmList;
    for (int i = 0; ; ++i)
    {
        bool bExist = false;
        int iShmID = pConfig->GetIntValEx("IO", "shm_list", i, &bExist);
        if (!bExist)
        {
            break;
        }

        vecShmList.push_back(iShmID);
    }

    int iShmSize = pConfig->GetIntVal("IO", "shm_size");

    ASSERT_RET(!vecMapList.empty(), false);
    
    ASSERT_RET(CIOBase::CommInit(vecMapList, vecShmList, iShmSize), false);
	
	string sDirection = pConfig->GetVal("COMMON", "DIRECTION");	
    if(sDirection == "IN")
    {
    	m_emDirection = DIR_IN;
    }
    else if(sDirection == "OUT")
    {
    	m_emDirection = DIR_OUT;
    }
    else
    {
    	LOG_ERR("traffic direction err, value = %s", sDirection.c_str());
    	return false;
    }
    if(m_emDirection == DIR_IN)
    {
    	ASSERT_RET(LockFile(), false);
    }
    
   
    SetPriority();
    SetCpuAffinity(PRI_HIGHER);

    m_ulIOTotalCount = 6;
    
    m_ulProcessCnt = pConfig->GetIntVal("COMMON", "PROCESS_NUM");
    
    
    CConfig ArgusConf;
    if(ArgusConf.LoadFile("/home/oicq/argus/argus.conf"))
    {
    	m_ulIOTotalCount = ArgusConf.GetIntVal("COMMON", "io_num");
    	ASSERT_RET(m_ulIOTotalCount, false);
    	
    	string sMachineType = ArgusConf.GetVal("COMMON", "machine_type");
    	if(sMachineType == "40G")
    	{
    		m_ulProcessCnt = pConfig->GetIntVal("COMMON", "PROCESS_NUM_FOR40G");
    	}
    }
     
    LOG_INFO("process cnt = %u", m_ulProcessCnt);
    ASSERT_RET(m_ulProcessCnt, false);
    
    ASSERT_RET(InitReaderAndWrite(), false); 

	CConfig ArgusAgentConf;
	if(!ArgusAgentConf.LoadFile("/home/oicq/argus/ArgusAgent/conf/ArgusAgent.conf"))
	{
		LOG_INFO("no agent config,ignore");
	}
	else
	{
		g_ulIDCID = ArgusAgentConf.GetUIntVal("COMMON", "idc_id");
	}
    
    uint32_t ulHashDataKey = m_emDirection == DIR_IN ? HASH_DATA_KEY + m_ulPortStep :  HASH_DATA_KEY + 1000 + m_ulPortStep;

    ASSERT_RET(g_cHashTable.Init(ulHashDataKey, 500000, 8), false);
    g_cHashTable.DelAllElems();
    
    int iShmKey = pConfig->GetIntVal("CENTER_SERVER_INFO", "shm_key");
    ASSERT_RET(iShmKey > 0, false);

    if (!m_stCenterServerInfo.Init(iShmKey))
    {
        LOG_ERR("Init center server info err.");
        return false;
    }
    
    m_iMaxFds = pConfig->GetIntVal("LOCAL_SERVER", "max_conn");
    ASSERT_RET(m_iMaxFds > 0 ,false);
    
    m_iEpollFd = epoll_create(m_iMaxFds * 2);
    if(m_iEpollFd == -1)
    {
    	LOG_ERR("epoll create failed, errno = %d, err msg = %s", errno, strerror(errno));
    	return false;
    }

    m_astEvents = new epoll_event[m_iMaxFds];
    ASSERT_RET(m_astEvents, false);
    
    
    m_sLocalIP = pConfig->GetVal("LOCAL_SERVER", "local_ip");
    if(m_emDirection == DIR_OUT)
    {
    	m_usBindPort = pConfig->GetIntVal("LOCAL_SERVER", "bind_port");
    	ASSERT_RET(m_usBindPort > 0, false);
    	m_usBindPort += m_ulPortStep;
    	
    	struct sockaddr_in stAddr;
    	stAddr.sin_family = AF_INET;
    	stAddr.sin_port = htons(m_usBindPort);
    	stAddr.sin_addr.s_addr = inet_addr(m_sLocalIP.c_str());
    	
    	m_iListenFd = socket(AF_INET, SOCK_STREAM | SOCK_NONBLOCK | SOCK_CLOEXEC, 0); 
    	ASSERT_RET(m_iListenFd > 0, false);
    	
        if (bind(m_iListenFd, (sockaddr*)&stAddr, sizeof stAddr) != 0)
        {
            LOG_ERR("Can not bind %s:%u", m_sLocalIP.c_str(), m_usBindPort);
            return false;
        }

        if (listen(m_iListenFd, m_iMaxFds))
        {
            LOG_ERR("listen err:%d",errno);
            return false;
        }
        
        LOG_INFO("bind %s:%d success", m_sLocalIP.c_str(), m_usBindPort);
        
        ASSERT_RET(AddReadEvent(m_iListenFd), false);
    }

	m_stHashPack.ulStx = m_emDirection == DIR_IN ? HASH_IN_STX : HASH_OUT_STX;
	//m_stHashPack.ullReserved = m_emDirection == DIR_IN ? 0 : (((uint64_t) inet_network(m_sLocalIP.c_str()) << 32) | m_usBindPort);
	m_stHashPack.ulIP = m_emDirection == DIR_IN ? 0 : inet_network(m_sLocalIP.c_str());
	m_stHashPack.usPort = m_emDirection == DIR_IN ? 0 : m_usBindPort;
	m_stHashPack.ullReserved = 0;

    ASSERT_RET(m_LinkHashTable.Init(400000, HASH_TIMES), false);

	return true;
}

bool CFlowLinkSvrApp::LockFile()
{
	struct flock _flock;
	_flock.l_type =  F_WRLCK;
	_flock.l_whence = SEEK_SET;
	_flock.l_len = 1;
	_flock.l_start = m_ulPortStep;
	
	m_iLockFileFd = open( "/home/oicq/argus/FlowLinkServer/conf/lock_file", O_CREAT|O_RDWR, S_IRWXU|S_IRGRP|S_IWGRP|S_IRWXO);
    if (m_iLockFileFd < 0 )
    {
    	LOG_ERR("open file failed, errno = %d", errno);
        return false;
    }
	
	if(fcntl(m_iLockFileFd, F_SETLK, &_flock) != -1)
	{
		LOG_INFO("lock suc");
	}
	else 
	{
		LOG_ERR("lock failed");
		return false;
	}
    
	return true;
}

bool CFlowLinkSvrApp::InitReaderAndWrite()
{
	
	const char * const HTTP_IN_NEED_FIELD[] = 
	{
		"src.ip",
	    "dst.ip",
	    "src.port",
	    "dst.port",
	    "http.ack",	
		"http.cgi",
		"http.host",
	};

	const char * const HTTP_OUT_NEED_FIELD[] =
	{	
		"dst.ip",
		"src.ip",
		"dst.port",
		"src.port",
		"httprsp.seq",
	};
	
	const uint32_t IN_SELECT_FIELD_COUNT = 7;
	const uint32_t OUT_SELECT_FIELD_COUNT = 5;
	
//	//��Ԫ�� + SEQ

	for(uint32_t i = 0 ; i < IN_SELECT_FIELD_COUNT; ++i)
	{
		for(uint32_t j = 0 ; j < HTTP_FLD_END ; ++j)
		{
			if(strcmp(HTTP_FLD_NAME[j], HTTP_IN_NEED_FIELD[i]) == 0)
			{
				m_InFlowNeedFieldList.push_back(j);
			}
		}
	}
//	//��Ԫ�� + ACK
//	
//	for(uint32_t i = 0 ; i < SELECT_FIELD_COUNT; ++i)
//	{
//		for(uint32_t j = 0 ; j < HTTP_RSP_FLD_END ; ++j)
//		{
//			if(strcmp(HTTP_RSP_FLD_NAME[j], HTTP_OUT_NEED_FIELD[i]) == 0)
//			{					
//				m_OutFlowNeedFieldList.push_back(j);
//			}
//		}
//	}
	
	//SetForceFieldType(const vector<emExpType> &vecType)
	
	
	
	vector<CStaticData::tFieldSelector> astSelector;
	vector<emExpType> vecSelectorType;
	
	CStaticData::tFieldSelector stSelector;
	
	if(m_emDirection == DIR_IN)
	{
		for(uint32_t i = 0 ; i < IN_SELECT_FIELD_COUNT; ++i)
		{
			for(uint32_t j = 0 ; j < HTTP_FLD_END ; ++j)
			{
				if(strcmp(HTTP_FLD_NAME[j], HTTP_IN_NEED_FIELD[i]) == 0)
				{
					stSelector.ulSrcID = j;
					stSelector.ulDstID = i;
					astSelector.push_back(stSelector);
					vecSelectorType.push_back(HTTP_FLD_TYPE[j]);
				}
			}
		}
	}
	else
	{
		for(uint32_t i = 0 ; i < OUT_SELECT_FIELD_COUNT; ++i)
		{
			for(uint32_t j = 0 ; j < HTTP_RSP_FLD_END ; ++j)
			{
				if(strcmp(HTTP_RSP_FLD_NAME[j], HTTP_OUT_NEED_FIELD[i]) == 0)
				{
					stSelector.ulSrcID = j;
					stSelector.ulDstID = i;
					astSelector.push_back(stSelector);
					vecSelectorType.push_back(HTTP_RSP_FLD_TYPE[j]);
				}
			}
		}
	}
	
	
	//uint32_t ulNeedReadWriteIOCount = ( m_ulIOTotalCount + m_ulProcessCnt - 1 - m_ulPortStep ) / m_ulProcessCnt ;
	//���㱾������Ҫ����IO����
	
	uint32_t ulNeedReadWriteIOCount = m_ulIOTotalCount / m_ulProcessCnt;
	if( m_ulIOTotalCount % m_ulProcessCnt != 0)
	{
		ulNeedReadWriteIOCount = (uint32_t)m_ulPortStep + 1 >= (m_ulIOTotalCount % m_ulProcessCnt) ? ulNeedReadWriteIOCount + 1 : ulNeedReadWriteIOCount;
	}
	
	uint64_t ullBaseIOID = m_emDirection == DIR_IN ? IN_HTTP_STREAM_IO_ID : OUT_HTTP_RSP_STREAM_IO_ID;
	for(uint32_t i = 0 ; i < ulNeedReadWriteIOCount; ++i )
	{
		CStaticDataIOReader *pHashIOReader = new CStaticDataIOReader;
		ASSERT_RET(pHashIOReader->Init(ullBaseIOID + i * m_ulProcessCnt + m_ulPortStep), false);
		pHashIOReader->SetForceFieldType(vecSelectorType);
		pHashIOReader->SetSelector(astSelector);
		m_HashFlowInIOReaderList.push_back(pHashIOReader);
			
		
		if(m_emDirection == DIR_OUT)
		{
			CLocalOutput *pOutput = new CLocalOutput;
			ASSERT_RET(pOutput->Init(FLOW_LINK_IN_IO_ID + i * m_ulProcessCnt + m_ulPortStep), false);
			m_LocalFlowInList.push_back(pOutput);
			LOG_INFO("IN HTTP LINK, port step = %d, ioid = %lu", m_ulPortStep, (FLOW_LINK_IN_IO_ID + i * m_ulProcessCnt + m_ulPortStep));
		}
	}
	
	ullBaseIOID = m_emDirection == DIR_IN ? OUT_HTTP_STREAM_IO_ID : IN_HTTP_RSP_STREAM_IO_ID;
	for(uint32_t i = 0 ; i < ulNeedReadWriteIOCount; ++i )
	{
		CStaticDataIOReader *pHashIOReader = new CStaticDataIOReader;
		ASSERT_RET(pHashIOReader->Init(ullBaseIOID + i * m_ulProcessCnt + m_ulPortStep), false);
		pHashIOReader->SetForceFieldType(vecSelectorType);
		pHashIOReader->SetSelector(astSelector);
		
		m_HashFlowOutIOReaderList.push_back(pHashIOReader);
		
		if(m_emDirection == DIR_OUT)
		{
			CLocalOutput *pOutput = new CLocalOutput;
			ASSERT_RET(pOutput->Init(FLOW_LINK_OUT_IO_ID + i * m_ulProcessCnt + m_ulPortStep), false);
			m_LocalFlowOutList.push_back(pOutput);
			LOG_INFO("OUT HTTP LINK, port step = %d, ioid = %lu", m_ulPortStep, (FLOW_LINK_OUT_IO_ID + i * m_ulProcessCnt + m_ulPortStep));
		}
	}
	
	
	
	vector<emExpType> vecLinkDataType;
	if(m_emDirection == DIR_OUT)
	{
		for(uint32_t i = 0 ; i < HTTP_FLD_END ; ++i)
		{
			vecLinkDataType.push_back(HTTP_FLD_TYPE[i]);
		}
		
		for(uint32_t i = 0 ; i < HTTP_RSP_FLD_END; ++i)
		{
			vecLinkDataType.push_back(HTTP_RSP_FLD_TYPE[i]);
		}
		ASSERT_RET(m_FlowLinkData.InitField(vecLinkDataType), false);		
	}
	
	return true;
}

bool CFlowLinkSvrApp::SetPriority()
{
	int iPrio = -1;
    if(setpriority(PRIO_PROCESS, 0, iPrio) == -1)
    {
        LOG_ERR("Set process priority %d err: %d", iPrio, errno);
        return false;
    }
    
	return true;
}

int CFlowLinkSvrApp::GetHashDataInfoAndDelete(uint64_t ullHash, int& iDir, char *pBuf, uint32_t ulLen)
{
	
	SHashData *pstElem = g_cHashTable.GetElem(ullHash);
	if(pstElem)
	{
		if(ulLen < pstElem->dataPointer.ulLen)
		{
			LOG_INFO("buffer size exceed len:%u need %u", ulLen, pstElem->dataPointer.ulLen);
			return -2;
		}

		int iLen = pstElem->pIOReader->GetDataMemory(pstElem->dataPointer,pBuf,ulLen); 
        if (iLen > 0) 
        {
			iDir = pstElem->ulDir;
			g_cHashTable.DelElem(ullHash);
			return iLen;
		}
		g_cHashTable.DelElem(ullHash);
		return -3;
	}
	else
	{
		LOG_ERR("can not get hash from cache, ullHash = %lu", ullHash);
	}
		
	MyMonitor(ATTR_FLOW_LINK_HASH_TIMEOUT);
	return -1;
}

		
		


uint64_t CFlowLinkSvrApp::GetHashFromHttpReqStaticData(const CStaticData &stData)
{
	
	//ǰ4���ֶ���Ԫ������һ��hash����32λ��Ȼ��ack/seq��Ϊ��32λ

	uint64_t ullHash = 0, ullValue;
	
	for(uint32_t i = 0 ; i < 4; ++i)
	{
		ullValue = stData.ReadUint(m_InFlowNeedFieldList[i]);
		ullHash = CRC32((const char *)&ullValue, sizeof(ullValue), ullHash);
	}
	
	ullHash = (ullHash << 32) |  stData.ReadUint(m_InFlowNeedFieldList[4]);

	return ullHash;
}

uint64_t CFlowLinkSvrApp::GetHashFromFieldSelectorStaticData(const CStaticData &stData)
{
	
	//ǰ4���ֶ���Ԫ������һ��hash����32λ��Ȼ��ack/seq��Ϊ��32λ

	uint64_t ullHash = 0, ullValue;	
	for(uint32_t i = 0 ; i < 4; ++i)
	{
		ullValue = stData.ReadUint(i);
		ullHash = CRC32((const char *)&ullValue, sizeof(ullValue), ullHash);
	}
	
	ullHash = (ullHash << 32) |  stData.ReadUint(4);

	return ullHash;
}


//�����������ϲ�������׼ȷ�Ե�
bool CFlowLinkSvrApp::CheckTestRequest(const CStaticData &stData)
{
	return true;
//	vector<uint32_t> *pFieldList = NULL;	
//
//	if(m_emDirection == DIR_IN)
//	{
//		pFieldList = &m_InFlowNeedFieldList;
//	}
//	else
//	{
//		pFieldList = &m_OutFlowNeedFieldList;
//	}
//	
//	ASSERT_RET(pFieldList->size() > 1, false);
//	
//	uint64_t ullHash = GetHashFromStaticData(stData);
//	if( stData.ReadUint((*pFieldList)[0]) == 992312645 || stData.ReadUint((*pFieldList)[1]) == 992312645 )
//	{
//		LOG_INFO("test req, dir = %d, info = %lu,%lu,%lu,%lu,%lu, hash = %lu", m_emDirection, 
//				stData.ReadUint((*pFieldList)[0]), stData.ReadUint((*pFieldList)[1]),
//				stData.ReadUint((*pFieldList)[2]), stData.ReadUint((*pFieldList)[3]), stData.ReadUint((*pFieldList)[4]), ullHash);
//		m_TestReqList[ullHash] = time(NULL);
//		return true;
//	}
//	return false;
}


bool CFlowLinkSvrApp::ProcessAccept()
{
    sockaddr_in stInAddr;
    socklen_t ulSockLen = sizeof stInAddr;
    
    // accept4 ��������ֱ�����������Ƿ�������
    int iNewFd = accept4(m_iListenFd, (sockaddr*)&stInAddr, &ulSockLen, SOCK_NONBLOCK | SOCK_CLOEXEC);
    ASSERT_RET(iNewFd >= 0, false);

    CTcpInFlowReceiver *pReceiver = new CTcpInFlowReceiver(this);
    if (!pReceiver->Init(iNewFd))
    {
        close(iNewFd);
        delete pReceiver;
        return false;
    }
    
	return true;
}


bool CFlowLinkSvrApp::AddEvent(int iFd, uint32_t ulEvent, CEpollEventHandler *pArg)
{
    struct epoll_event stEvent = {0};
    if (NULL ==  pArg)
    {
        stEvent.data.u64 = iFd;
    }
    else
    {
        stEvent.data.ptr = (void*)pArg;
    }
    stEvent.events = ulEvent;

    if (epoll_ctl(m_iEpollFd, EPOLL_CTL_ADD, iFd, &stEvent) != 0)
    {
        LOG_ERR("Can not add fd:%d to epoll events :%u. errno:%d", iFd, ulEvent, errno);
        return false;
    }
    return true;
}


bool CFlowLinkSvrApp::ModEvent(int iFd, uint32_t ulEvent, CEpollEventHandler *pArg)
{
    struct epoll_event stEvent = {0};
    if (NULL ==  pArg)
    {
        stEvent.data.u64 = iFd;
    }
    else
    {
        stEvent.data.ptr = (void*)pArg;
    }
    stEvent.events = ulEvent;

    if (epoll_ctl(m_iEpollFd, EPOLL_CTL_MOD, iFd, &stEvent) != 0)
    {
        LOG_ERR("Can not mod fd:%d to epoll events :%u. errno:%d", iFd, ulEvent, errno);
        return false;
    }
    return true;
}


bool CFlowLinkSvrApp::DelEvent(int iFd)
{
    struct epoll_event stEvent = {0};


    if (epoll_ctl(m_iEpollFd, EPOLL_CTL_DEL, iFd, &stEvent) != 0)
    {
        LOG_ERR("Can not del fd:%d from epoll events. errno:%d", iFd, errno);
        return false;
    }
    return true;
}




bool CFlowLinkSvrApp::NotifyWriteLinkPkg(CStaticData &stData)
{
	//get hash 
	uint64_t ullHash = GetHashFromHttpReqStaticData(stData);	
	
	int iDir = -1;
	static char szTmpBuffer[8 * 1024 * 1024];
	int iBufLen = sizeof szTmpBuffer, iLen;
	
	if((iLen = GetHashDataInfoAndDelete(ullHash, iDir, szTmpBuffer, iBufLen)) > 0)
	{
		
		static CStaticData stHttpOutData;
		static bool bInitHttpOutStaticData = false;
		
		if(unlikely(!bInitHttpOutStaticData))
		{
			//ASSERT_RET(m_stInitStaticData.InitFieldFromArray((const char *)(m_aucUncompressBuffer + m_ulUncompressPos), ulStaticDataPkgLen));
			if(stHttpOutData.InitFieldFromArray((const char *)szTmpBuffer, iBufLen) < 0)
			{
				LOG_ERR("init field from array fail.");
				return false;
			}        			
			LOG_INFO("init static data suc");
			bInitHttpOutStaticData = true;
		}
	    
		int iRet = stHttpOutData.ParseFromArray((const char *)szTmpBuffer, iBufLen);
		
		if(iRet < 0)
		{
			return false;
		}
						
		m_FlowLinkData.CopyFromObjString2IOString(stData, 0);
		m_FlowLinkData.CopyFromObjString2IOString(stHttpOutData, stData.GetFieldTot());
		
		
		static CLocalOutput *pOutput = NULL;
		
		if(iDir == 0)
		{
			pOutput = m_LocalFlowInList[ullHash % m_LocalFlowInList.size()];
			++m_ullInFlowMatchCnt;
		}
		else if(iDir == 1)
		{
			pOutput = m_LocalFlowOutList[ullHash % m_LocalFlowOutList.size()];
			++m_ullOutFlowMatchCnt;
		}
		else
		{
			LOG_ERR("err pkg dir, continue");
			return false;
		}
		//CLocalOutput *pOutput = m_LocalFlowOutputList[ullHash % m_LocalFlowOutputList.size()];
		//�ж���in ���� out��
		//LOG_INFO("output id = %lu", pOutput->GetOutputID());
		ASSERT_RET(pOutput->Output(m_FlowLinkData), false);
	}
	
	return true;
}


uint64_t CFlowLinkSvrApp::GetDstAddr(uint64_t ullSrcAddr)
{
	if(m_DstAddrList.find(ullSrcAddr) != m_DstAddrList.end())
	{
		return m_DstAddrList[ullSrcAddr];
	}
	else
	{
		uint64_t ullDstAddr = ((ullSrcAddr >> 32 ) << 32) + m_usBindPort + (m_DstAddrList.size() % m_ulProcessCnt);
		m_DstAddrList[ullSrcAddr] = ullDstAddr;
		return ullDstAddr;
	}
}

bool CFlowLinkSvrApp::NotityHashInput(uint32_t ulIP, uint16_t usPort, tHashType *pHashData, uint32_t ulHashCount)
{	
	
	CTcpOutput *pOutputer = NULL;  
	uint64_t ullDstHash = ((uint64_t)ulIP << 32) + usPort;
	if(m_TcpFlowOutput.find(ullDstHash) == m_TcpFlowOutput.end())
	{
		pOutputer = new CTcpOutput;
		LOG_INFO("ull dst hash = %lu", ullDstHash);
		ASSERT_RET(pOutputer->Init(ulIP, usPort), false);
		m_TcpFlowOutput[ullDstHash] = pOutputer;
	}
	else
	{
		pOutputer = m_TcpFlowOutput[ullDstHash];
	}
	ASSERT_RET(pOutputer, false);
	
	for(uint32_t i = 0 ; i < ulHashCount; ++i)
	{
		
		int iDir = -1;
		static char szDataBuffer[8 * 1024 * 1024];
		int iLen = GetHashDataInfoAndDelete(pHashData[i], iDir, szDataBuffer, sizeof(szDataBuffer));
		if(iLen < 0)
		{
			//LOG_INFO("get hash data failed, iret = %d", iLen);
		}
		else
		{
			if(pOutputer->CanWrite())
			{
				if(!pOutputer->OutputData(szDataBuffer, iLen, (emCompressType)m_ucCompressBit))
				{
					//LOG_ERR("output data failed");
					MyMonitor(ATTR_FLOW_LINK_WRITE_STATICDATA_FAIL);
				}
			}
			else
			{
				//LOG_ERR("can not write, skip");
				MyMonitor(ATTR_FLOW_LINK_WRITE_STATICDATA_FAIL);
			}
		}
	}
	return true; 
}

bool CFlowLinkSvrApp::CheckAvailCenterServer()
{
	
	if(m_ulLastUpdateAvailSrvTime == m_stCenterServerInfo.GetUpdateTime() && 
       g_ulSystemTime32 - m_ulLastCheckAliveTime < CHECK_CENTER_SERVER_ALIVE_INTERVAL) 
	{
		return true;
	}
	
	LOG_INFO("update alive server, last update time = %u, cur = %d", m_ulLastUpdateAvailSrvTime, m_stCenterServerInfo.GetUpdateTime());
	
	m_ulLastUpdateAvailSrvTime = m_stCenterServerInfo.GetUpdateTime();
	m_ulLastCheckAliveTime = g_ulSystemTime32;
	 
	vector<pair<uint32_t, uint16_t> > vecIPPortList;
	if(!m_stCenterServerInfo.GetAvailServer(vecIPPortList))
	{
		LOG_ERR("get avail ip and port from cache failed");
		return false;
	}
	
	uint64_t ullHash = 0;
	for(vector<pair<uint32_t, uint16_t> >::iterator Iter = vecIPPortList.begin(); Iter != vecIPPortList.end(); Iter++)
	{
		ullHash = ((uint64_t)Iter->first << 32) | (Iter->second); 
		if(m_AvailHashOutputList.find(ullHash) == m_AvailHashOutputList.end() 
				&& m_ToWakeUpHashOutputList.find(ullHash) == m_ToWakeUpHashOutputList.end())
		{
			CTcpHashOutput *pOutput = new CTcpHashOutput(this);
			if(!pOutput->Init(Iter->first, Iter->second))
			{
				LOG_ERR("init CTcpHashOutput failed");
				delete pOutput;
			}
			else
			{
				m_AvailHashOutputList[ullHash] = pOutput;
			}
		}
	}
	
	for(map<uint64_t, CTcpHashOutput *>::iterator Iter = m_AvailHashOutputList.begin(); Iter != m_AvailHashOutputList.end();)
	{
		if(Iter->second != NULL && Iter->second->IsDead())
		{
			LOG_INFO("%s dead, wait to wakeup", HashToAddr(Iter->first).c_str());
			m_ToWakeUpHashOutputList[Iter->first] = Iter->second;
			m_AvailHashOutputList.erase(Iter++);
		}
		else
		{
			Iter++;
		}
	}
	
	for(map<uint64_t, CTcpHashOutput *>::iterator Iter = m_ToWakeUpHashOutputList.begin(); Iter != m_ToWakeUpHashOutputList.end();)
	{
		if(Iter->second != NULL && !Iter->second->IsDead())
		{
			LOG_INFO("%s alive, wake up", HashToAddr(Iter->first).c_str());
			m_AvailHashOutputList[Iter->first] = Iter->second;
			m_ToWakeUpHashOutputList.erase(Iter++);
		}
		else
		{
			Iter++;
		}
	}
	
	m_AliveHashSeqList.clear();
	for(map<uint64_t, CTcpHashOutput *>::iterator Iter = m_AvailHashOutputList.begin(); Iter != m_AvailHashOutputList.end(); Iter++)
	{
		m_AliveHashSeqList.push_back(Iter->second);
	}
	
	LOG_INFO("cur avail cnt = %d, to wake up cnt = %d", m_AvailHashOutputList.size(), m_ToWakeUpHashOutputList.size());
	return true;
}

void CFlowLinkSvrApp::WriteAttrInfo()
{
	static uint64_t ullInHttpReqRead = 0;
	static uint64_t ullInHttpRspRead = 0;
	static uint64_t ullOutHttpReqRead = 0;
	static uint64_t ullOutHttpRspRead = 0;
	static uint64_t ullInFlowMatchCnt = 0;
	static uint64_t ullOutFlowMatchCnt = 0;

	Attr_API(ATTR_FLOW_LINK_IN_HTTP_REQ    ,m_ullInHttpReqRead -  ullInHttpReqRead);
	Attr_API(ATTR_FLOW_LINK_IN_HTTP_RSP    ,m_ullInHttpRspRead -  ullInHttpRspRead);
	Attr_API(ATTR_FLOW_LINK_OUT_HTTP_REQ   ,m_ullOutHttpReqRead - ullOutHttpReqRead);
	Attr_API(ATTR_FLOW_LINK_OUT_HTTP_RSP   ,m_ullOutHttpRspRead - ullOutHttpRspRead);
	Attr_API(ATTR_FLOW_LINK_IN_HTTP_MATCH  ,m_ullInFlowMatchCnt - ullInFlowMatchCnt);
	Attr_API(ATTR_FLOW_LINK_OUT_HTTP_MATCH ,m_ullOutFlowMatchCnt- ullOutFlowMatchCnt);

    LOG_INFO("attr info, in http req = %lu, in http rsp = %lu, out http req = %lu, "
             "out http rsp = %lu, in http match = %lu, out http match = %lu, filter by cgi = %lu, filter by host = %lu",			
             m_ullInHttpReqRead -ullInHttpReqRead, m_ullInHttpRspRead -ullInHttpRspRead,
             m_ullOutHttpReqRead - ullOutHttpReqRead, m_ullOutHttpRspRead -ullOutHttpRspRead,
             m_ullInFlowMatchCnt -ullInFlowMatchCnt, m_ullOutFlowMatchCnt - ullOutFlowMatchCnt,
             m_ullFilterByCgi, m_ullFilterByHost);

	ullInHttpReqRead   = m_ullInHttpReqRead  ;
	ullInHttpRspRead   = m_ullInHttpRspRead  ;
	ullOutHttpReqRead  = m_ullOutHttpReqRead ;
	ullOutHttpRspRead  = m_ullOutHttpRspRead ;
	ullInFlowMatchCnt  = m_ullInFlowMatchCnt ;
	ullOutFlowMatchCnt = m_ullOutFlowMatchCnt;

	m_ullFilterByCgi = 0;
	m_ullFilterByHost = 0;
	
}

void CFlowLinkSvrApp::CheckFilterCond()
{
	string sFilterFile;
	m_stCenterServerInfo.GetFilterFile(sFilterFile);
	if(sFilterFile != m_sFilterFile)
	{
		LOG_INFO("filter file update, last = %s, cur = %s", m_sFilterFile.c_str(), sFilterFile.c_str());
		m_sFilterFile = sFilterFile;
		if(m_pFilterFileNode)
		{
			delete m_pFilterFileNode;
			m_pFilterFileNode = NULL;
		}
		m_pFilterFileNode = new CSuffixFind;
		m_pFilterFileNode->Insert(m_sFilterFile);
	}
	
	string sKeyHost;
	m_stCenterServerInfo.GetKeyHost(sKeyHost);
	if(sKeyHost != m_sKeyHost)
	{
		LOG_INFO("key host update, last = %s, cur = %s", m_sKeyHost.c_str(), sKeyHost.c_str());
		m_sKeyHost = sKeyHost;
		if(m_pKeyHostNode)
		{
			delete m_pKeyHostNode;
			m_pKeyHostNode = NULL;
		}
		m_pKeyHostNode = new CSuffixFind;
		m_pKeyHostNode->Insert(m_sKeyHost);
	}
}

void CFlowLinkSvrApp::CheckCompressConf()
{
	m_stCenterServerInfo.GetCompressBit(m_ucCompressBit);
}


void CFlowLinkSvrApp::ReportInfo(void) const
{
    static const pid_t pid = getpid();
    static uint64_t lastCpuTime = 0;
    static uint64_t lastProcTime = 0;
    static uint64_t lastSendBytes = 0;
    static uint64_t lastRecvBytes = 0;
    static uint64_t lastInFlowMatchCnt = 0;
    static uint64_t lastOutFlowMatchCnt = 0;
    static uint64_t lastInHttpReqCnt = 0;
    static uint64_t lastInHttpRspCnt = 0;
    static uint64_t lastOutHttpReqCnt = 0;
    static uint64_t lastOutHttpRspCnt = 0;
    //TODO lost unactch count

    int iCpuUsage=0;
    if (GetProcessCpuUsage(pid, iCpuUsage, lastCpuTime, lastProcTime) != 0)
    {
        LOG_ERR("GetProcessCpuUsage failed");
        //return ;
    }

    uint64_t rssMemKB = 0;
    if (GetProcessRSSMemInKB(pid, rssMemKB) != 0) 
    {
        LOG_ERR("GetProcessRSSMemInKB failed");
        //return ;
    }

    uint64_t sendBytes= CTcpInFlowReceiver::GetRecvBytes() - lastRecvBytes;
    uint64_t recvBytes= CTcpSender::GetSendBytes() - lastSendBytes;
    uint64_t inMatchCnt = m_ullInFlowMatchCnt - lastInFlowMatchCnt;
    uint64_t outMatchOut = m_ullOutFlowMatchCnt - lastOutFlowMatchCnt;
    uint64_t inHttpReqCnt = m_ullInHttpReqRead - lastInHttpReqCnt;
    uint64_t inHttpRsqCnt = m_ullInHttpRspRead - lastInHttpRspCnt;
    uint64_t outHttpReqCnt = m_ullOutHttpReqRead - lastOutHttpReqCnt;
    uint64_t outHttpRsqCnt = m_ullOutHttpRspRead - lastOutHttpRspCnt;

    int senderCnt =  CTcpSender::GetConnCnt();
    int reciverCnt =  CTcpInFlowReceiver::GetConnCnt();

    //isEnable
    LOG_INFO("report info -p %u dir %s cpu:%d RSS %lu(BK) sendSocket:%d  recvSocket:%d send:%lu(KB) recv:%lu(KB) inReqCnt:%lu inRspCnt:%lu outReqCnt:%lu outRspCnt:%lu matchIn:%lu, matchOut:%lu idc:%d, ip:%s ", 
             m_ulPortStep, (m_emDirection == DIR_IN) ? "in":"out", iCpuUsage, rssMemKB, senderCnt, reciverCnt, (sendBytes >> 10), (recvBytes >> 10), 
             inHttpReqCnt, inHttpRsqCnt, outHttpReqCnt, outHttpRsqCnt, inMatchCnt, outMatchOut, g_ulIDCID, m_sLocalIP.c_str());


#define	sysid_16152 16152 //http://armory.wht.oa.com/accessApplyV3/accessApplyInfo?sysid=16152
    TCPAGENTPROTO::CUsProto sysMsg;
	sysMsg.Reset();
    sysMsg.AddUint("idcId", g_ulIDCID);
    sysMsg.AddStr("ip", m_sLocalIP.c_str(), m_sLocalIP.length());
    sysMsg.AddUint("proc", m_ulPortStep);
    sysMsg.AddUint("dir", m_emDirection);
    sysMsg.AddInt("cpu", iCpuUsage);
    sysMsg.AddUint("memRssKB", rssMemKB);
    sysMsg.AddUint("connectSocketCnt", senderCnt);
    sysMsg.AddUint("aceeptSocketCnt", reciverCnt);
    sysMsg.AddUint("sendBytes", sendBytes);
    sysMsg.AddUint("recvBytes", recvBytes);
    sysMsg.AddUint("inReqCnt", inHttpReqCnt);
    sysMsg.AddUint("inRspCnt", inHttpRsqCnt);
    sysMsg.AddUint("outReqCnt", outHttpReqCnt);
    sysMsg.AddUint("outRspCnt", outHttpRsqCnt);
    sysMsg.AddUint("inMatchCnt", inMatchCnt);
    sysMsg.AddUint("outMatchCnt", outMatchOut);
    sysMsg.AddUint("time", g_ulSystemTime32);

    uint32_t ulRet = sysMsg.SendDataByTcp(sysid_16152, 0, 0);
    if (TCP_SEND_FAIL == ulRet)
    {
        ulRet = sysMsg.SendDataByUdp(sysid_16152, 0, 0);
        if (ulRet != 0)
        {
            LOG_ERR("Send to seacube sysid %d err:%u", sysid_16152, ulRet);
        }
    }
    LOG_DBG("report to sys 16152  successed");

    lastInFlowMatchCnt = m_ullInFlowMatchCnt;
    lastOutFlowMatchCnt = m_ullOutFlowMatchCnt;
    lastSendBytes = CTcpSender::GetSendBytes(); 
    lastRecvBytes = CTcpInFlowReceiver::GetRecvBytes();

    lastInHttpReqCnt = m_ullInHttpReqRead; 
    lastInHttpRspCnt = m_ullInHttpRspRead; 
    lastOutHttpReqCnt= m_ullOutHttpReqRead; 
    lastOutHttpRspCnt= m_ullOutHttpRspRead; 
}

bool CFlowLinkSvrApp::HandleLoop(void)
{
	timeval tv;
	gettimeofday(&tv, NULL);
	g_ullSystemTime = tv.tv_sec * 1000000 + tv.tv_usec;
	g_ulSystemTime32 = tv.tv_sec;

    if (s_ulLastReportTime + 60 < g_ulSystemTime32) {
        ReportInfo();
        s_ulLastReportTime = g_ulSystemTime32;
    }

	if(m_stCenterServerInfo.GetTrafficBit() && (m_stCenterServerInfo.GetTrafficBit() & (EM_TRAFFIC_IN | EM_TRAFFIC_OUT)) != (EM_TRAFFIC_IN | EM_TRAFFIC_OUT))
	{
		if(m_ulLastWriteLogTime != g_ulSystemTime32)
		{
			LOG_INFO("traffic type = %u, no need to link data", m_stCenterServerInfo.GetTrafficBit());
			m_ulLastWriteLogTime = g_ulSystemTime32;
		}
        //TODO BUG �����;�ı�ᵼ���޷�����epoll_wait
        //�޷��ر�һ�򿪵�socket,������Ǵ���CLOSE_WAIT״̬socketһ���
		return false;
	}
	
	if(tv.tv_sec != m_ulLastCheckConfUpdateTime)
	{
		CheckAvailCenterServer();		
		m_ulLastCheckConfUpdateTime = tv.tv_sec;
		CheckCompressConf();
		
		WriteAttrInfo();
	}
	
	if(tv.tv_sec - m_ulLastCheckFilterCondTime >= CHECK_FILTER_COND_INTERVAL)
	{
		CheckFilterCond();
	}
	
	if(g_ulSystemTime32 > m_ulLastTimestampWritten)
	{
		m_ulLastTimestampWritten = g_ulSystemTime32;
		for(uint32_t i = 0 ; i < m_LocalFlowInList.size(); ++i)
		{
			m_LocalFlowInList[i]->OutputTime(m_ulLastTimestampWritten);
		}

		for(uint32_t i = 0 ; i < m_LocalFlowOutList.size(); ++i)
		{
			m_LocalFlowOutList[i]->OutputTime(m_ulLastTimestampWritten);

		}
	}
	
	
	
	if(g_ullSystemTime - m_ullLastCheckFlushTime > 200000)
	{
		for(uint32_t i = 0 ; i < m_AliveHashSeqList.size(); ++i)
		{
			m_AliveHashSeqList[i]->CheckFlush();
		}
		
		for(map<uint64_t, CTcpOutput*>::iterator Iter = m_TcpFlowOutput.begin(); Iter != m_TcpFlowOutput.end(); Iter++)
		{
			Iter->second->CheckFlush();
		}
		m_ullLastCheckFlushTime = g_ullSystemTime;
	}
	
	uint32_t ulAliveServerNum = m_AliveHashSeqList.size();
	
	if(ulAliveServerNum)
	{
		for(uint32_t i = 0; i < 2 ; ++i)
		{
			const vector<CStaticDataIOReader*> &HashIOReaderList = (i == 0) ? m_HashFlowInIOReaderList : m_HashFlowOutIOReaderList; 
			for(uint32_t j = 0 ; j < HashIOReaderList.size(); ++j)
			{
				static CStaticDataIOReader::tStaticDataPointer astPointer[1024];
				uint32_t ulTimestamp = 0;
				pair<const CStaticData* , uint32_t> read_pair = HashIOReaderList[j]->GetNextMultiData(&ulTimestamp, astPointer);
				
				if(read_pair.second == 0)
				{
					continue;
				}
				
				if(m_emDirection == DIR_IN)
				{
					if(i == 0)
					{
						m_ullInHttpReqRead += read_pair.second;
					}
					else
					{
						m_ullOutHttpReqRead += read_pair.second;
					}
				}
				else
				{
					if(i == 0)
					{
						m_ullInHttpRspRead += read_pair.second;
					}
					else
					{
						m_ullOutHttpRspRead += read_pair.second;
					}
				}
				
				for(uint32_t ulIdx = 0 ; ulIdx < read_pair.second; ++ulIdx)
				{
					
					//HTTP������������ǰ������׺�����������ˣ�����������Ƿ�������Ҫ��
					if(m_emDirection == DIR_IN)
					{						
						if(!m_sFilterFile.empty())
						{
							if(m_pFilterFileNode && read_pair.first[ulIdx].ReadIOString(5).length() &&  
									m_pFilterFileNode->Search(read_pair.first[ulIdx].ReadIOString(5).AsStdString()))
                            {
								++m_ullFilterByCgi; 
								//LOG_INFO("filter cgi = %s.", read_pair.first[ulIdx].ReadString(5).c_str());
								continue;
							}
						}
						
						if(!m_sKeyHost.empty())
						{
							if(m_pKeyHostNode && (!read_pair.first[ulIdx].ReadIOString(6).length() ||
									!m_pKeyHostNode->SearchExt(read_pair.first[ulIdx].ReadIOString(6).AsStdString())))
							{
								++m_ullFilterByHost;
								continue;
							}
							//LOG_INFO("key host = %s.", read_pair.first[ulIdx].ReadString(6).c_str());
						}
					}
					
					tHashType ullHash = GetHashFromFieldSelectorStaticData(read_pair.first[ulIdx]);
						
					m_stHashData.ullTime = g_ullSystemTime;
					m_stHashData.key = ullHash;
                    m_stHashData.dataPointer = astPointer[ulIdx];
					m_stHashData.ulDir = i;
					m_stHashData.pIOReader = HashIOReaderList[j];
					
                    //TODO
					if(!g_cHashTable.InsertElem(m_stHashData))
					{
						LOG_ERR("insert hash data failed");
					}
					
					if(likely(ulAliveServerNum))
					{
						CTcpHashOutput *pOutput = m_AliveHashSeqList[ullHash % ulAliveServerNum];
						if(pOutput->CanSend() && pOutput->LeafBuffer() >= sizeof(tHashPack) + sizeof(tHashType))
						{
							m_stHashPack.ulLen = sizeof(tHashPack) + sizeof(tHashType);
							m_stHashPack.astData[0] = ullHash;
                            //m_stHashPack.dir = i;
								
							pOutput->AppendData((void *)&m_stHashPack, m_stHashPack.ulLen);
						}
						else
						{
							//LOG_INFO("can send %d, leaf buffer = %u", pOutput->CanSend(), pOutput->LeafBuffer());
							static uint64_t s_ullDropCount = 0;
							if(s_ullDropCount++ % 1000 == 0)
							{
								LOG_ERR("disconnect or buffer overflow, drop data, drop count = %lu", s_ullDropCount);
							}
						}
					}
				}
			}
		}
	}
	
    int iReadFds = epoll_wait(m_iEpollFd, m_astEvents, m_iMaxFds, EPOLL_WAIT_TIME);

    for (int i  = 0; i < iReadFds; ++i)
    {
        if (m_astEvents[i].data.u64 == (uint64_t)m_iListenFd)
        {
        	//MyMonitor(MONITOR_PROCESS_ACCEPT);
            ProcessAccept();
            continue;
        }
        
        CEpollEventHandler *pObj = (CEpollEventHandler *)m_astEvents[i].data.ptr;
        
        if (m_astEvents[i].events & EPOLLERR)
        {
        	MyMonitor(ATTR_FLOW_LINK_EPOLL_EPOLLERR);
        	LOG_ERR("handle epoll err msg, close conn, events = %u", m_astEvents[i].events);
            pObj->HandleClose();
            continue;
        }
        
        if (m_astEvents[i].events & EPOLLHUP)
        {
        	MyMonitor(ATTR_FLOW_LINK_EPOLL_EPOLLHUP);
        	LOG_ERR("handle epoll hup msg, close conn, events = %u", m_astEvents[i].events);
            pObj->HandleClose();
            continue;
        }
                
        if (m_astEvents[i].events & EPOLLIN)
        {
            if (!pObj->HandleRead())
            {
                // Read faid
            	MyMonitor(ATTR_FLOW_LINK_HANDLE_READ_FAIL);
            	LOG_ERR("handle read fail , close conn");
                pObj->HandleClose();
                continue;
            }
        }
        
        if (m_astEvents[i].events & EPOLLOUT)
        {
            if (!pObj->HandleWrite())
            {
                // write faid
            	MyMonitor(ATTR_FLOW_LINK_HANDLE_WRITE_FAIL);
            	LOG_ERR("handle write fail , close conn");
                pObj->HandleClose();
                continue;
            }
        }                                               
    }
	
	
	
	return true;
}
