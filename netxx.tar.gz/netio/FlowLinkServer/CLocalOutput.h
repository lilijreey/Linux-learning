#ifndef _C_LOCAL_OUTPUT_H_
#define _C_LOCAL_OUTPUT_H_

#include "CDataOutputBase.h"
#include "CStaticDataIOWriter.h"


class CLocalOutput : public CDataOutputBase
{
public:
    bool Init(uint64_t ullOutputID);

    bool CanWrite() {return true;}

    bool Output(const CStaticData &Data);

    bool OutputTime(uint32_t ulTime);

    uint64_t GetTrafficCnt()
    {
    	return 0;
    }
    
    emOutputType GetOutputType() {return eTypeIO;}
    
    const uint64_t GetOutputID() {return m_ullOutputID;};
    
    void ResetTrafficCnt() {};
    
    void OutputHeartBeat() {};
    
private:
    CStaticDataIOWriter     m_Writer;
    uint64_t				m_ullOutputID;
    uint32_t 				m_ulLastWriteTime;
};

#endif


