#include "CLocalOutput.h"

extern uint32_t g_ulSystemTime32;
bool CLocalOutput::Init(uint64_t ullOutputID)
{
	m_ullOutputID = ullOutputID;
    return m_Writer.Init(ullOutputID);
}

bool CLocalOutput::Output(const CStaticData & Data)
{
    if(m_Writer.WriteObj(Data))
    {
        //static char s_aszTmp[1024 * 1024];
        //int iRet = Data.SerializeToArray(s_aszTmp, 1024 * 1024);
    	
    	//LOG_INFO("data len = %d", iRet);
    	
    	if(g_ulSystemTime32 != m_ulLastWriteTime)
    	{
    		m_ulLastWriteTime = g_ulSystemTime32;
    		m_Writer.Flush();
    	}
    	//LOG_INFO("write data suc");
    	return true;
    }
    else
    {
    	LOG_ERR("write data failed");
    	return false;
    }
    
}


bool CLocalOutput::OutputTime(uint32_t ulTime)
{
	//LOG_INFO("write timestamp into io, time = %s" , GetFormatTime(ulTime).c_str());
	return m_Writer.WriteTimestamp(ulTime);
}
