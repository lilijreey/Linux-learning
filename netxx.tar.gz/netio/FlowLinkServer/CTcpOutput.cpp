#include "CTcpOutput.h"
#include "CMergeSvrProtocol.h"

extern uint64_t g_ullSystemTime;

CTcpOutput::CTcpOutput()
{
    m_ulSenderTot = 0;
    m_ulLastTime = 0;
    m_ulBufferLen = 0;
    m_ullTrafficCnt = 0;
    m_ulBeforeCom = 0;
    m_ulAfterCom = 0;
    m_ullLastSendTime = 0;
    m_emType = TYPE_SNAPPY;
}

CTcpOutput::~CTcpOutput()
{
    for (uint32_t i = 0; i < m_ulSenderTot; ++i)
    {
        if (m_apSender[i])
        {
            delete m_apSender[i];            
        }
        else
        {
            LOG_ASSERT("Err, sender :%u is null", i);
        }
    }
}

bool CTcpOutput::Init(uint32_t ulIP, uint16_t usPort)
{
    ASSERT_RET(m_ulSenderTot == 0, false);
    
    m_ulIP = ulIP;
    m_usPort = usPort;
    
    m_apSender[0] = new CTcpSender();
    if (!m_apSender[0]->Init(ulIP, usPort, 0, 0))
    {
        LOG_ERR("Err to init sender, %u:%u", ulIP, usPort);
        delete m_apSender[0];
        return false;
    }

    m_ulSenderTot = 1;
    return true;
}

bool CTcpOutput::CanWrite()
{
    for (uint32_t i = 0; i < m_ulSenderTot; ++i)
    {
        if (m_apSender[i]->CanSend())
        {
            return true;
        }
    }

    // �ж��Ƿ���Ҫ�½�һ�����������Ӵ���
    if (m_ulSenderTot >= MAX_TCP_CONNECTION)
    {
    	//LOG_INFO("max conn,cur conn, tot = %u,ID = %u", m_ulSenderTot, m_ullMergeID);
        return false;
    }

    for (uint32_t i = 0; i < m_ulSenderTot; ++i)
    {
        if (m_apSender[i]->GetStatus() != CTcpSender::TCP_CONNECTED)    // �������е����Ӷ�Ϊ TCP_CONNECTED �������½�����
        {
            return false;
        }
    }

    // �½�һ������
    m_apSender[m_ulSenderTot] = new CTcpSender();
    if (!m_apSender[m_ulSenderTot]->Init(m_ulIP, m_usPort, 0, 0))
    {
        LOG_ERR("Err to init sender, %u:%u", m_ulIP, m_usPort);
        delete m_apSender[m_ulSenderTot];
        return false;
    }
    m_ulSenderTot++;
    return false;
}

void CTcpOutput::CheckFlush()
{
	if(m_ulBufferLen > 0 && (g_ullSystemTime - m_ullLastSendTime > 200000 || m_ulBufferLen >= STATIC_DATA_BUFFER_SIZE / 2))
	{
		//LOG_INFO("flush data, last system time = %lu, last send = %lu", g_ullSystemTime, m_ullLastSendTime);
		Flush();
	}
}

void CTcpOutput::Flush()
{
	m_ullLastSendTime = g_ullSystemTime;
	if(m_ulBufferLen > 0)
	{
		if(!Send(m_pBuffer, m_ulBufferLen))
		{
			MyMonitor(MONITOR_FLUSH_DATA_BEFORE_SEND_TIMESTAMP_FAIL);
		}
		m_ulBufferLen = 0;
	}
}

bool CTcpOutput::Send(const void *pPkg, uint32_t ulPkgLen, CTcpSender *pSender)
{
	
	const void *pData = NULL;
	uint32_t ulDataLen = 0;
	
	
	static char s_auComBuffer[MAX_BUF_SIZE];
	size_t ullOutputLen = 0;

	tFlowLinkDataHeader *pComHeader = (tFlowLinkDataHeader *)(s_auComBuffer);
	pComHeader->usSTX = FLOW_LINK_STATICDATA_STX;
	pComHeader->ucHeaderLen = sizeof(tFlowLinkDataHeader);	
	
	if(m_emType == TYPE_SNAPPY)
	{
		snappy::RawCompress((const char *)pPkg, ulPkgLen, s_auComBuffer + sizeof(tFlowLinkDataHeader), (size_t *)&ullOutputLen);
		if(ullOutputLen < ulPkgLen)
		{
			pComHeader->ucCompressBit = TYPE_SNAPPY;
			pComHeader->ulLen = ullOutputLen + sizeof(tFlowLinkDataHeader);
		}
		else
		{
			ASSERT_RET(ulPkgLen < MAX_BUF_SIZE - sizeof(tFlowLinkDataHeader), false);
			memcpy(s_auComBuffer + sizeof(tFlowLinkDataHeader), pPkg, ulPkgLen);
			pComHeader->ucCompressBit = TYPE_NOT_COMPRESS;
			pComHeader->ulLen = ulPkgLen + sizeof(tFlowLinkDataHeader);
		}
	}
	else if(m_emType == TYPE_NOT_COMPRESS)
	{
		ASSERT_RET(ulPkgLen < MAX_BUF_SIZE - sizeof(tFlowLinkDataHeader), false);
		memcpy(s_auComBuffer + sizeof(tFlowLinkDataHeader), pPkg, ulPkgLen);
		pComHeader->ucCompressBit = TYPE_NOT_COMPRESS;
		pComHeader->ulLen = ulPkgLen + sizeof(tFlowLinkDataHeader);
	}

	
	pData = s_auComBuffer;
	ulDataLen = pComHeader->ulLen;	//���ü���ͷ���Ѿ���ȫ��������

	//LOG_INFO("dataCompress before = %u, after = %u", ulPkgLen, ulDataLen);
    if (pSender == NULL)
    {
        // ʼ��ѡ��һ�� BUFFER ���ķ���
        uint32_t ulBestBufferSize = 0;
        for (uint32_t i = 0; i < m_ulSenderTot; ++i)
        {
            if (m_apSender[i]->GetStatus() == CTcpSender::TCP_CONNECTED 
                && m_apSender[i]->GetBufferSpace() > ulBestBufferSize)
            {
                ulBestBufferSize = m_apSender[i]->GetBufferSpace();
                pSender = m_apSender[i];
            }
        }

        if (NULL == pSender || ulBestBufferSize < ulPkgLen)
        {
            MyMonitor(MONITOR_TCP_SEND_ERR);
            return false;
        }
    }
	
    ASSERT_RET(pSender->SendData((const uint8_t *)pData, ulDataLen), false);
    m_ullTrafficCnt += ulDataLen;
    
    m_ulBeforeCom += ulPkgLen;
    m_ulAfterCom += ulDataLen;
    
//    if(m_ulBeforeCom > BLOCK_SIZE)
//    {
//    	m_ulBeforeCom -= BLOCK_SIZE;
//    	MyMonitor(MONITOR_OUTPUT_DATA_BEFORE_COMPRESS);
//    }
//    
//    if(m_ulAfterCom > BLOCK_SIZE)
//    {
//    	m_ulAfterCom -= BLOCK_SIZE;
//    	MyMonitor(MONITOR_OUTPUT_DATA_AFTER_COMPRESS);
//    }
//    
    
    return true;
}


bool CTcpOutput::OutputData(const char *pData, uint32_t ulLen, emCompressType emType)
{
	m_emType = emType;
	
	if(m_ullSendBytes >= 1048576)
	{
		Attr_API(ATTR_FLOW_LINK_SEND_MILLION_BYTES, m_ullSendBytes / 1048576);
		m_ullSendBytes = m_ullSendBytes % 1048576;
	}
	
	if(ulLen <= sizeof(m_pBuffer) - m_ulBufferLen)
	{
		memcpy(m_pBuffer + m_ulBufferLen, pData, ulLen);
		m_ulBufferLen += ulLen;
		m_ullSendBytes += ulLen;
		return true;
	}
	else
	{
		Flush();
	}
	
	if(ulLen <= sizeof(m_pBuffer) - m_ulBufferLen)
	{
		memcpy(m_pBuffer + m_ulBufferLen, pData, ulLen);
		m_ulBufferLen += ulLen;
		m_ullSendBytes += ulLen;
		return true;
	}
	else
	{
    	MyMonitor(MONITOR_DISCARD_LARGE_PKG);
		LOG_ERR("pack too large , drop it");
		return false;
	}


    return true;
}


/*
bool CTcpOutput::OutputTime(uint64_t ullMergeID, uint32_t ulTime, CTcpSender *pObj)
{
	LOG_INFO("tcp send timestamp, mergeid = %llu, time = %u", ullMergeID, ulTime);
	    
	m_ulLastTime = ulTime;
    m_ullMergeID = ullMergeID;
    m_stTime.ulTimestamp = ulTime;

    const char *pPkg = (const char *)&m_stTime;
    uint32_t ulPkgLen = sizeof(m_stTime);

    if (pObj)
    {
        return Send(pPkg, ulPkgLen, pObj);
    }
    
    //�����flush��������²����������ΪҪ�յ�ʱ����������ڵ�ǰbucket�����ݶ������꣬
    //��bucket���ݱ�������ǰ����tcpsender������һ������write������Ӧflush�ܳɹ�,�������ܶѵ�tcpsender�Ļ������flushʧ�ܻ���ջ�����
    Flush();

    bool bRet = true;
    for (uint32_t i = 0; i < m_ulSenderTot; ++i)
    {
        if (m_apSender[i]->GetStatus() == CTcpSender::TCP_CONNECTED)
        {
            if (!Send(pPkg, ulPkgLen, m_apSender[i]))
            {
                LOG_ERR("Err to send time, merge id:%llu, time:%u, i:%u", ullMergeID, ulTime, i);
                MyMonitor(MONITOR_SEND_TIMESTAMP_FAIL);
                bRet = false;
            }
        }
        else
        {
        	//�����һ��bucket��ΪҪ���ͱȽ϶�����ݶ��½������ӣ��ڼ���bucketû�������ݺ���ܻᱻ�Զ˹ر�
        	//�����������ǿ��check cansend�ᵼ���ֽ����˿����ӣ�����ֻ����һ������
        	if(i == 0)	
        	{
        		m_apSender[i]->CanSend();	//��tcpsend���������ӣ�������ӿ��Դ���notifyconnect�������ͷ.
        	}
        }
        
    }
    
    return bRet;
}
*/


void CTcpOutput::HandleLoop()
{
    for (uint32_t i = 0; i < m_ulSenderTot; ++i)
    {
        ASSERT_RET(m_apSender[i]);
        m_apSender[i]->HandleLoop();
    }
}


