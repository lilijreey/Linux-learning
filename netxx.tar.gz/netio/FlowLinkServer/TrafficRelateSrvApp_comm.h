/*
 * CTrafficSrvApp_comm.h
 *
 *  Created on: 2017��3��30��
 *      Author: stanzeng
 */

#ifndef TRUNK_DEV_TRAFFICRELATE_TRAFFICRELATESRVAPP_COMM_H_
#define TRUNK_DEV_TRAFFICRELATE_TRAFFICRELATESRVAPP_COMM_H_
#include <fcntl.h>
#include <unistd.h>
#include <stdint.h>
#include <errno.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string>
#include <vector>
#include <set>
#include <sys/time.h>
#include "CCenterServerInfo.h"
#include "ASSERT.h"
#include "MonitorAttr.h"
#include "CStaticData.h"
#include "log.h"
#include "CLruHashTable.h"
#include "FlowLinkProtoDef.h"
#include "CStaticDataIOReader.h"
#include "CommUtils.h"
#include "ProtocolFieldDef.h"
#include "Attr_API.h"
#include <algorithm>
#include "CommUtils.h"

using namespace std;
using namespace ARGUS;

// ������������Ŀ
const char *const CONF_BLOCK_COMM = "COMMON";
const char *const   CONF_ITEM_LOCAL_CONFIG_FILE="local_config";

const char *const CONF_BLOCK_LOCAL_SERVER = "LOCAL_SERVER";
const char *const CONF_BLOCK_OUTER_SERVER = "OUTER_SERVER";

#define IN_HTTP_STREAM_IO_ID  (9LL << 32)
#define OUT_HTTP_STREAM_IO_ID (10LL << 32)
#define IN_HTTP_RSP_STREAM_IO_ID  (11LL << 32)
#define OUT_HTTP_RSP_STREAM_IO_ID (12LL << 32)



#pragma pack(1)

struct SHashDataHead
{
	uint64_t ullTotalSize;
	uint32_t ulBlockCount;
	uint32_t ulBlockDataLen;
};

struct SHashDataBlockInfo
{
	uint64_t ullWritePos;
	uint64_t ullReadPos;
	char szData[0];
};

struct SHashData
{
	uint64_t key;	
	uint64_t ullTime;
	
	CStaticDataIOReader *pIOReader;
    CStaticDataIOReader::tStaticDataPointer dataPointer;
	uint32_t ulDir;		//0���������ģ�1������
	//const void *pData;
	//uint32_t ulDataLen;		//���ݳ���
	//uint64_t ullLastAddress;	//���һ�ζ����ݵĵ�ַ�����������жϸõ�ַ�Ƿ���Ч
};

#pragma pack()

enum EM_TRAFFIC_BIT
{
	EM_TRAFFIC_UNKNOW = 0,
	EM_TRAFFIC_IN = 1,
	EM_TRAFFIC_OUT = 2,
};


static CLruHashTable<SHashData, uint64_t> g_cHashTable;

const uint32_t HASH_DATA_KEY = 20170413; 
const uint32_t BLOCK_KEY_SIZE = 300000;	 // 300000 * 20Byte = 6000000 = 6M  
const uint32_t BLOCK_DATA_SIZE = sizeof(SHashDataBlockInfo) + BLOCK_KEY_SIZE * sizeof(SHashData);


inline string GetFormatTime(time_t ulTime)
{
	char szTmp[128] = {0};
	struct tm *t = localtime(&ulTime);
	if(t != NULL)
	{
		snprintf(szTmp, sizeof(szTmp), "%d-%02d-%02d %02d:%02d:%02d", 
				t->tm_year + 1900, t->tm_mon + 1, t->tm_mday, 
				t->tm_hour, t->tm_min, t->tm_sec);
	}
	return string(szTmp);
}


inline static const string HashToAddr(uint64_t ullHash) 
{
	static string s_sAddr;
	in_addr in;
	in.s_addr = htonl(ullHash >> 32);
	
	return string(inet_ntoa(in)) + ":" + UintToString(ullHash & 0xffffffff); 
}

struct AcNode
{
	AcNode* next[256];
	AcNode* fail;
	bool bIsLeaf;
	AcNode()
	{
		memset(next, 0 , sizeof next);
		fail = NULL;
		bIsLeaf = false;
	}
};


class CSuffixFind
{
public:
	CSuffixFind()
	{
		m_root = NULL; 
	}
	
	AcNode* AllocNode()
	{
		AcNode* pNode = new AcNode();
		m_vAlloc.push_back(pNode);
		return pNode;
	}
	
	bool Insert(const string& sValue)
	{
		m_root = AllocNode();
		
		string sCur = sValue.c_str();
		transform(sCur.begin(), sCur.end(), sCur.begin(), ::tolower);		//�����ִ�Сд
		vector<string> vecEdgeList;
		SplitString(sCur, vecEdgeList);
		
		for(uint32_t ulIdx = 0 ; ulIdx < vecEdgeList.size(); ++ulIdx)
		{
			AcNode *cur = m_root;
			string sContext = vecEdgeList[ulIdx];
			
			reverse(sContext.begin(), sContext.end());		//��׺������
			for(uint32_t i = 0 ; i < sContext.length() ; ++i)
			{
				uint8_t uIndex = (uint8_t)sContext[i];
				
				if(cur->next[uIndex] == NULL)
				{
					cur->next[uIndex] = AllocNode();
				}
				
				//uIndex��Сд��ĸ���Ѵ�д��ĸ��nextҲ��ֵ
				if(uIndex >= 97 && uIndex <= 122)
				{
					if(cur->next[uIndex - 32] == NULL)
					{
						cur->next[uIndex - 32] = cur->next[uIndex]; 
					}				
				}			
				
				cur = cur->next[uIndex];
			}
			cur->bIsLeaf = true;
		}
		
		return true;
	}
	
	bool Search(const string& strValue)
	{
		AcNode *pCur = m_root;
		int32_t iKeyLen = strValue.length();
		uint8_t uIndex = 0;
		
		for(int32_t iIdx = iKeyLen - 1 ; iIdx >= 0; --iIdx)
		{
			uIndex = uint8_t(strValue[iIdx]);
			
			if(pCur->next[uIndex] != NULL)
			{
				pCur = pCur->next[uIndex];
				if(pCur->bIsLeaf)
				{
					return true;
				}
			}
			else
			{
				return false;
			}
		}		
		return true;
	}
	
	//�ַ���ƥ�����˻���ƥ�䵽 sStop�˲�ͣ
	bool SearchExt(const string& strValue, char sStop = '.')
	{
		AcNode *pCur = m_root;
		int32_t iKeyLen = strValue.length();
		uint8_t uIndex = 0;
		
		for(int32_t iIdx = iKeyLen - 1 ; iIdx >= 0; --iIdx)
		{
			uIndex = uint8_t(strValue[iIdx]);
			
			if(pCur->next[uIndex] != NULL)
			{
				pCur = pCur->next[uIndex];
				if(pCur->bIsLeaf && (iIdx == 0 || strValue[iIdx] == '.'))	
				{
					return true;
				}
			}
			else
			{
				return false;
			}
		}
		return false;
	}
	
	
	~CSuffixFind()
	{
		for(uint32_t i = 0 ; i < m_vAlloc.size() ; i ++)
		{
			if(m_vAlloc[i])
			{
				delete m_vAlloc[i];
			}
			m_vAlloc[i] = NULL;
		}
	}
private:
    AcNode* m_root;
    vector<AcNode *> m_vAlloc;
};



#endif /* TRUNK_DEV_TRAFFICRELATE_TRAFFICRELATESRVAPP_COMM_H_ */
