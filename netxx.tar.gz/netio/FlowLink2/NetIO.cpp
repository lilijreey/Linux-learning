
//#include "CommUtils.h"
#include "NetIO.h"

//全部基于nonblock 模式, 水平触发

ssize_t NetRecv(int sockfd, void *buf, size_t len, size_t &recvLen, int flags)
{
    recvLen = 0;
    while (recvLen < len)
    {
        ssize_t ret = recv(sockfd, (char*)buf+recvLen, len-recvLen, flags);
        if (ret > 0)
        {
            recvLen += ret;
        } 
        else if (ret == -1)
        {
            if (errno == EAGAIN || errno == EWOULDBLOCK)
                return 1;
            if (errno == EINTR)
                continue;

            return -1;
        }
        else
        {
            LOG_DBG("fd %d  recv 0 ret:%ld", sockfd, ret);
            //(ret == 0)
            return 0;
        }
    }
    return 1;
}

int Listen(const std::string &ip, uint16_t port, int sockopt)
{
    sockaddr_in addr;
    Bzero(addr);

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    int ret =
    inet_pton(AF_INET, ip.c_str(), &(addr.sin_addr.s_addr));
    if (ret <= 0)
    {
        LOG_ERR("parse ip %s failed %s", ip.c_str(), ret == 0 ? "Not in presentaion format " : ErrnoStr);
        return -1;
    }


    int listenFd = socket(AF_INET, SOCK_STREAM, 0);
    if (-1 == listenFd)
    {
        LOG_ERR("create socket failed %s", ErrnoStr);
        return -1;
    }

    int opt =1;
    if (-1 == setsockopt(listenFd, SOL_SOCKET,  SO_REUSEADDR | sockopt, &opt, sizeof(opt)))
    {
        LOG_ERR("setsockopt fd %d failed %s", listenFd, ErrnoStr);
        close(listenFd);
        return -1;
    }


    if (-1 == bind(listenFd, (sockaddr*)&addr, sizeof(addr)))
    {
        LOG_ERR("bind %s %d failed %s", ip.c_str(), port, ErrnoStr);
        close(listenFd);
        return -1;
    }

    if (-1 == listen(listenFd, 10))
    {
        LOG_ERR("bind %s %d failed %s", ip.c_str(), port, ErrnoStr);
        close(listenFd);
        return -1;
    }

    LOG_INFO("listen %s %d successed", ip.c_str(), port);

    return listenFd;
}

int Accept(int listenFd, sockaddr *addr, socklen_t *addrlen)
{
again:
    int ret = accept4(listenFd, addr, addrlen, SOCK_NONBLOCK);
    if (-1 == ret )
    {
        if (errno == EAGAIN || errno == EWOULDBLOCK)
            return -1;
        if (errno == EINTR)
            goto again;
        return -1;
    }

    LOG_DBG("accept new fd %d", ret);
    return ret;
}




CEpoll::CEpoll(int maxevents)
    :m_maxevents(maxevents)
{
    m_epfd = epoll_create1(0);
    if (-1 == m_epfd)
    {
        LOG_ERR("epoll_create1 failed %s", ErrnoStr);
        return;
    }
    m_events = (epoll_event*)malloc(m_maxevents * sizeof(epoll_event));
}

CEpoll::~CEpoll()
{
    CloseAllFd();
    if (IsOpen())
    {
        free(m_events);
        m_events=nullptr;
        close(m_epfd);
    }
}

bool CEpoll::RemoveFd(int fd)
{
    auto it = m_watchers.find(fd);
    if (it == m_watchers.end())
    {
        LOG_ERR("can not find fd %d", fd);
        return false;
    }
    m_watchers.erase(it);

    epoll_event _ev;//2.6.9 before need
    if (-1 == epoll_ctl(m_epfd, EPOLL_CTL_DEL, fd, &_ev))
    {
        LOG_ERR("epoll del fd %d failed %s", fd, ErrnoStr);
    }
    return true;
}

bool CEpoll::AddFd(int fd, int event, const EvHandler& cb)
{
    if (IsExistFd(fd))
    {
        LOG_ERR("listener %d alreay exist", fd);
        return true;
    }

    if (IsBlockingFd(fd))
    {
        if (not SetSocketNonbockable(fd, true))
        {
            LOG_ERR("fd %d not canot set nonblocking %s", fd, ErrnoStr);
            return false;
        }
    }


    epoll_event ev;
    ev.events = event;
    EvWatcher *watcher = new EvWatcher(fd, cb);
    ev.data.ptr = watcher;

    if (-1 == epoll_ctl(m_epfd, EPOLL_CTL_ADD, fd, &ev))
    {
        LOG_ERR("epoll add fd %d failed %s", fd, ErrnoStr);
        return false;
    }

    m_watchers[fd] = watcher;

    LOG_DBG("add fd %d ok", fd);
    return true;
}

bool CEpoll::Wait(int timeout)
{
    const int fds = epoll_wait(m_epfd, m_events, m_maxevents, timeout);
    //if (unlikey(fds == -1)) //XXX
    if (fds == -1)
    {
        return false;
    }

    for (int i =0; i < fds; ++i)
    {
        EvWatcher* watcher = (EvWatcher*)(m_events[i].data.ptr);
        if (not watcher->evHandler(this, watcher->fd, m_events[i].events))
        { //close fd
            const int fd = watcher->fd;
            LOG_DBG("ev handle return false, close fd %d", fd);
            RemoveFd(fd);
            close(fd);
        }

        //TODO check return
    }

    return true;
}
