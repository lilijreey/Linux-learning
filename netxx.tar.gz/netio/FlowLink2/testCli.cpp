
#include <stdio.h>
#include <assert.h>
#include "NetIO.h"

bool HandleEv(CEpoll *epoll, const int fd, const int events)
{
    if (CEpoll::IsErrEv(events))
    {
        int err = GetSocketErr(fd);
        printf("conn %d has a error %d %s, close it\n", fd, err, strerror(err));
        return false;
    }

    if (events & EPOLLOUT)
    {
        printf("write able todo.. \n");

    }

    if (events & EPOLLIN)
    {
        char buf[215];
        size_t recvLen =0;
        int ret = NetRecv(fd, buf, 214, recvLen);
        if (ret <= 0)
        {
            printf("socket %d close by peer ret:%d, cloes it", fd, ret);
            return false;
        }

        buf[recvLen] = '\0';
        printf("fd %d recv %lu:%s\n", fd, recvLen, buf);
    }
    return true;

}

int main(int argc, char *argv[])
{
    int fd = TcpSocket("127.0.0.1", 3345);
    assert(SetSocketNonbockable

    
    return 0;
}
