
#include <stdio.h>
#include <assert.h>
#include "NetIO.h"

bool HandleEv(CEpoll *epoll, const int fd, const int events)
{
    if (CEpoll::IsErrEv(events))
    {
        int err = GetSocketErr(fd);
        printf("conn %d has a error %d %s, close it\n", fd, err, strerror(err));
        return false;
    }

    if (events & EPOLLOUT)
    {
        printf("write able todo.. \n");

    }

    if (events & EPOLLIN)
    {
        char buf[215];
        size_t recvLen =0;
        int ret = NetRecv(fd, buf, 214, recvLen);
        if (ret <= 0)
        {
            printf("socket %d close by peer ret:%d, cloes it", fd, ret);
            return false;
        }

        buf[recvLen] = '\0';
        printf("fd %d recv %lu:%s\n", fd, recvLen, buf);
    }
    return true;

}


int main(int argc, char *argv[])
{
    CEpoll epoll(32);

    assert(epoll.IsOpen());

    int fd = Listen("127.0.0.1", 3345);
    assert(fd != -1);
    int ret =
    epoll.AddReadFd(fd, 
                  [](CEpoll *epoll, const int listenFd, const int events)
                  {
                  printf("listen fd %d event %d\n", listenFd, events);
                  if (CEpoll::IsErrEv(events))
                  {
                  int err = GetSocketErr(listenFd);
                  printf("socket %d has a error %d %s, close it\n", listenFd, err, strerror(err));
                  return false;
                  }

                  int conn = Accept(listenFd);
                  if (conn == 0) return true;
                  if (conn == -1)
                  {
                      printf("accept fd %d failed %s\n", listenFd, ErrnoStr);
                      return true;
                  }


                  printf("accept new conn fd %d\n", conn);

                  epoll->AddReadFd(conn, HandleEv);
                  return true;
                  });
    if (ret == -1)
    {
        perror("AddReadFile failed");
        return 0;
    }



    printf("\nstart wait\n");
    while(true)
    {
        printf("wait again\n");
        epoll.Wait(-1);
    }

    return 0;
}
