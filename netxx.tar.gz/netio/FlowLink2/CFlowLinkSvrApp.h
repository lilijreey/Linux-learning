/**
 * @file     同宿同源机房出入流量关联Server
 *           
 *
 * @author   akozhao
 * @date     2018年04月13日 14时57分02秒
 *
 */

#pragma once

#include "CommUtils.h"
#include "CSimpleApp.h"
#include "TimeTrigger.h"

#if __cplusplus < 201103L
#define override //兼容c++98
#endif


class CLocalLinker;

//全局单例

class CFlowLinkSvrApp : public CSimpleApp
{
public:
    //框架回调
	virtual bool InitServer() override;
	virtual bool HandleLoop(void) override;

    enum { //处理的流量方向
        DIR_IN = 0,
        DIR_OUT = 1,
        DIR_END,

        MAX_LINKER_CNT = 20,
    };


    ~CFlowLinkSvrApp()
    {
        ClearLinker();
    }
private:
    bool InitIO();
    bool InitLinker();
    void ClearLinker();


    int m_linkerCnt =0;
    int m_IoCnt =0; //总共的IO数量
    int m_processCnt =0; //总共有几个进程
    int m_dir ;
    vector<CLocalLinker*> m_linkers;
    CIdcLinker m_idcLinker;

};


extern CFlowLinkSvrApp g_FlowLinkSrvApp;
extern uint32_t g_nowSec32;
extern uint64_t g_nowMsec64;
