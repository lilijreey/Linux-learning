/**
 * @file     实现周期性调用功能
 *           
 *
 * @author   akozhao
 * @date     2018年04月13日 19时58分23秒
 *
 */

#ifndef  TIMETRIGGER_H
#define  TIMETRIGGER_H

#include <stdint.h>
#include <stdio.h>
#include <vector>

namespace ARGS
{


/* how to use:
   <pre>
   struct App{
     int count=0;
     void IncCount() {
       ++count;
     }
   };
   App app;
  
   //每五秒调用一次app::IncCount
   
   TimeTrigger<App> timer;
   1. 
   timer.Reg(&app, &App::IncCount, 5); //注册
   timer.Check(now());
  
   2. 使用lambda
   timer.Reg([&app]() { app.IncCount(); }); //注册
   timer.Check(now());

   <pre>
  
 */
template <typename T>
class IntervalTimer
{
 public:
    typedef void (T::*Fn)(void);

    struct Node
    {
        Fn fn;
        T *pObj;
        uint32_t interval; //sec
        uint32_t lastCallTime;
    };


    void Reg(T *obj, Fn fn, uint32_t interval)
    {
        if (interval == 0)
            return ;
        Node n;
        n.pObj = obj;
        n.fn = fn;
        n.interval = interval;
        n.lastCallTIme = 0;

        m_nodes.push_back(n);
    }


#if __pluslplus > _2011
    void Reg(std::function<void(void)>, uint32_t interval)
    {
        if (interval == 0)
            return ;
        Node n;
        n.pObj = nullptr;
        n.fn = fn;
        n.interval = interval;
        n.lastCallTIme = 0;
        m_nodes.push_back(n);
    }
#endif

    //remove all register
    void Clear()
    {
        m_nodes.clear();
    }

    //TODO UnReg()

    void Check(uint32_t time)
    {
        for (size_t i=0; i< m_nodes.size(); ++i)
        {
            Node &n = m_nodes[i];
            if (n.lastCallTIme + n.interval <= time)
            {
                if (n.pObj)
                {
                    (n.pObj->*n.fn)();
                }
                else
                {
                    n.fn();
                }
                n.lastCallTIme = time;
            }
        }
    }

 private:
    std::vector<Node> m_nodes;

};

} //end namespace

#endif   /* ----- #ifndef TIMETRIGGER_H ----- */
