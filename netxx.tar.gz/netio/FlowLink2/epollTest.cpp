
class Accepter : EpollListenerHandler
{
    HandleNewConnect(eng, socket, *arg);
    {
        eng.AttachTcpConnect(socket, EV_READ | EV_WRITE, connect);
        fd = eng.NewTcpConnect(ipv4(3,4,2,1), port, timeout);

    }

    HandleError();

};


int main(int argc, char *argv[])
{
    Epoll eng;
    //ipv4("fjeof");
    eng.getOption().setNonblock(true);

    int fd = eng.newListener("1234", 324, Accepter, NULL);



    try_catch 
    {
        eng.destroyListener(int);
    }




    
    return 0;

struct Socket
{
    SetNonblocking(bool)
    int _fd;
};

struct Result<T,E>
{
    isNone();
    isSome();
    isError();
    assertOk(); ->T;
    get

};
