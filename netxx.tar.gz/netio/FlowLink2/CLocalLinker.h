/**
 * @file     在本机流量中查找关联数据。
 *           读取偏移量相同的HTTP_REQ,HTTP_RSP IO通道数据，
 *           然后进行关联,把关联上的数据写入对应的FLOW_LINK IO
 *           @note 这种方案依赖于同宿同源网络分发，RecvServer
 *           使用对称哈希保证同宿同源数据落入偏移量相同的IO.
 *
 *           HTTP_REQ_IO[n]
 *                         \ 
 *                           关联 ---> FLOW_LINK_IO[n]
 *                         /
 *           HTTP_RSP_IO[n]
 *           
 *
 * @author   akozhao
 * @date     2018年04月13
 *
 */

#pragma once

#include "CommUtils.h"
#include "CStaticDataIOWriter.h"
#include "CStaticDataIOReader.h"
#include "TimeTrigger.h"
#include "MultiStageMapMT.h"
#include "CLruHashTable.h"
#include <unordered_map>


#define _always_inline_ __attribute__((always_inline)) 

struct MatchInfo  //HTTP 五元组key
{
    MatchInfo(const CStaticData&, int _type)
    {
        key = 0;
        for(uint32_t i = 0 ; i < 5; ++i)
        {
            uint64_t data = stData.ReadUint(i);
            key = XXH64(data, sizeof(data), key);
        }
        type = _type;
        time = g_nowSec32;
    }

    //void SetKey(uint64_t k) _always_inline_ {key=k;} 
    //uint64_t GetKey() const _always_inline_ { return key;}
    bool IsMatch(const MatchInfo& o) _always_inline_
    {
        return type != o.type;
    }

    uint64_t key; 
    uint32_t type; //REQ/RSP
    uint32_t time; //创建时间
    CStaticDataIOReader::tStaticDataPointer pointer; //StaticData地址
};



void SendMatcheInfo(const MatchInfo &hashData)
{
    GetConnect(matchInfo.key).send(matchInfo);
}

//static uint64_t CalcHashKey(const CStaticData &stData)
//{
//    uint64_t hash = 0;
//    for(uint32_t i = 0 ; i < 5; ++i)
//    {
//        uint64_t data = stData.ReadUint(i);
//        hash = XXH64(data, sizeof(data), hash);
//    }
    
//    return hash;
//}




using namespace ::IO_NAMESPACE;
class CLocalLinker
{
 public:
  CLocalLinker()
  {
      m_reqIoBaseId=0;
      m_rspIoBaseId=0;
      m_outIoBaseId=0;
      m_offset=-1;

      Bzero(m_cnt); //TODO
      m_outFailCnt = 0;
  }
  ~CLocalLinker();


  bool Init(uint64_t reqIOBase, uint64_t rspIOBase, uint64_t outIOBase, int ioOffset, int dir);
  uint32_t HandleLoop();


private:
    uint32_t ReadIoAndMatch(const int ioType); //RSQ or RSP
    void OutFlowLinkData(const MatchInfo &req, const MatchInfo &rsp);

    inline static bool MatchInfoKickedOut(const MatchInfo &l, const MatchInfo &r) __attribute__((always_inline))
    {
        return l.time <= r.time;
    }

    void WriteTimestamp();

    HttpReader 
    CStaticDataIOReader     m_hashReader[2]; //in <- IO, req,rsp
    CStaticDataIOWriter     m_flowLinkWriter;//out -> IO

    CStaticData             m_httpData[2];//req,rsp
    CStaticData             m_flowLinkData;

    uint64_t				m_reqIoBaseId;
    uint64_t				m_rspIoBaseId;
    uint64_t				m_outIoBaseId;
    int                     m_offset;
    int                     m_dir; //DIR_IN or DIR_OUT

    enum {
        LINK_TABLE_SIZE = 400000, //最大处理速度=一个IO通道每秒10W包 * 3秒,也就是说一个包平均有3秒的时间来关联
        REQ=0, //不要改变值
        RSP=1,
        BUF_SIZE = (8 << 20),

        //统计数据类型
        READ_CNT=0, //IO中staticData的数量
        MATCH_CNT, //匹配的数量
        SAME_CNT, //完全一致的数量
        KICKEDOUT_CNT, //被踢出的数量
        READ_FAIL_CNT, //读取IO staticData失败
        PARSE_FAIL_CNT, //解析staticData失败
        CNT_SIZE
    };


    typedef MultiStageMap<uint64_t, MatchInfo, LINK_TABLE_SIZE, 12>  LinkTable;
    LinkTable               m_linkTable;

    TimeTrigger<CLocalLinker> m_intervalFn;

    char     m_buf[BUF_SIZE]; 

    //统计数据
    static uint32_t m_cnt[2][CNT_SIZE]; //2 REQ + RSP 两个方向
    uint32_t m_outFailCnt;
};

