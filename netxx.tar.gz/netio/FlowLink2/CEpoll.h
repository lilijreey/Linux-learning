/*
 * 实现基于epoll的网络通讯功能
 */


//Listener
//Connect
//Epoll.seta

epoll.newListener
epoll.getListener
epoll.deleteListener
epoll.attachListener
epoll.detachListener

epoll.newTcpConnect
epoll.getTcpConnect
epoll.deleteTcpConnect
epoll.attachTcpConnect
epoll.detachTcpConnect



EpollTcpConnect *
EpollListener *

