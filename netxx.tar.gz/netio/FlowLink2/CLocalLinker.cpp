/**
 * @file     CLocalLinker.c
 *           
 *
 * @date     2018年04月13日 16时48分38秒
 *
 */
#include "CLocalLinker.h"
#include "NameHash.h"
#include "ProtocolFieldDef.h"
#include "CFlowLinkSvrApp.h"

#include <vector>

using namespace ::ARGUS;

static uint32_t s_testCnt;

uint32_t CLocalLinker::m_cnt[2][CNT_SIZE]; //2 REQ + RSP 两个方向


static void ShowData(const CStaticData &stData)
{
    fputs("{\n", stdout);
    //for (uint32_t i = 0; i < stData.GetFieldTot(); ++i)
I   //{
    //    fprintf(stdout, "\tField%u:", i);
    //    switch (stData.GetFieldType(i))
    //    {
    //        case EXP_UINT:
    //            fprintf(stdout, "\t%lu", stData.ReadUint(i));
    //            break;
    //        case EXP_INT:
    //            fprintf(stdout, "\t%ld", stData.ReadInt(i));
    //            break;
    //        case EXP_DOUBLE:
    //            fprintf(stdout, "\t%lf", stData.ReadDouble(i));
    //            break;
    //        case EXP_STRING:
    //            fprintf(stdout, "\t\"%s\"", stData.ReadString(i).c_str());
    //            break;
    //        case EXP_IOSTRING:
    //            fprintf(stdout, "\t\"%s\"", stData.ReadIOString(i).c_str());
    //            break;
    //        default:
    //            LOG_ERR("Err: Unknown field type!\n");
    //            return;
    //    }
    //    fputc('\n', stdout);
    //}
    //fputs("}\n", stdout);

}



//四元组 + SEQ
static const char * const HTTP_REQ_HASH_FIELDS[] = 
{
    "src.ip",
    "dst.ip",
    "src.port",
    "dst.port",
    "http.ack",
};

static const char * const HTTP_RSP_HASH_FIELDS[] =
{	
    "dst.ip", //注意这里已经调换dst和src位置，保证hash正确性
    "src.ip",
    "dst.port",
    "src.port",
    "httprsp.seq",
};

static const int HTTP_HASH_FILED_SIZE = 5;






static bool InitReader(CStaticDataIOReader &reader, uint64_t ioId,
                       const char * const ioFieldName[], 
                       const emExpType ioFieldType[],
                       const int ioFieldCnt,
                       const char * const hashFieldName[])
{
    if (not reader.Init(ioId))
    {
        LOG_ERR("init io reader %lu failed", ioId);
        return false;
    }

	CStaticData::tFieldSelector selector;
	vector<CStaticData::tFieldSelector> selectors;
	vector<emExpType> fieldTypes;

    for (int keyIdx = 0; keyIdx < HTTP_HASH_FILED_SIZE; ++keyIdx)
    {
        for (int ioIdx =0; ioIdx < ioFieldCnt; ++ioIdx)
        {
            if(strcmp(ioFieldName[ioIdx], hashFieldName[keyIdx]) == 0)
            {
                selector.ulSrcID = ioIdx;
                selector.ulDstID = keyIdx;

                selectors.push_back(selector);
                fieldTypes.push_back(ioFieldType[ioIdx]);
                break;
            }
        }
    }

    ASSERT_RET(selectors.size() == HTTP_HASH_FILED_SIZE, false);
    reader.SetForceFieldType(fieldTypes);
    reader.SetSelector(selectors);

    return true;

}

bool CLocalLinker::Init(uint64_t reqIOBase, uint64_t rspIOBase, uint64_t outIOBase, int ioOffset, int dir)
{
    //1
    if (not InitReader(m_hashReader[REQ],reqIOBase+ioOffset, HTTP_FLD_NAME, HTTP_FLD_TYPE, HTTP_FLD_END, HTTP_REQ_HASH_FIELDS))
    {
        LOG_ERR("init reqHashReader failed io:%lu offset:%d", reqIOBase+ioOffset, ioOffset);
        return false;
    }
			
    //2
    if (not InitReader(m_hashReader[RSP], rspIOBase+ioOffset, HTTP_RSP_FLD_NAME, HTTP_RSP_FLD_TYPE, HTTP_RSP_FLD_END, HTTP_RSP_HASH_FIELDS))
    {
        LOG_ERR("init rspHashReader failed io:%lu offset:%d", rspIOBase+ioOffset, ioOffset);
        return false;
    }
		
    //3
    if (not m_flowLinkWriter.Init(outIOBase + ioOffset))
    {
        LOG_ERR("out writer init failed io:%lu offset:%d", outIOBase+ioOffset, ioOffset);
        return false;
    }


    //4, init StaticData type
	vector<emExpType> reqTypes, rspTypes, flowLinkTypes;
    for(uint32_t i = 0 ; i < HTTP_FLD_END ; ++i)
    {
        emExpType type = HTTP_FLD_TYPE[i];
        flowLinkTypes.push_back(type);

        if (type == EXP_IOSTRING) 
            type = EXP_STRING;// 需要把IO_STRING替换成STRING才能在ParseFromArray函数解析成功

        reqTypes.push_back(type);
    }
    for(uint32_t i = 0 ; i < HTTP_RSP_FLD_END; ++i)
    {
        emExpType type = HTTP_RSP_FLD_TYPE[i];
        flowLinkTypes.push_back(type);

        if (type == EXP_IOSTRING) 
            type = EXP_STRING;// 需要把IO_STRING替换成STRING才能在ParseFromArray函数解析成功
        rspTypes.push_back(type);
    }
    ASSERT_RET(m_httpData[REQ].InitField(reqTypes), false);		
    ASSERT_RET(m_httpData[RSP].InitField(rspTypes), false);		
    ASSERT_RET(m_flowLinkData.InitField(flowLinkTypes), false);		

    //5
    m_intervalFn.Reg(this, &CLocalLinker::WriteTimestamp, 1);

    m_reqIoBaseId = reqIOBase;
    m_rspIoBaseId = rspIOBase;
    m_outIoBaseId = outIOBase;
    m_offset = ioOffset;
    m_dir = dir;

    LOG_INFO("linker init successed offset %d", m_offset);
    return true;
}

void CLocalLinker::WriteTimestamp()
{
    LOG_INFO("[%d:%s] %u, read:%u req:%u rsp%u, match:%u reqMatch:%u rspMatch:%u reqKOutCnt:%u, rspKOutCnt:%u reqSame:%u, rspSame:%u reqReadFail:%u, rspReadFail:%u, reqParseFail:%u, rspParseFail:%u, outFail:%u, tableSize:%lu", 
             m_offset,
             m_dir == CFlowLinkSvrApp::DIR_IN? "IN":"OUT",
             s_testCnt,
             m_cnt[REQ][READ_CNT] + m_cnt[RSP][READ_CNT], m_cnt[REQ][READ_CNT], m_cnt[RSP][READ_CNT],
             m_cnt[REQ][MATCH_CNT]+ m_cnt[RSP][MATCH_CNT], m_cnt[REQ][MATCH_CNT], m_cnt[RSP][MATCH_CNT],
             m_cnt[REQ][KICKEDOUT_CNT], m_cnt[RSP][KICKEDOUT_CNT],
             m_cnt[REQ][SAME_CNT], m_cnt[RSP][SAME_CNT],
             m_cnt[REQ][READ_FAIL_CNT], m_cnt[RSP][READ_FAIL_CNT],
             m_cnt[REQ][PARSE_FAIL_CNT], m_cnt[RSP][PARSE_FAIL_CNT],
             m_outFailCnt,
             m_linkTable.size());

    //m_flowLinkWriter.Flush();
    //ASSERT(m_flowLinkWriter.WriteTimestamp(g_nowSec32));
}


CLocalLinker::~CDataLinker()
{
    if (m_offset == -1)
        return;

    m_reqIoBaseId=0;
    m_rspIoBaseId=0;
    m_outIoBaseId=0;
    //m_ulLastWriteTime=0;
    m_offset=-1;
}


void CLocalLinker::OutFlowLinkData(const MatchInfo &l, const MatchInfo &r)
{
    //从IO中读取数据　拼接成一个flowLinkData 然后写入IO
    //l,r = (req, rsp), or (rsp, req)
    const MatchInfo* hashData[2] = {&l, &r};

    for (int i=0; i<2; ++i) //REQ and RSP
    {
        const int t = hashData[i]->type;
        //读取
        if (m_hashReader[t].GetDataMemory(hashData[i]->pointer, m_buf, BUF_SIZE) <= 0)
        {
            ++m_cnt[t][READ_FAIL_CNT];
            return;
        }

        //解析
        if (m_httpData[t].ParseFromArray(m_buf, BUF_SIZE) <0) 
        {
            ++m_cnt[t][PARSE_FAIL_CNT];
            return;
        }

        //拼接
        m_flowLinkData.CopyFromObjString2IOString(m_httpData[t], t*m_httpData[REQ].GetFieldTot());
    }

    //写入
    if (not m_flowLinkWriter.WriteObj(m_flowLinkData))
    {
        ++m_outFailCnt;
    }
}

uint32_t CLocalLinker::ReadIoAndMatch(const int t) //RSQ or RSP
{
    //1.读取IO //2.做匹配， //3.把匹配到的数据写入IO
    
    CStaticDataIOReader::tStaticDataPointer astPointer[MAX_BATCH_WRITE_ELEM_TOT];
    uint32_t ulTimestamp = 0;


    pair<const CStaticData* , uint32_t> pair = m_hashReader[t].GetNextMultiData(&ulTimestamp, astPointer);
    for (uint32_t i = 0; i < pair.second; ++i)
    {
        MatchInfo data(pair.first[i], t);
        data.pointer = astPointer[i];

        LinkTable::iterator it = m_linkTable.find(data.key);
        if (it == m_linkTable.end())
        {
            //未找到匹配，插入table等待后续匹配
            if (m_linkTable.insert_or_replace(data, MatchInfoKickedOut).second)
                ++m_cnt[t][KICKEDOUT_CNT];  //淘汰了一个元素
        }
        else if (it->IsMatch(data))
        {
            OutFlowLinkData(data, *it); 
            ++m_cnt[t][MATCH_CNT];
            ++s_testCnt;
            m_linkTable.erase(it);
        }
        else
        {
            //五元组相同,替换掉旧的
            *it= data;
            ++m_cnt[t][SAME_CNT];
        }

        //不管本机是否匹配，都进行全局匹配
        globalLinkerClient.SendMatcheInfo(MatchInfo); 
    }

    m_cnt[t][READ_CNT] += pair.second;
    return pair.second;
}


uint32_t CLocalLinker::HandleLoop()
{
    uint32_t readCnt = 0;

    readCnt = ReadIoAndMatch(REQ);
    readCnt += ReadIoAndMatch(RSP);

    m_intervalFn.Trigger(g_nowSec32);
    return readCnt;
}

