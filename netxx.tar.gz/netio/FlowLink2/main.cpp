/**
 * @file     main.cpp
 *           
 *
 * @author   akozhao
 * @date     2018年04月13日 15时07分01秒
 *
 */

#include "CFlowLinkSvrApp.h"

int main(int argc, char *argv[])
{
    g_FlowLinkSrvApp.Run(argc, argv);
}
