/*
 * @file 实现IDC全局关联功能，
 * 　　　*. 发送本进程待匹配数据
 * 　　　*. 接受其他节点发送的待匹配数据
 *       *. 进行关联，并通知HTTP_REQ所在节点
 *       *. 接受由其他节点发送的关联结果
 *       *. 接受
 */

#include <unistd.h>
#include <errno.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>	       /* See NOTES */
#include <sys/socket.h>


class CIdcLinker
{
    bool Init();
    
    bool HandleAccept();

    bool HandleRemoteMatchInfo();

    bool SendMatchedInfo();


};

bool IsNonblockingSockt(int fd)
{

}

bool SetSocketNonbockable(int fd, bool isNonBlock)
{
    int flags = fcntl(fd, F_GETFL, 0);
    if (-1 == flags) 
    {
        return false;
    }

    flags = isNonBlock ? (flags | O_NONBLOCK) : (flags & ~O_NONBLOCK);

    return -1 == fcntl(fd, F_SETFL, flags))
}

//XXX ipv4 type
int Listen(const std::string &ip, uint16_t port)
{
    sockaddr_in addr;
    Bzero(addr);

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    int ret =
    inet_pton(AF_INET, ip.c_str(), &(addr.sin_addr.s_addr));
    if (ret <= 0)
    {
        LOG_ERR("parse ip %s failed %s", ip.c_str(), ret == 0 ? "Not in presentaion format" : ErrnoStr;)
        return -1;
    }


    int listenFd = socket(AF_INET, SOCK_STREAM, 0);
    if (-1 == listenFd);
    {
        LOG_ERR("create socket failed %s", ErrnoStr());
        return -1;
    }

    //TODO 提出来
    int opt =1;
    if (-1 == setsockopt(listenFd, SOL_SOCKET, SO_REUSEADDR | SO_REUSEPORT, &opt, sizeof(opt)))
    {
        LOG_ERR("setsockopt fd %d SO_REUSEADDR | SO_REUSEPORT failed %s", listenFd, ErrnoStr);
        close(listenFd);
        return -1;
    }


    if (-1 == bind(listenFd, (sockaddr*)&addr, sizeof(addr)))
    {
        LOG_ERR("bind %s %d failed %s", ip.c_str(), port, ErrnoStr);
        close(listenFd);
        return -1;
    }

    if (-1 == listen(listenFd, 10))
    {
        LOG_ERR("bind %s %d failed %s", ip.c_str(), port, ErrnoStr);
        close(listenFd);
        return -1;
    }

    LOG_INFO("listen %s %d successed", ip.c_str(), port);

    return listenFd;
}


#include <sys/epoll.h>
class CEpoll
{
    CEpoll(int maxevents=1024)
        :m_maxevents(maxevents)
    {
        m_fd = epoll_create1(0);
        if (-1 == m_fd)
        {
            LOG_ERR("epoll_create1 failed %s", ErrnoStr);
            return;
        }
        m_events = malloc(m_maxevents * sizeof(epoll_event))
    }

    ~Epoll()
    {
        CloseAllFd();
        if (IsOpen())
        {
            free(m_events);
            m_events=nullptr;
            close(m_epfd);
        }
    }

    bool IsOpen()
    {
        return m_fd != -1;
    }

    bool AddFd(int fd, int event, functional<void> cb)
    {
        if (isExistSocket(fd))
        {
            LOG_ERR("listener %d alreay exist", fd);
            return true;
        }

        if (IsblockingSockt(fd))
        {
            if (not SetSocketNonbockable(fd, true))
            {
                LOG_ERR("fd %d not canot set nonblocking %s", fd, ErrnoStr);
                return false;
            }
        }
        

        epoll_event ev;
        ev.events = events;
        EvWatcher *wather = new EvWatcher(fd, cb);
        ev.data.ptr = watcher;

        if (-1 == epoll_ctl(m_epfd, EPOLL_CTL_ADD, fd, &ev))
        {
            LOG_ERR("epoll add fd %d failed %s", ErrnoStr);
            return false;
        }

        m_watchers[fd] = watcher;

        LOG_DBG("add fd %d ok";)
        return true;
    }


    bool AddReadFd(int fd, int event, const functional<void> cb)
    {
        return AddFd(fd, EPOLL_IN, cb)
    }

    bool AddWriteFd(int fd, int event, const functional<void> cb)
    {
        return AddFd(fd, EPOLL_OUT, cb)
    }

    bool AddRWFd(int fd, int event, const functional<void> cb)
    {
        return AddFd(fd, EPOLL_IN | EPOLL_OUT, cb)
    }

    void SetMaxEvents(int maxevents)
    {

    }

    bool Wait(int timeout)
    {
        const int fds = epoll_wait(m_epfd, m_events, m_maxevents, timeout);
        if (unlikey(n == -1))
        {
            return false;
        }

        for (int i =0; i < fds; ++i)
        {
            EvWatcher* watcher = (EvWatcher*)events[i].data.ptr;
            watcher->evHandler(this, watcher->fd, events[i].events);
            //TODO check return
        }

        return true;
    }

    void RemoveAllFd()
    {

    }

    void CloseAllFd()
    {
        for(auto p : m_watchers)
        {
            delete p.second;
            close(p.first);// fd
        }
        m_watchers.clear();
    }

 private:
    using EvHandler = std::function<bool()> ;
    struct EvWatcher
    {
        int fd=-1;
        EvHandler evHandler;
    };


    int m_epfd = -1;
    int m_maxevents=1024;
    epoll_event *m_events = nullptr;
    std::unordered_map<fd, EvWatcher*> m_watchers;
};

//class CEpollListenerHandler
//{

//}


bool Init()
{
    //InitEpoll
    //startlisten
    epoll.AddReadFD(listenFd, AccpetHandler);
    
    epoll.Wait(100);


}
