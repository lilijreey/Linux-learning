/**
 * @file     CFlowLinkSvrApp.cpp
 *           
 *
 * @author   akozhao
 * @date     2018年04月13日 15时09分26秒
 *
 */

#include "ProcessLimit.h"
#include "CUsProto.h"
#include "def_config.h"
#include "ProtocolFieldDef.h"

#include "CFlowLinkSvrApp.h"
#include "CDataLinker.h"

CFlowLinkSvrApp g_FlowLinkSrvApp;
uint32_t g_nowSec32;
uint64_t g_nowMsec64;

     
bool CFlowLinkSvrApp::OpenIO(void)
{
    CConfig *pConfig = GetConfig();
    CConfig ArgusConf;
    m_IoCnt = 6;

    if(ArgusConf.LoadFile("/home/oicq/argus/argus.conf"))
    {
    	m_IoCnt= ArgusConf.GetIntVal("COMMON", "io_num");
    	ASSERT_RET(m_IoCnt, false);
    	
    	string sMachineType = ArgusConf.GetVal("COMMON", "machine_type");
    	if(sMachineType == "40G")
    	{
    		m_processCnt = pConfig->GetIntVal("COMMON", "PROCESS_NUM_FOR40G");
    	}
    }
    ASSERT_RET(m_IoCnt, false);

    //init io
    bool bExist;
    string sMapFile = pConfig->GetValEx("IO", "map_file_list", 0, &bExist); //配置是个模式 /hugetlb/argus_* 
    ASSERT_RET(!sMapFile.empty(), false);
    vector<string> vecMapList;
    vector<int> vecShmList;
    vecMapList.push_back(sMapFile);
    LOG_DBG("map_file_list %s", sMapFile.c_str());
    ASSERT_RET(CIOBase::CommInit(vecMapList, vecShmList, 0/* ignore this args */), false);

    return true;
}

bool CFlowLinkSvrApp::InitLinker()
{
    ASSERT_RET(m_linkerCnt == 0, false);
    LOG_DBG("processNum %u, -p io_cnt :%u", m_processCnt, m_ulPortStep, m_IoCnt);
    ASSERT_RET(m_IoCnt % m_processCnt == 0, false); //进程数刚好平分IO
    int needLinkerCnt = m_IoCnt / m_processCnt;

    m_ulPortStep;
    for (int i=0; needLinkerCnt > 0; ++i)
    {
        int offset = i*needLinkerCnt + m_ulPortStep;
        LOG_DBG("will to create offset %d linker", offset);
        //一次两个方向
        CDataLinker *linker = new CDataLinker();
        ASSERT_RET(linker>Init(IN_HTTP_STREAM_IO_ID, OUT_HTTP_RSP_STREAM_IO_ID, 20UL<<32, offset, DIR_IN), false); 
        m_linkers.push_back(linker);

        CDataLinker *linker = new CDataLinker();
        ASSERT_RET(m_linkers[1]->Init(OUT_HTTP_STREAM_IO_ID, IN_HTTP_RSP_STREAM_IO_ID, 21UL<<32, offset, DIR_OUT), false);
        m_linkers.push_back(linker);
    }

    LOG_INFO("init linker successed");

	return true;
}

void CFlowLinkSvrApp::ClearLinker()
{
    for (auto &linker : m_linkers)
    {
        delete linker;
        linker = nullptr;
    }
    m_linkers.clear();
}

bool CFlowLinkSvrApp::InitServer() 
{

    if (not InitLog())
    {
        printf("Init Log failed\n");
        return false;
    } 

    //设置日志告警属性
    CLog *pLog =CLog::Instance();
    pLog->SetMntAttr(LOG_LEVEL_ASSERT, MONITOR_ASSERT_LOG);
    pLog->SetMntAttr(LOG_LEVEL_WARN, MONITOR_WARN_LOG);
    pLog->SetMntAttr(LOG_LEVEL_ERR, MONITOR_ERR_LOG);

	int iPrio = -1;
    if(setpriority(PRIO_PROCESS, 0, iPrio) == -1)
    {
        LOG_ERR("Set process priority %d err: %d", iPrio, errno);
        return false;
    }
    
    SetCpuAffinity(PRI_HIGHER);

    ASSERT_RET(InitIO(), false);

    ASSERT_RET(InitLinker(), false); 


    LOG_INFO("server init successed io cnt :%d linker cnt:%d", m_IoCnt, m_linkerCnt);


    return true;
}


bool CFlowLinkSvrApp::HandleLoop(void)
{
	timeval tv;
	gettimeofday(&tv, NULL);
	g_nowMsec64= tv.tv_sec * 1000000 + tv.tv_usec;
	g_nowSec32 = tv.tv_sec;

    uint32_t cnt=0;
    for (auto linker : m_linkers)
    {
        cnt += linker->HandleLoop();
    }

    //if (cnt == 0)
    //{
    //    usleep(50*1000);
    //}

    return true;
}



