
#pragma once

/*
 * @file 实现读取相同偏移的HTTP REQ/RSP IO数据
 *
 */

class CHttpReader
{

};
