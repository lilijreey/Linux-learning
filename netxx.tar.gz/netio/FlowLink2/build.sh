#!/bin/bash

g++ -Wall -std=c++11 -I ../include netTest.cpp  NetIO.cpp
