#include <stdio.h>
#include "ASSERT.h"
#include <assert.h>
#include <sys/socket.h>
#include <string.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <errno.h>
#include <ctype.h>
#include <sys/un.h>
#include <net/if.h>
#include <sys/ioctl.h>
#include <unistd.h>
#include <dirent.h>
#include <string.h>
#include <sys/stat.h>
#include <string>
#include <iostream>
#include "CZookeeper.h"
#include "SocketApiWrapper.h"

using namespace std;
using namespace SEC;


#define SOCK_HOOK_CONF "/etc/hook.conf"

CZookeeper  g_Zookeeper;

string          g_sZKHost;
int             g_iIDCID = 0;
string          g_sIP;

bool WriteZKNode()
{
    if (!g_Zookeeper.Init(g_sZKHost, 10000))
    {
        LOG_ERR("Init zookeeper err with : %s,  timeout: %d", g_sZKHost.c_str(), 10000);
        return false;
    }

    string sRegPath("/argus/flow_link/reg_path/");
    sRegPath += g_sIP;

    string sDstPath("/argus/flow_link/groups/");
    char aszBuf[50];
    snprintf(aszBuf, sizeof(aszBuf), "%d", g_iIDCID);
    sDstPath += aszBuf;

    ASSERT_RET(0 == g_Zookeeper.CreateOrSetNode(sRegPath, sDstPath.c_str(), sDstPath.size()), false);

    unsigned int ulTime = (uint32_t)time(NULL);
    int iRet = snprintf(aszBuf, sizeof(aszBuf), "%u", ulTime);
    ASSERT_RET(0 == g_Zookeeper.CreateOrSetNode(sDstPath, aszBuf, iRet), false);

    string sSeqPath = sDstPath + "/seq";
    ASSERT_RET(0 == g_Zookeeper.CreateOrSetNode(sSeqPath, aszBuf, iRet), false);

    string sIpIdPath = sDstPath + "/ipid";
    ASSERT_RET(0 == g_Zookeeper.CreateOrSetNode(sIpIdPath, aszBuf, iRet), false);

    string sOnlinePath = sDstPath + "/online";
    ASSERT_RET(0 == g_Zookeeper.CreateOrSetNode(sOnlinePath, aszBuf, iRet), false);

    return true;
}


void Usage()
{
    printf("Usage: -i idcid -z zk_host -d ip\n");
}


int main(int argc, char *argv[])
{
    if( access(SOCK_HOOK_CONF, F_OK) == 0 )
    {
        if(!init_socket_api(SOCK_HOOK_CONF))
        {
            printf("Init socket hook failed.\n");
            return -1;
        }
    }

    char opt;
    while( -1 != (opt=getopt(argc, argv, "z:i:d:")) )
    {
        switch(opt)
        {
            case 'i':  // idc
                g_iIDCID = atoi(optarg);
                break;

            case 'z': // zk ip
                g_sZKHost = optarg;
                break;

            case 'd':
                g_sIP = optarg;
                break;

            case 'h':  // help
            default:
                Usage();
                return -1;
        }
    }

    if(g_sIP.empty() || g_iIDCID == 0 || g_sZKHost.empty())
    {
        Usage();
        return -1;
    }

    if(!WriteZKNode())
    {
        fprintf(stderr, "Write ZK failed\n");
        exit(-1);
    }
    else
    {
        printf("OK\n");
    }

    return 0;
}
