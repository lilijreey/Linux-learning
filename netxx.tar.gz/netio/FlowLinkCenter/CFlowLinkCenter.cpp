/***********************************************************************
 * File : CFlowLinkCenter.cpp
 * Brief: 
 * 
 * History
 * ---------------------------------------------------------------------
 * 2017-03-08     feynmanzuo   1.0    created
 * 
 ***********************************************************************
 */

#include "CFlowLinkCenter.h"
#include "FlowLinkCenter_comm.h"
#include "FLMonitor.h"
#include "CZookeeper.h"
#include "SocketApiWrapper.h"

using namespace SEC;

extern int g_iProcID;

CZookeeper  g_Zookeeper;
timeval     g_ulSystemTime = {0};

bool CFlowLinkCenter::InitServer()
{
    /**
     * �������룬����Ӧ�ÿ�������޸�Ϊ�����������Ե����� 
     */
    bool bRet = false;

    // GetConfig��ȡ���������ļ�
    CConfig *pConfig = GetConfig();

    // ��ȡ�����ػ��������ļ�
    CConfig localCfg;
    string  sLocalConfigPath = pConfig->GetVal(CONF_BLOCK_COMM, 
            CONF_ITEM_LOCAL_CONFIG_FILE);

    if (!localCfg.LoadFile(sLocalConfigPath))
    {
        LOG_ERR("load local config file faled! file path=%s", 
                sLocalConfigPath.c_str());
    }

    ASSERT_RET(m_LinkHashTable.Init(400000, HASH_TIMES), false);
    //ASSERT_RET(m_LinkHashTable[0].Init(400000, HASH_TIMES), false);
    //ASSERT_RET(m_LinkHashTable[1].Init(400000, HASH_TIMES), false);

    // ��ȡ��������IP
    string sLocalIP = localCfg.GetVal(CONF_BLOCK_LOCAL_SERVER, "local_ip");

    // ��ȡ�󶨶˿�
    int    iBasePort    = pConfig->GetIntVal(CONF_BLOCK_LOCAL_SERVER, "base_port");
    int    iProcessCnt  = pConfig->GetIntVal(CONF_BLOCK_LOCAL_SERVER, "process_cnt");
    if (sLocalIP.empty() || iBasePort <= 0 || iProcessCnt <= 0)
    {
        LOG_ERR("read local server config failed! ip=%s, port=%d, proccnt=%d", sLocalIP.c_str(), iBasePort, iProcessCnt);
        return false;
    }
    
    //���ð󶨵�tcp�˿�
    int    iBindPort    = iBasePort + g_iProcID;
    bRet = AddTcpBindAddr(sLocalIP.c_str(), iBindPort, SOCK_MAIN, sizeof(tHashPack));
    ASSERT(bRet);
    
    bRet = SetUserInfoLen(sizeof(TcpUserInfo));
    ASSERT(bRet);

    SrvFrameworkSetWaitTimeout(1);      // 1ms ��ʱ

    gettimeofday(&g_ulSystemTime, NULL);


    if(g_iProcID == 0)
    {
        string sSockAgentConf = pConfig->GetVal("SocketHook", "path");
        if(sSockAgentConf.size())
        {
            if( access(sSockAgentConf.c_str(), F_OK) == 0 )
            {
                ASSERT_RET(init_socket_api(sSockAgentConf.c_str()), false);
            }
        }

        // zookeeper
        string sZookeeperHost = pConfig->GetVal("ZOOKEEPER", "host");
        int iZookeeperTimeout = pConfig->GetIntVal("ZOOKEEPER", "timeout");

        ASSERT_RET(!sZookeeperHost.empty() && iZookeeperTimeout > 0, false);

        if (!g_Zookeeper.Init(sZookeeperHost, iZookeeperTimeout))
        {
            LOG_ERR("Init zookeeper err with : %s,  timeout: %d", sZookeeperHost.c_str(), iZookeeperTimeout);
            return false;
        }



        ASSERT_RET(Register(sLocalIP, iBasePort, iProcessCnt), false);
        m_ulZkFailedTimes = 0;
        // g_Zookeeper.Close();
    }

    memset(&m_stMonitor, 0, sizeof(m_stMonitor));

    m_ulReqKeyCnt = 0;
    m_ulRspKeyCnt = 0;
    m_ulReqMatchCnt = 0;
    m_ulRspMatchCnt = 0;

    m_ulReqSame = 0;
    m_ulRspSame = 0;

    m_ulReqKickCnt = 0;
    m_ulRspKickCnt = 0;

    return true;
}



/**
* ������������
*/
int CFlowLinkCenter::HandleAccept (SCTX *pstSctx, void *pCInfo, int iAddrName)
{
    return 0;
}

/**
* ����TCP�������
*/
int CFlowLinkCenter::HandlePkgHead (SCTX *pstSctx, void *pCInfo, int iAddrName,
        void *pPkg, int iBytesRecved, int *piPkgLen)
{
    if(((tHashPack*)pPkg)->ulStx != HASH_IN_STX && ((tHashPack*)pPkg)->ulStx != HASH_OUT_STX)
    {
        LOG_ERR("recv bad head %d", ((tHashPack*)pPkg)->ulStx);
        return -1;
    }
    *piPkgLen = (int)(((tHashPack*)pPkg)->ulLen);

    ++m_ulRecvPkgCnt;
    m_ulRecvBytes += *piPkgLen;

    return 0;
}

/**
* ����TCP����
*/
int CFlowLinkCenter::HandlePkg (SCTX *pstSctx, void *pCInfo, int iAddrName,
        void *pPkg, int iPkgLen)
{
    uint32_t ulHashLen = iPkgLen - sizeof(tHashPack);
    uint32_t ulHashCnt = ulHashLen / sizeof(tHashType);
    if(ulHashLen % sizeof(tHashType) != 0)
    {
        LOG_ERR("%d Err package", pstSctx->iSocket);
        return -1;
    }

    tAddrNameInfo &stAddrInfo = m_mapAddrInfo[pstSctx->iSocket];
    stAddrInfo.fd= pstSctx->iSocket;
    if(((tHashPack*)pPkg)->ulStx == HASH_IN_STX) //����������IN����req, Ҳ�������е�req,�����ǳ�����������������������,�п��ܰ���������req����������rsp����������Ȼ����ȷ
    {
        for(uint32_t i = 0; i < ulHashCnt; i++)
        {
            HandleHashIn(((tHashPack*)pPkg)->astData[i], stAddrInfo, 0);
        }
        m_ulReqKeyCnt += ulHashCnt;
    }
    else
    {
        stAddrInfo.ulIP = ((tHashPack*)pPkg)->ulIP;
        stAddrInfo.usPort = ((tHashPack*)pPkg)->usPort;;
        for(uint32_t i = 0; i < ulHashCnt; i++)
        {
            HandleHashOut(((tHashPack*)pPkg)->astData[i], pstSctx->iSocket, 0);
        }
        m_ulRspKeyCnt += ulHashCnt;
    }

    return 0;
}

/**
* �����ر�����
*/
int CFlowLinkCenter::HandleCloseConn(SCTX *pstSctx, void *pUserInfo, int iAddrName,
        char *sErrInfo)

{
    LOG_INFO("Close %d", pstSctx->iSocket);
    m_mapAddrInfo.erase(pstSctx->iSocket);
    return 0;
}



/**
* ѭ��ʱ�䴦��
*/
int CFlowLinkCenter::HandleLoop(void)
{
    // 2000 ���� ���� 10ms flush һ��
    gettimeofday(&g_ulSystemTime, NULL);
    if(m_stLastFlushTime.tv_sec * 1000 + m_stLastFlushTime.tv_usec / 1000 + 10
        <= g_ulSystemTime.tv_sec * 1000 + g_ulSystemTime.tv_usec / 1000)
    {
        m_stLastFlushTime = g_ulSystemTime;
        for(map<int, tAddrNameInfo>::iterator Iter = m_mapAddrInfo.begin(); Iter != m_mapAddrInfo.end(); Iter++)
        {
            Send(Iter->second);
        }
    }

    if(m_ulLastLogMnt + 60 <= g_ulSystemTime.tv_sec)
    {
        m_ulLastLogMnt = (uint32_t)(g_ulSystemTime.tv_sec);
        LogMonitor();
    }

    if(g_iProcID == 0 && m_ulLastCheckOnlineNode + 3 * 60 <= g_ulSystemTime.tv_sec)
    {
        m_ulLastCheckOnlineNode = (uint32_t)(g_ulSystemTime.tv_sec);

        int iRet =  g_Zookeeper.ExistsNode(m_sOnlineNodePath);

        if (iRet == 0 || iRet == ZNONODE)
        {
            m_ulZkFailedTimes = 0;
        }

        if (iRet == ZNONODE)
        {
            LOG_WARN("Temp node is lost. recreate:%s", m_sOnlineNodePath.c_str());
            g_Zookeeper.CreateNode(m_sOnlineNodePath, m_sOnlineNodeVal.c_str(), m_sOnlineNodeVal.size(), true);
        }
        else if (iRet != 0)
        {
            //zk ���Ӷ�ʧ��ʱ���ִ�е�����
            m_ulZkFailedTimes++;
            LOG_ERR("check zk path (%s) exists err:%s %d", m_sOnlineNodePath.c_str(), iRet, zerror(iRet));
            if(2 == m_ulZkFailedTimes)
            {
                LOG_ERR("zk failed too many times, exit process.");
                _exit(-1);
            }
        }
    }


    static uint32_t lastTime = 0;

    if (lastTime != g_ulSystemTime.tv_sec)
    {
        lastTime = g_ulSystemTime.tv_sec;
        LOG_INFO("%u, reqCnt:%u, rspCnt:%u reqMatch:%u rspMatch:%u reqSame:%u, rspSame:%u reqKick:%u rspKick:%u", 
                m_ulReqMatchCnt + m_ulRspMatchCnt,
                m_ulReqKeyCnt, m_ulRspKeyCnt, m_ulReqMatchCnt, m_ulRspMatchCnt, m_ulReqSame, m_ulRspSame,
                m_ulReqKickCnt, m_ulRspKickCnt);
    }


    return 0;
}

/**
* �������˳���ʱ�򣬽����øú���
*/
int CFlowLinkCenter::HandleExit(void)
{
    return 0;
}

/**
 * ��ѡ�ص�����
 */
void CFlowLinkCenter::OnHandle()
{
}

inline void CFlowLinkCenter::Send(tAddrNameInfo &stAddrInfo)
{
    if(stAddrInfo.ulTotHashCount <= 0)
    {
        return;
    }
    static char s_aszBuf[64 * 1024];        // ���2000��hash��Ӧ�ò��ᳬ�� 32k
    int iCursor = sizeof(tLinkReply);
    map<uint16_t, vector<tHashType> > &mapHash = stAddrInfo.mapHash;
    for(map<uint16_t, vector<tHashType> >::iterator Iter = mapHash.begin(); Iter != mapHash.end(); Iter++)
    {
        if(m_mapAddrInfo.find(Iter->first) == m_mapAddrInfo.end())
        {
            LOG_ERR("Can't find match dst host");
            continue;
        }

        vector<tHashType> &vecHash = Iter->second;
        if(vecHash.size())
        {
            tAddrNameInfo &stDstAddrInfo = m_mapAddrInfo[Iter->first];
            tPeerInfo *pstPeerHead = (tPeerInfo *)(&(s_aszBuf[iCursor]));
            pstPeerHead->ulDstIP = stDstAddrInfo.ulIP;
            pstPeerHead->usPort = stDstAddrInfo.usPort;
            pstPeerHead->ulCount = vecHash.size();

            iCursor += sizeof(tPeerInfo);
            for(vector<tHashType>::iterator Iter2 = vecHash.begin(); Iter2 != vecHash.end(); Iter2++)
            {
                *(tHashType*)(&(s_aszBuf[iCursor])) = *Iter2;
                iCursor += sizeof(tHashType);
            }

            vecHash.clear();        // Clear buffer
        }
    }
    ((tLinkReply*)s_aszBuf)->ulStx = LINK_REPLY_STX;
    ((tLinkReply*)s_aszBuf)->ulLen = iCursor;

    // do some clear
    stAddrInfo.ulTotHashCount = 0;

    SCTX * pstSctx = NULL;
    if(SrvFrameworkGetContext(stAddrInfo.fd, &pstSctx, NULL) < 0)
    {
        m_stMonitor.ullGetAddCtxFail++;
        LOG_ERR("Get addr ctx failed");
        return;
    }

    if(SrvFrameworkSend(pstSctx, NULL, s_aszBuf, iCursor) < 0)
    {
        m_stMonitor.ullSendFail++;
        LOG_ERR("Send package failed id:%d, sock:%d.", stAddrInfo.fd, pstSctx->iSocket);
    }
}

inline void CFlowLinkCenter::AddMatchHash(tAddrNameInfo &stAddrInfo, uint16_t ulDst, tHashType stHash)
{
    m_stMonitor.ullMatchCnt++;
    stAddrInfo.mapHash[ulDst].push_back(stHash);
    if (++stAddrInfo.ulTotHashCount >= MAX_HOLD_HASH)
    {
        Send(stAddrInfo);
    }
}

/**
* ����http�����hash
*/
void CFlowLinkCenter::HandleHashIn (tHashType stHash, tAddrNameInfo &stAddrInfo, int _dir/* unused */)
{
    //dir ��������������������֮ǰ��û�������ֵģ�֮����Ҫ���Լ���
    m_stMonitor.ullHandleIn++;

    const uint16_t srcSocket = stAddrInfo.fd;
    const uint32_t ulThisTime = (uint32_t)(g_ulSystemTime.tv_sec);
    const uint32_t ulExpiredTime = ulThisTime - EXPIRE_TIME;
    tLinkElem *pstEmpty = NULL;

    for(int i = 0; i < HASH_TIMES; i++)
    {
        tLinkElem *pstElem = m_LinkHashTable.GetConflictElem(stHash, i);
        if(pstElem->key == stHash)
        {
            if(pstElem->dstSocket != 0)
            {
                AddMatchHash(stAddrInfo, pstElem->dstSocket, stHash);
                pstElem->key = 0;   // clear
                ++m_ulReqMatchCnt;
            }
            else
            {
                pstElem->srcSocket = srcSocket;
                pstElem->ulTime = ulThisTime;
                m_stMonitor.ullConfilictHash++;
                ++m_ulReqSame;
            }

            return;
        }
        //else if(pstElem->key == 0 || (pstElem->ulTime <= ulExpiredTime && !pstEmpty))
        else if(pstElem->key == 0 || (pstElem->ulTime <= ulExpiredTime))
        {
            pstEmpty = pstElem;
            break;
        }
    }

    if(pstEmpty)
    {
        pstEmpty->key = stHash;
        pstEmpty->ulTime = ulThisTime;
        pstEmpty->srcSocket = srcSocket;
        pstEmpty->dstSocket = 0;
        ++m_ulReqKickCnt;
    }
    else
    {
        m_stMonitor.ullHashFull++;
    }

    return;
}


/**
* ����http��Ӧ��hash
*/
void CFlowLinkCenter::HandleHashOut(tHashType stHash, int socket, int _dir/* noused */)
{
    m_stMonitor.ullHandleOut++;

    uint32_t ulThisTime = (uint32_t)(g_ulSystemTime.tv_sec);
    uint32_t ulExpiredTime = ulThisTime - EXPIRE_TIME;
    tLinkElem *pstEmpty = NULL;

    for(int i = 0; i < HASH_TIMES; i++)
    {
        tLinkElem *pstElem = m_LinkHashTable.GetConflictElem(stHash, i);
        if(pstElem->key == stHash)
        {
            if(pstElem->srcSocket != 0)
            {
                if(m_mapAddrInfo.find(pstElem->srcSocket) != m_mapAddrInfo.end())
                {
                    AddMatchHash(m_mapAddrInfo[pstElem->srcSocket], socket, stHash);
                }
                pstElem->key = 0;   // clear
                ++m_ulRspMatchCnt;
            }
            else
            {
                pstElem->dstSocket= socket;
                pstElem->ulTime = ulThisTime;
                m_stMonitor.ullConfilictHash++;
                ++m_ulRspSame;
            }

            return;
        }
        //else if(pstElem->key == 0 || (pstElem->ulTime <= ulExpiredTime && !pstEmpty))
        else if(pstElem->key == 0 || (pstElem->ulTime >= ulExpiredTime))
        {
            pstEmpty = pstElem;
        }
    }

    if(pstEmpty)
    {
        pstEmpty->key = stHash;
        pstEmpty->ulTime = ulThisTime;
        pstEmpty->dstSocket = socket;
        pstEmpty->srcSocket = 0;
        ++m_ulRspKickCnt;
    }
    else
    {
        m_stMonitor.ullHashFull++;
    }

    return;
}


bool CFlowLinkCenter::Register(string sLocalIP, int iBasePort, int nCount)
{
    string sRegPath = "/argus/flow_link/reg_path/" + sLocalIP;
    string sBasePath;

    if(0 != g_Zookeeper.ReadString(sRegPath, sBasePath) || sBasePath.empty())
    {
        LOG_ERR("Read reg_path err");
        return false;
    }

    string sSeqPath = sBasePath + "/seq";
    string sIdxPath = sBasePath + "/ipid/" + sLocalIP;

    uint64_t ullIdx = -1;
    string sRealPath;
    ASSERT_RET(0 == g_Zookeeper.ReadUint(sIdxPath, ullIdx), false);
    if(ullIdx == 0)
    {
        string sTmp;
        ASSERT_RET(0 == g_Zookeeper.ReadString(sSeqPath + "/IP0000000000", sTmp), false);
        if(sTmp != sLocalIP)
        {
            ASSERT_RET(0 == g_Zookeeper.CreateOrSetNode(sSeqPath), false);
            ASSERT_RET(0 == g_Zookeeper.CreateNode(sSeqPath + "/IP", sLocalIP.c_str(), sLocalIP.length(), false, true, sRealPath), false);
            ASSERT_RET(sRealPath != "", false);

            ullIdx = strtoul(sRealPath.c_str() + string(sSeqPath + "/IP").length(), NULL, 10);
            ASSERT_RET(0 == g_Zookeeper.WriteUint(sIdxPath, ullIdx), false);
         }
    }
    LOG_INFO("register ip = %s to %s, get seq = %u", sLocalIP.c_str(), sBasePath.c_str(), ullIdx);

    // create temp node
    m_sOnlineNodePath = sBasePath + "/online/" + sLocalIP;
    for(int i = 0; i < nCount; i++)
    {
        char aszBuf[50];
        snprintf(aszBuf, sizeof aszBuf, "%d", iBasePort + i);
        if(i > 0)
        {
            m_sOnlineNodeVal += ',';
        }
        m_sOnlineNodeVal += aszBuf;
    }
    ASSERT_RET(0 == g_Zookeeper.CreateNode(m_sOnlineNodePath, m_sOnlineNodeVal.c_str(), m_sOnlineNodeVal.size(), true), false);
    m_ulLastCheckOnlineNode = (uint32_t)(g_ulSystemTime.tv_sec);

    return true;
}

void CFlowLinkCenter::LogMonitor()
{
    Attr_API(MN_CONFILICT_HASH, m_stMonitor.ullConfilictHash);
    Attr_API(MN_GET_EXPIRED_HASH, m_stMonitor.ullGetExpiredHash);
    Attr_API(MN_HASH_FULL, m_stMonitor.ullHashFull);
    Attr_API(MN_GET_ADD_CTX_FAIL, m_stMonitor.ullGetAddCtxFail);
    Attr_API(MN_SEND_FAIL, m_stMonitor.ullSendFail);
    Attr_API(MN_HANDLE_IN, m_stMonitor.ullHandleIn);
    Attr_API(MN_HANDLE_OUT, m_stMonitor.ullHandleOut);
    Attr_API(MN_MATCH_CNT, m_stMonitor.ullMatchCnt);

#define CASTU(x) ((unsigned long long)x)
    LOG_INFO("ConflictHash:%llu, ExpiredHash:%llu, HashFull:%llu, GetCtxFail:%llu, SendFail:%llu, HandleIn:%llu, HandleOut:%llu, Match:%llu",
            CASTU(m_stMonitor.ullConfilictHash), CASTU(m_stMonitor.ullGetExpiredHash),CASTU(m_stMonitor.ullHashFull) ,CASTU(m_stMonitor.ullGetAddCtxFail)
            ,CASTU(m_stMonitor.ullSendFail),CASTU(m_stMonitor.ullHandleIn),CASTU(m_stMonitor.ullHandleOut), CASTU(m_stMonitor.ullMatchCnt));
#undef CASTU

    memset(&m_stMonitor, 0, sizeof(m_stMonitor));
}

