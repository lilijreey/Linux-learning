/***********************************************************************
 * File : FlowLinkCenter_comm.h
 * Brief: 
 * 
 * History
 * ---------------------------------------------------------------------
 * 2017-03-08     feynmanzuo   1.0    created
 * 
 ***********************************************************************
 */

#ifndef FLOWLINKCENTER_COMM_H__
#define FLOWLINKCENTER_COMM_H__


// ������������Ŀ
const char *const CONF_BLOCK_COMM = "COMMON";
const char *const   CONF_ITEM_LOCAL_CONFIG_FILE="local_config";

const char *const CONF_BLOCK_LOCAL_SERVER = "LOCAL_SERVER";
const char *const CONF_BLOCK_OUTER_SERVER = "OUTER_SERVER";


enum SOCK_UDP_NAME
{
    SOCK_MAIN=0,
    SOCK_CNT
};

struct TcpUserInfo
{
    char szReserve[1];
};


#endif

