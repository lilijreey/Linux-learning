/***********************************************************************
 * File : main.cpp
 * Brief: 
 * 
 * History
 * ---------------------------------------------------------------------
 * 2017-03-08     feynmanzuo   1.0    created
 * 
 ***********************************************************************
 */

#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <stdint.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <signal.h>
#include <string.h>
#include <stdarg.h>
#include <netdb.h>
#include <sys/socket.h> 
#include <iostream>

#include "svr_dev.h"
#include "CFlowLinkCenter.h"

using namespace std;

// ���������ģ��
CFlowLinkCenter g_serverApp;
int             g_iProcID = -1;

/**
 *  �÷���ʾ
 */
static void Usage( )
{
    #ifdef TEST_VERSION
    const char *szType = "test";
    #else
    const char *szType = "standard";
    #endif

    (void) fprintf( stderr,    "----------------------------------------------\n"
                            "Version:(%s)1.0; Compile@"__DATE__" "__TIME__";\n"
                            "----------------------------------------------\n"
                            "Usage:\n"
                            "FlowLinkCenter -h | -f config_file | -n\n"
                            "    h) help and version\n"
                            "    p) process id\n"
                            "    f) load config file and run\n"
                            "    n) do not use DaemonInit\n",
                            szType);
}

int main(int argc, char *argv[])
{
    char szCfgFile[256];
    char opt;
    bool bUseDaemonInit = true;

    memset(szCfgFile, 0, sizeof(szCfgFile)); 
    while( -1 != (opt=getopt(argc, argv, "hnp:f:")) )
    {
        switch(opt)
        {
            case 'f':  // config file
                strncpy(szCfgFile, optarg, sizeof(szCfgFile)-1);
                break;
                
            case 'n':
               bUseDaemonInit = false;
               break;
               
            case 'p':
                g_iProcID = atoi(optarg);
                break;

            case 'h':  // help                
            default:                
                Usage();
                return -1;
        }
    }

    if (!szCfgFile[0] || g_iProcID < 0)
    {
        Usage();
        return -1;
    }

    bool bRet = g_serverApp.Run(szCfgFile, bUseDaemonInit);
    if (bRet)
    {
        cout<<"server run succ!";
    }
    else
    {
        cout<<"server run failed!";
    }

    // �������
    printf("process exit\r\n");
    
    return 0;
}


