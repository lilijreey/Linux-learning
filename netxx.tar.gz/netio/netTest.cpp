
#include <stdio.h>
#include <assert.h>
#include "NetIO.h"

int size=0;
bool HandleEv2(CEpoll *epoll, const int fd, const int events)
{
    if (CEpoll::IsErrEv(events))
    {
        int err = GetSocketErr(fd);
        printf("conn %d has a error %d %s, close it\n", fd, err, strerror(err));
        return false;
    }

    if (events & EPOLLOUT)
    {
        printf("write able todo.. \n");

    }

    if (events & EPOLLIN)
    {
        char buf[215];
        size_t recvLen =0;
        int ret = NetRecv(fd, buf, 214, recvLen);
        if (ret <= 0)
        {
            printf("socket %d close by peer ret:%d, cloes it size:%d\n", fd, ret, size);
            return false;
        }

        buf[recvLen] = '\0';
        size+=ret;
        //printf("fd %d recv %lu:%s\n", fd, recvLen, buf);
    }
    return true;

}



class ServerListener : public ListenerHandler
{
 public:
  virtual bool OnAcceptSuccessed(CEpoll *epoll, int fd, sockaddr_in addr, socklen_t addrlen) override
  {
    printf("new conn fd %d\n", fd);
    epoll->AddReadFd(fd, HandleEv2);
    return true;
  }


};


int main(int argc, char *argv[])
{
    CEpoll epoll(32);

    assert(epoll.IsOpen());
    ServerListener listener;

    int fd = Listen("127.0.0.1", 3345);
    assert(fd != -1);
    int ret = epoll.AddReadFd(fd, listener.GetEvHandler());
    if (ret == -1)
    {
        perror("AddReadFile failed");
        return 0;
    }

#if 0
    epoll.AddReadFd(fd, 
                  [](CEpoll *epoll, const int listenFd, const int events)
                  {
                  printf("listen fd %d event %d\n", listenFd, events);
                  if (CEpoll::IsErrEv(events))
                  {
                  int err = GetSocketErr(listenFd);
                  printf("socket %d has a error %d %s, close it\n", listenFd, err, strerror(err));
                  return false;
                  }

                  int conn = Accept(listenFd);
                  if (conn == 0) return true;
                  if (conn == -1)
                  {
                      printf("accept fd %d failed %s\n", listenFd, ErrnoStr);
                      return true;
                  }


                  printf("accept new conn fd %d\n", conn);

                  epoll->AddReadFd(conn, HandleEv);
                  return true;
                  });
#endif



    printf("\nstart wait\n");
    while(true)
    {
        //printf("wait again\n");
        epoll.Wait(-1);
    }

    return 0;
}
