
#include <unordered_map>
#include <vector>
#include <functional>
#include <stdio.h>
//using Fn = std::function<bool(int &)>;

using Fn = bool(*)(int &);
struct EvHandlerPipeline
{
    explicit EvHandlerPipeline(const Fn &fn)
    {
        Add(fn);
        //pp.push_back(fn);
    }

    bool operator()(int &val)
    {
        //printf("pipeline handle\n");
        for (int i=0; i<n;++i)
        {
            if (not pp[i](val))
            {
                //printf("pipline break\n");
                return false;
            }
        }
        return true;
    }


    EvHandlerPipeline& Add(const Fn &fn)
    {
        pp[n++]=fn;
        //pp.push_back(fn);
        return *this;
    }

    EvHandlerPipeline& operator|(const Fn &fn)
    {
        return Add(fn);
    }

    Fn pp[4];
    int n=0;
    //std::vector<Fn> pp;
};

bool ok(int &n)
{
    ++n;
    return true;
}

bool dst(int &n)
{
    ++n;
    return true;
}

bool nn(int &n)
{
    ++n;
    return true;
}

bool oo(int &n)
{
    if (not ok(n)) return true;
    if (not dst(n)) return true;
    if (not nn(n)) return true;
    return true;
}

int main(int argc, char *argv[])
{
    //EvHandlerPipeline p(ok);
    //p |  nn | dst;
    int a=1;

    //oo(a);
    for (int i =0; i<100000000;++i)
    {
        oo(argc);
        //p(a);
    }


    
    return 0;
}
