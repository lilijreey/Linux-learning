
#ifndef LINK_UTILS_H_
#define LINK_UTILS_H_

#include <assert.h>

#define ASSERT_RET(exp, ret) if (not (exp)) return ret

#define DEV_ASSERT(exp) assert(exp)

enum
{
    _4K = 4 << 10,

};

struct NoCopyable
{
    NoCopyable() = default;
    ~NoCopyable() = default;
    NoCopyable(NoCopyable &) = delete;
    NoCopyable& operator=(NoCopyable &) = delete;
};

#endif /* ifndef  */
