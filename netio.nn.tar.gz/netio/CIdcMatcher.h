/**
 * @file     CIdcMatcher.h
 *           
 *
 * 进行IDC级的匹配
 * @author   lili <lilijreey@gmail.com>
 * @date     07/01/2018 07:51:47 PM
 *
 */



//IdcMatcher
//LocalMatcher

//IdcMatchedInfoReceiver// 发送本机matche info 到对应的IDC 节点
//IdcMatchedInfoSender //接受上游IDC节点返回的匹配信息

//HttpInfoSender
//HttpInfoReceiver

//void HandlePkg()

//class CIdcMatcherListenr : ListenerHandler
//{
//    void Init(CEpoll *epoll, constd::string)







