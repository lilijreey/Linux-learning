
#include "NetIO.h"
#include "Utils.h"
#include "MessageDef.h"

struct IdcMatchInfo 
{
    IdcMatchInfo(MatchInfo *info, int _fd, uint32_t _ip)
        :infoKey(info->infoKey)
         ,time(g_NowSec)
         ,fd(_fd)
         ,ip(_ip)
         ,port(info->port)
         ,type(info->type)
    {}


    uint64_t infoKey=0;
    uint32_t time;
    int      fd;   //conn //这里不存指针是因为，对象之后有可能释放掉，通过fd来查找
    uint16_t ip; //监听的port //better 每个连接存下来，不在每个包中单独发送
    uint16_t port; //监听的port //better 每个连接存下来，不在每个包中单独发送
    uint16_t type;  //req/rsp
};




//TODO 再次封装
//TcpConnect
class CIdcMatcher;
struct CDownstreamConn : NoCopyable
{
  CDownstreamConn(int fd, CIdcMatcher *owner)
      :m_fd(fd), m_owner(owner)
  {}

  bool Recv()
  {
      if (not m_recvBuf.Recv(m_fd))
      {
          LOG_DBG("downstream %d recv <= 0 close it", m_fd);
          return false;
      }

      while (const NetPkgHaed *pkgHead = m_recvBuf.PeekNextPkgHead())
      {
          if (not pkgHead->IsVaildPkg())
          {
              LOG_ERR("fd %d get a unvalied pkg close it", m_fd);
              return false;
          }

          if (not m_recvBuf.IsHasCompletePkg(pkgHead->pkgLen))
          {
              return true;
          }

          m_recvBuf.ReadNextPkg(pkgHead->pkgLen);

          if (not DispatchPkgMsg(pkgHead))
          {
              return false;
          }
      }

      return true;
  }

  /*RegMsgHandler<CMD_MATCHINFO, HandleMatchInfoMsg,*/
  /*             >                                  */
  bool DispatchPkgMsg(const NetPkgHaed *pkgHead)
  {
    //todo register
    
    switch (pkgHead->cmdId)
    {
    case MSG_MATCHINFO:
        return HandleMatchInfoMsg(pkgHead->GetMsgHead(), pkgHead->GetMsgLen());
    case MSG_TEST:
        return HandleTestMsg(pkgHead->GetMsgHead(), pkgHead->GetMsgLen());

      default:
        LOG_ERR("conn %d get a unknown cmd %d, will be close it", m_fd, pkgHead->cmdId);
        return false;
    }
  }

  bool HandleMatchInfoMsg(const char *data, size_t dataLen)
  {
    const MatchInfoMsg *msg = (MatchInfoMsg*)data;
    //unlikey
    if (msg->infoCnt * sizeof(MatchInfo) != dataLen)
    {
      LOG_ERR("bad matchInfo msg len error,fd:%d close it", m_fd);
      return false;
    }

    for(size_t i=0; i < msg->infoCnt; ++i)
    {
      m_owner->Match(msg->infos[i], this);
    }
    return true;
  }


  bool HandleTestMsg(const char *data, size_t dataLen)
  {
    const TestMsg *msg = (TestMsg*)data;
    printf("get msg len:%d %s\n", msg->len, msg->msg);
    return true;
  }


 private:
  using NetRecvBuf = NetPkgBuf<NetPkgHaed, _4K>;

  NetRecvBuf m_recvBuf;
  /*NetSendBuf m_sendBuf;*/

  const int m_fd = -1;
  CIdcMatcher *m_owner=nullptr;

};


/*SendMatchedInfoToReqNode(info, other);           */
/*{                                                */
/*  auto fd = info->getFd();                       */

/*  auto it = m_downConns.find(it);                */
/*  if (it == m_downConns.end())                   */
/*  {                                              */
/*    LOG_DBG("");                                 */
/*    //连接已断, TODO 记录这种情况      */
/*    return                                       */
/*  }                                              */

/*  return it->second->SendPkg(PackageInfo(other)))*/

/*}                                                */


/*bool SendPkg( const char *data, size_t dataLen)              */
/*{                                                            */
/*  //if ()                                                    */
/*  buf= getSendBuf();                                         */
/*  buf.append(data, dataLen);                                 */

/*  //if (send)                                                */
  
/*  //以及发送还是缓存??                               */
/*  //Conn.Flush                                               */
/*  //if (NowMsec > )                                          */

/*  if (-1 == NetSend(buf.GetData(), buf.GetDataLen()))        */
/*  {                                                          */
/*    LOG_ERR("send data fd faild %d, close it", fd, ErrnoStr);*/
/*    return false;                                            */
/*  }                                                          */
/*}                                                            */




class CIdcMatcher : public ListenerHandler, public EpollHandler, NoCopyable
{
 public:
  bool Init()
  {
      m_ip = "127.0.0.1";
      m_port = 3345;
      m_listenFd = Listen(m_ip, m_port);
      ASSERT_RET(m_listenFd != -1, false);

      m_epoll = new CEpoll(1024);
      ASSERT_RET(m_epoll->IsOpen(), false);
      ASSERT_RET(m_epoll->AddReadFd(m_listenFd, ListenerHandler::GetEvHandler()), false);

      //TODO RegisterNode to ZK

      return true;
  }

 public:
  //ListenerHandler cb
  virtual bool OnAcceptSuccessed(CEpoll *epoll, int fd, sockaddr_in addr, socklen_t addrlen)  override
  {
    if (m_downConns.count(fd))
    {
      LOG_ERR("fd %d already in m_downConns, shoud not occus this, close it", fd);
      return false;
    }

    auto conn = new CDownstreamConn(fd, this);
    epoll->AddReadFd(fd, EpollHandler::GetEvHandler());
    m_downConns[fd] = conn;

    LOG_INFO("accept a new conn fd:%d", fd) ;//TODO ip
    return true;
  }

  virtual void OnListenErr(CEpoll *_epoll, const int listenFd, const int err) override
  {
    //relisten TODO
    LOG_ERR("listen fd %d occus a error %s, exit process", listenFd, strerror(err));
    //TODO UnRegNodeFromZk()
    //StopProcess();
  }


 public:
  //conn cb
  virtual bool OnEpollIn(CEpoll *epoll, int fd) override
  {
    auto conn = m_downConns[fd];
    if (conn == nullptr)
    {
      LOG_INFO("can not find conn:%d, show not occus this, close it", fd);
      m_downConns.erase(fd);
      return false;
    }

    return conn->Recv();
  }

  virtual bool OnEpollOut(CEpoll *epoll, int fd) override
  {
    LOG_DBG("OnEpollOut fd %d default close it\n", fd);
    //TODO
    return false;
  }

  virtual void OnBeforeCloseFd(CEpoll *epoll, int fd) override
  {
    LOG_INFO("downstream %d will be closed", fd);
    auto it = m_downConns.find(fd);
    if (it == m_downConns.end())
      return;

    delete it->second; //upstreamConn
    m_downConns.erase(it);
  }

  bool Wait()
  {
      return m_epoll->Wait(-1);
  }



  void Match(const MatchInfo *info, CDownstreamConn *conn)
  {                                                              
      MatchTable *table = m_table[info->dir];
      auto it = table.find(info);            
      if (it == table.end())
      {
          IdcMatchInfo data(info, conn->GetFd())
          //未找到匹配，插入table等待后续匹配
          if (m_linkTable.insert_or_replace(data, 
                                            [](const IdcMatchInfo &l, const IdcMatchInfo &r) //code will be inlined by compiler
                                            { return l.time <= r.time }).second)
          {

              ++m_cnt[t][KICKEDOUT_CNT];  //淘汰了一个元素
          }
          return;
      }

      if (info->type != it->type) //匹配上了/req,rsp
      {
          if (info->ip == it->ip)
          {
              //来自同主机，已在该主机本地匹配过了,忽略
              ++LocalMatchCnt;
              return;
          }

          if (info->type == REQ)
          {
              SendMatchedInfo(conn, info->key, it->ip, it->port); //发送到req所在的节点
          }
          else
          {
              SendMatchedInfo(GetConn(it->fd), info->key, info->ip, info->port); //发送到req所在的节点
          }

          ++IdcMatchCnt;
          table->erase(it);
          return;
      }

      //五元组相同,替换掉旧的
      *it = info;
      ++m_Cnt[info-dir][SAME_CNT];
  }                                                              




  //发送到req所在的节点
  SendMatchedInfo(CDownstreamConn *conn, uint64_t key, uint32_t rspIp, uint8_t rspPort) 
  {
      if (conn == nullptr)
      {
          LOG_DBG("can not find conn");
          return ;
      }

      if (SendBuf.GetWriteableLen() < sizeof(MatchedInfo))
      {

          
          SendBufGetPkgHead
          /*SendBuf.MakePackHead(sizeof(NetPkgHead));*/

          SendBuf.Send(); //加入写监听
      }

      MatchedInfo *info = SenBuf.GetWriteableBuff();
      info->infoKey = key;
      info->rspIp = rspIp;
      info->rspPort = rspPort;
      SendBuf.Write(sizeof(MatchedInfo));
  }

 private:
  using MatchTable = MultiStageMap<uint64_t, IdcMatchInfo, LINK_TABLE_SIZE, 12>;

  CEpoll *m_epoll = nullptr;
  std::string m_ip;
  uint16_t m_port ;
  int m_listenFd = -1;

  std::unordered_map<int/*conn fd */, CDownstreamConn *> m_downConns;

  MatchTable m_table[2]; //两个方向
  TimeTrigger<CIdcMatcher> m_intervalFn;

  //统计数据
  static uint32_t m_cnt[2][CNT_SIZE]; //2 REQ + RSP 两个方向
};


int main(int argc, char *argv[])
{
    CIdcMatcher matcher;

    assert(matcher.Init());
    
    while(matcher.Wait())
    {
        printf("\n");
    }

    return 0;
}
