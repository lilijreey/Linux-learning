#!/usr/bin/ruby
#
require 'socket'



STR = "hello aaaa bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb eeeeeeeeeeeeeeeeeeeeeeee"
def tt(n)
fd = TCPSocket.new '127.0.0.1', 3345
n.times do |i|
  str1 = STR + i.to_s + "\0";
  msg = [str1.length+10, 0x9981, 1, 1, str1.length+i, str1].pack('SSCCLA*')
  puts msg
  fd.write msg

end
end
