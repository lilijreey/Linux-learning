

  bool HandleNetPkg(const NetPkgHaed *pkgHead)
  {
    switch (pkgHead->cmdId)
    {
    case MSG_MATCHINFO:
        return HandleMatchInfoMsg(pkgHead->GetMsgHead(), pkgHead->GetMsgLen());
    case MSG_TEST:
        return HandleTestMsg(pkgHead->GetMsgHead(), pkgHead->GetMsgLen());

      default:
        LOG_ERR("conn %d get a unknown cmd %d, will be close it", m_fd, pkgHead->cmdId);
        return false;
    }
  }

  bool HandleMatchInfoMsg(const char *data, size_t dataLen)
  {
    const MatchInfoMsg *msg = (MatchInfoMsg*)data;
    //unlikey
    if (sizeof(MatchInfo) % dataLen != 0)
    {
      LOG_ERR("bad matchInfo msg len error,fd:%d close it", m_fd);
      return false;
    }

    size_t infoCnt = dataLen >> sizeof(MatchInfo);

    for(size_t i=0; i < infoCnt; ++i)
    {
      m_owner->Match(msg->infos[i], this);
    }
    return true;
  }


  bool HandleTestMsg(const char *data, size_t dataLen)
  {
    const TestMsg *msg = (TestMsg*)data;
    printf("get msg len:%d %s\n", msg->len, msg->msg);
    return true;
  }








class CIdcMatcher : public ListenerHandler, public EpollHandler, NoCopyable
{
 public:
  bool Init()
  {
      m_ip = "127.0.0.1";
      m_port = 3345;
      m_listenFd = Listen(m_ip, m_port);
      ASSERT_RET(m_listenFd != -1, false);

      m_epoll = new CEpoll(1024);
      ASSERT_RET(m_epoll->IsOpen(), false);
      ASSERT_RET(m_epoll->AddReadFd(m_listenFd, ListenerHandler::GetEvHandler()), false);

      //TODO RegisterNode to ZK

      return true;
  }

 public:
  //ListenerHandler cb
  virtual bool OnAcceptSuccessed(CEpoll *epoll, int fd, sockaddr_in addr, socklen_t addrlen)  override
  {
    if (m_downConns.count(fd))
    {
      LOG_ERR("fd %d already in m_downConns, shoud not occus this, close it", fd);
      return false;
    }

    auto conn = new CDownstreamConn(fd, this);
    epoll->AddReadFd(fd, EpollHandler::GetEvHandler());
    m_downConns[fd] = conn;

    LOG_INFO("accept a new conn fd:%d", fd) ;//TODO ip
    return true;
  }

  virtual void OnListenErr(CEpoll *_epoll, const int listenFd, const int err) override
  {
    //relisten TODO
    LOG_ERR("listen fd %d occus a error %s, exit process", listenFd, strerror(err));
    //TODO UnRegNodeFromZk()
    //StopProcess();
  }


 public:
  //conn cb
  virtual bool OnEpollIn(CEpoll *epoll, int fd) override
  {
    auto conn = m_downConns[fd];
    if (conn == nullptr)
    {
      LOG_INFO("can not find conn:%d, show not occus this, close it", fd);
      m_downConns.erase(fd);
      return false;
    }

    return conn->Recv();
  }

  virtual bool OnEpollOut(CEpoll *epoll, int fd) override
  {
    LOG_DBG("OnEpollOut fd %d default close it\n", fd);

    if (not SendData(fd))
    {
      LOG_ERR("SendBuf failed fd:%d %s will be close it", strerror(errno));
      return false;
    }

    if (m_sendBuf.GetSendableLen() == 0)
    {
      return epoll->DisableOutEv(fd);
    }

    return true;
  }

  virtual void OnBeforeCloseFd(CEpoll *epoll, int fd) override
  {
    LOG_INFO("downstream %d will be closed", fd);
    auto it = m_downConns.find(fd);
    if (it == m_downConns.end())
      return;

    delete it->second; //upstreamConn
    m_downConns.erase(it);
  }

  bool Wait()
  {
      return m_epoll->Wait(-1);
  }



  void Match(const MatchInfo *info, CDownstreamConn *conn)
  {                                                              
      MatchTable *table = m_table[info->dir];
      auto it = table.find(info);            
      if (it == table.end())
      {
          IdcMatchInfo data(info, conn->GetFd())
          //未找到匹配，插入table等待后续匹配
          if (m_linkTable.insert_or_replace(data, 
                                            [](const IdcMatchInfo &l, const IdcMatchInfo &r) //code will be inlined by compiler
                                            { return l.time <= r.time }).second)
          {

              ++m_cnt[t][KICKEDOUT_CNT];  //淘汰了一个元素
          }
          return;
      }

      if (info->type == it->type) //匹配上了/req,rsp
      {
        //五元组相同,替换掉旧的
        *it = info;
        ++m_Cnt[info-dir][SAME_CNT];
        return;
      }

      //匹配上了/req,rsp
      if (info->ip == it->ip)
      {
        //来自同主机，已在该主机本地匹配过了,忽略
        ++LocalMatchCnt;
        return;
      }

      if (info->type == REQ)
      {
        SendMatchedInfo(conn, it->key, it->ip, it->port); //发送到req所在的节点
      }
      else
      {
        SendMatchedInfo(GetConn(it->fd), info->key, info->ip, info->port); //发送到req所在的节点
      }

      ++IdcMatchCnt;
      table->erase(it);
      return;

  }                                                              

  void FlushSendBuf()
  {
    //pakage data
    CNetPkgHead *pkgHead = SendBuf.GetPkgHead();
    pkgHead->len = SendBuf.GetPkgLen();
    pkgHead->magic = 3333;
    pkgHead->cmdId = CMD_MATCHED_MSG;
    SendBuf.MakeNewPkg();

    ssize_t ret = SendPkg(int fd);
    if (ret == -1)
    {
      return;
    }

    if (ret != dataLen)
    { //未发送完成，添加Out事件
      m_epoll->EnableOutEv(conn->m_fd);
    }
  }


  //用法，
  //2.写入数据
  //3.打包, 打好后调用makeNewPkg,
  //4.发送
  
  //发送到req所在的节点
  void SendMatchedInfo(CDownstreamConn *conn, uint64_t infoKey, uint32_t rspIp, uint8_t rspPort) 
  {
      if (conn == nullptr)
      {
          LOG_DBG("can not find conn");
          return ;
      }

      if (SendBuf.GetPkgLen() > _4K)
      {
        FlushSendBuf();
      }

      if (SendBuf.GetWriteableLen() < sizeof(MatchedInfo))
      {
        //已满，发送
        if (m_sendBuf->DiscardSendedData() < sizeof(MatchedInfo))
        {
          LOG_WARN("buff full can not werite data");
          return;
        }
      }

      m_sendBuf.Append(infoKey, rspIp, rspPort, dir);
  }



 private:
  using MatchTable = MultiStageMap<uint64_t, IdcMatchInfo, LINK_TABLE_SIZE, 12>;

  CEpoll *m_epoll = nullptr;
  std::string m_ip;
  uint16_t m_port ;
  int m_listenFd = -1;

  std::unordered_map<int/*conn fd */, CDownstreamConn *> m_downConns;

  MatchTable m_table[2]; //两个方向
  TimeTrigger<CIdcMatcher> m_intervalFn;

  //统计数据
  static uint32_t m_cnt[2][CNT_SIZE]; //2 REQ + RSP 两个方向
};


int main(int argc, char *argv[])
{
    CIdcMatcher matcher;

    assert(matcher.Init());
    
    while(matcher.Wait())
    {
        printf("\n");
    }

    return 0;
}
