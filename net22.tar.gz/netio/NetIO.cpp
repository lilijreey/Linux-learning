
//#include "CommUtils.h"
#include "NetIO.h"

//全部基于nonblock 模式, 水平触发

std::string CEpoll::Events2Str(const int events)
{
    std::string str;
    if (events & EPOLLERR) str += "ERR,";
    if (events & EPOLLHUP) str += "HUP,";
    if (events & EPOLLIN)  str += "IN,";
    if (events & EPOLLOUT) str += "OUT,";
    if (events & EPOLLRDHUP) str += "RDHUP,";
    if (events & EPOLLPRI) str += "PRI,";

    return str;
}


int Listen(const std::string &ip, uint16_t port, int sockopt)
{
    sockaddr_in addr;
    Bzero(addr);

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    int ret =
    inet_pton(AF_INET, ip.c_str(), &(addr.sin_addr.s_addr));
    if (ret <= 0)
    {
        LOG_ERR("parse ip %s failed %s", ip.c_str(), ret == 0 ? "Not in presentaion format " : ErrnoStr);
        return -1;
    }


    int listenFd = socket(AF_INET, SOCK_STREAM, 0);
    if (-1 == listenFd)
    {
        LOG_ERR("create socket failed %s", ErrnoStr);
        return -1;
    }

    int opt =1;
    if (-1 == setsockopt(listenFd, SOL_SOCKET,  SO_REUSEADDR | sockopt, &opt, sizeof(opt)))
    {
        LOG_ERR("setsockopt fd %d failed %s", listenFd, ErrnoStr);
        close(listenFd);
        return -1;
    }


    if (-1 == bind(listenFd, (sockaddr*)&addr, sizeof(addr)))
    {
        LOG_ERR("bind %s %d failed %s", ip.c_str(), port, ErrnoStr);
        close(listenFd);
        return -1;
    }

    if (-1 == listen(listenFd, 10))
    {
        LOG_ERR("bind %s %d failed %s", ip.c_str(), port, ErrnoStr);
        close(listenFd);
        return -1;
    }

    LOG_INFO("listen %s %d successed", ip.c_str(), port);

    return listenFd;
}

int Accept(int listenFd, sockaddr *addr, socklen_t *addrlen)
{
again:
    int ret = accept4(listenFd, addr, addrlen, SOCK_NONBLOCK);
    if (-1 == ret )
    {
        if (errno == EAGAIN || errno == EWOULDBLOCK)
            return -1;
        if (errno == EINTR)
            goto again;
        return -1;
    }

    LOG_DBG("accept new fd %d", ret);
    return ret;
}




CEpoll::CEpoll(int maxevents)
    :m_maxevents(maxevents)
{
    m_epfd = epoll_create1(0);
    if (-1 == m_epfd)
    {
        LOG_ERR("epoll_create1 failed %s", ErrnoStr);
        return;
    }
    m_events = (epoll_event*)malloc(m_maxevents * sizeof(epoll_event));
}

CEpoll::~CEpoll()
{
    for(auto p : m_watchers)
    {
        RemoveFd(p.first);
        close(p.first);// fd
    }
    m_watchers.clear();

    for(auto p : m_freeWatchers)
    {
        delete p;
    }
    m_freeWatchers.clear();

    if (IsOpen())
    {
        free(m_events);
        m_events=nullptr;
        close(m_epfd);
        m_epfd= -1;
    }
}

//RemoveFd 保证调用成功后，不会在调用之前的回调函数
//一般情况无需使用
bool CEpoll::RemoveFd(int fd)
{
    auto it = m_watchers.find(fd);
    if (it == m_watchers.end())
    {
        LOG_ERR("can not find fd %d", fd);
        return false;
    }
    //EvWatcher 对象由wait统一释放，保证在一次迭代中的EvWather对象都有效
    dev_env
    {
        it->second->oldFd = it->second->fd;
    }
    it->second->fd = -1;
    m_freeWatchers.push_back(it->second);
    m_watchers.erase(it);

    epoll_event _ev;//2.6.9 before need
    if (-1 == epoll_ctl(m_epfd, EPOLL_CTL_DEL, fd, &_ev))
    {
        LOG_ERR("epoll del fd %d failed %s", fd, ErrnoStr);
    }
    return true;
}

//bool CEpoll::IsEnableEv(int fd, int events)
//{
//  //TODO 自动事件如果处理

//  auto it = m_watchers.find(fd);
//  if (it == m_watchers.end())
//  {
//    return false;
//  }

//  return (it->second.m_events & ~events) == events);
//}

bool CEpoll::EnableEv(int fd, int enableEv)
{
  auto it = m_watchers.find(fd);
  if (it == m_watchers.end())
  {
    return false;
  }

  if ((it->second->events & enableEv) == enableEv)
  {
    return true;
  }

  int newEvents = it->second->events | enableEv;

  epoll_event ev;
  ev.events = newEvents;
  ev.data.ptr = m_watchers[fd];

  if (-1 == epoll_ctl(m_epfd, EPOLL_CTL_MOD, fd, &ev))
  {
    LOG_ERR("epoll mod fd %d ev failed %s", fd, ErrnoStr);
    return false;
  }

  //update
  it->second->events = newEvents;
  return true;
}

bool CEpoll::DisableEv(int fd, int disableEv)
{
  auto it = m_watchers.find(fd);
  if (it == m_watchers.end())
  {
    return false;
  }

  //TODO test
  if ((~(it->second->events) & disableEv) == disableEv)
  {
    return true;
  }

  int newEvents = it->second->events & (~disableEv);


  epoll_event ev;
  ev.events = newEvents;
  ev.data.ptr = m_watchers[fd];

  if (-1 == epoll_ctl(m_epfd, EPOLL_CTL_MOD, fd, &ev))
  {
    LOG_ERR("epoll mod fd %d ev failed %s", fd, ErrnoStr);
    return false;
  }

  //update
  it->second->events = newEvents;
  return true;
}

bool CEpoll::ModEv(int fd, int events)
{
  auto it = m_watchers.find(fd);
  if (it == m_watchers.end())
  {
    return false;
  }

  epoll_event ev;
  ev.events = events;
  ev.data.ptr = m_watchers[fd];

  if (-1 == epoll_ctl(m_epfd, EPOLL_CTL_MOD, fd, &ev))
  {
    LOG_ERR("epoll mod fd %d ev failed %s", fd, ErrnoStr);
    return false;
  }

  //update
  it->second->events = events;
  return true;
}

bool CEpoll::ModEvHandler(int fd, const EvHandler &cb)
{
  auto it = m_watchers.find(fd);
  if (it == m_watchers.end())
  {
    return false;
  }

  it->second->evHandler = cb;
  return true;
}

bool CEpoll::ModEv(int fd, int events, const EvHandler &cb)
{
  auto it = m_watchers.find(fd);
  if (it == m_watchers.end())
  {
    return false;
  }

  epoll_event ev;
  ev.events = events;
  ev.data.ptr = m_watchers[fd];

  if (-1 == epoll_ctl(m_epfd, EPOLL_CTL_MOD, fd, &ev))
  {
    LOG_ERR("epoll mod fd %d ev failed %s", fd, ErrnoStr);
    return false;
  }

  //update
  it->second->events = events;
  it->second->evHandler = cb;
  return true;

}

//bool CEpoll::DelEv(int fd, int events)
//{
//    if (not IsExistFd(fd))
//    {
//        return false;
//    }

//    epoll_event _ev;//2.6.9 before need
//    if (-1 == epoll_ctl(m_epfd, EPOLL_CTL_DEL, fd, &_ev))
//    {
//        LOG_ERR("epoll del fd %d failed %s", fd, ErrnoStr);
//        return false;
//    }
//    return true;
//}

bool CEpoll::AddFd(int fd, int events, const EvHandler& cb)
{
    if (IsExistFd(fd))
    {
        LOG_ERR("fd %d alreay exist", fd);
        return true;
    }

    if (IsBlockingFd(fd))
    {
        if (not SetSocketNonbockable(fd, true))
        {
            LOG_ERR("fd %d not canot set nonblocking %s", fd, ErrnoStr);
            return false;
        }
    }


    epoll_event ev;
    ev.events = events;
    EvWatcher *watcher = new EvWatcher(fd, events, cb);
    ev.data.ptr = watcher;

    if (-1 == epoll_ctl(m_epfd, EPOLL_CTL_ADD, fd, &ev))
    {
        LOG_ERR("epoll add fd %d failed %s", fd, ErrnoStr);
        return false;
    }

    m_watchers[fd] = watcher;

    LOG_DBG("add fd %d ok", fd);
    return true;
}

//不可重入
bool CEpoll::Wait(int timeout)
{
    if (m_waiting)
    {
        LOG_ERR("reenter wait");
        return true;
    }
    m_waiting = true;
    const int fds = epoll_wait(m_epfd, m_events, m_maxevents, timeout);
    //if (unlikey(fds == -1)) //XXX
    if (fds == -1)
    {
      LOG_ERR("epoll_wait faild %s", ErrnoStr);
        m_waiting = false;
        return false;
    }

    for (int i =0; i < fds; ++i)
    {
        //这里保证watcher没有被释放
        EvWatcher* watcher = (EvWatcher*)(m_events[i].data.ptr);
        //存在的几种情况:
        //1. fd,有效，EvWatcher 有效，在epoll中
        //2. fd,有效，但是之前已调用RemoveFd,
        //            RemoveFd 不会释放wathcer对象，检测fd 是否为-1
        //3. fd无效,被close,　
        const int fd = watcher->fd;
        if (fd == -1)//2
        {
            LOG_WARN("epoll handle fd %d already removed", watcher->oldFd);
            continue; //该fd 已被移除
        }
        LOG_DBG("fd %d event%s", fd, Events2Str(m_events[i].events).c_str());
        //1,3
        if (not watcher->evHandler(this, fd, m_events[i].events))
        { //close fd
            LOG_DBG("ev handle return false, close fd %d", fd);
            RemoveFd(fd);
            close(fd);
        }
    }
    
    for (auto p: m_freeWatchers) delete p;
    m_freeWatchers.clear();

    m_waiting = false;
    return true;
}

int CEpoll::TcpNonblockConnect(const std::string &ip, uint16_t port, const EvHandler &cb)
{
    sockaddr_in addr;
    Bzero(addr);

    addr.sin_family = AF_INET;
    addr.sin_port = htons(port);
    int ret =
    inet_pton(AF_INET, ip.c_str(), &(addr.sin_addr.s_addr));
    //TODO 同意通过cb 处理
    if (ret <= 0)
    {
        LOG_ERR("parse ip %s failed %s", ip.c_str(), ret == 0 ? "Not in presentaion format " : ErrnoStr);
        return -1;
    }


    int fd = socket(AF_INET, SOCK_STREAM, 0);
    if (-1 == fd)
    {
        LOG_ERR("create socket failed %s", ErrnoStr);
        return -1;
    }

    if (not SetSocketNonbockable(fd))
    {
        LOG_ERR("set fd %d nonblock failed %s", fd, ErrnoStr);
        close(fd);
        return -1;
    }

    if (-1 == connect(fd, (sockaddr*)&addr, sizeof(addr)))
    {
        if (errno == EINPROGRESS)
        {
            LOG_DBG("connect %s fd %d EINPROGRESS", ip.c_str(), fd);
            if (AddFd(fd, EPOLLOUT | EPOLLONESHOT, cb)) //once behavire
                return fd;

            close(fd);
        }
        return -1;
    }

    //success immediately
    if (not AddFd(fd, 0, cb))
    {
      LOG_ERR("fd %d connect success immediately but join epoll failed %s", fd, ErrnoStr);
      close(fd);
      return -1;
    }

    if (not cb(this, fd, EPOLLOUT))
    {
      close(fd);// TOOD CLOSE_FD
      return -1;
    }

    return fd;
}



