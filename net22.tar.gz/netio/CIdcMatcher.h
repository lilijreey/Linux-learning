/**
 * @file     CIdcMatcher.h
 *           
 *
 * 进行IDC级的匹配
 * @author   lili <lilijreey@gmail.com>
 * @date     07/01/2018 07:51:47 PM
 *
 */


#ifndef CIDCMATCHER_H_
#define CIDCMATCHER_H_

#include "NetIO.h"
#include "Utils.h"
#include "MessageDef.h"

//IdcMatcher
//LocalMatcher

//IdcMatchedInfoReceiver// 发送本机matche info 到对应的IDC 节点
//IdcMatchedInfoSender //接受上游IDC节点返回的匹配信息

//HttpInfoSender
//HttpInfoReceiver

//void HandlePkg()

//class CIdcMatcherListenr : ListenerHandler
//{
//    void Init(CEpoll *epoll, constd::string)




extern uint32_t g_NowSec;

struct IdcMatchInfo 
{
    IdcMatchInfo(MatchInfo *info, int _fd, uint32_t _ip)
        :infoKey(info->infoKey)
         ,time(g_NowSec)
         ,fd(_fd)
         ,ip(_ip)
         ,port(info->port)
         ,type(info->type)
    {}


    uint64_t infoKey=0;
    uint32_t time;
    int      fd;   //conn //这里不存指针是因为，对象之后有可能释放掉，通过fd来查找
    uint16_t ip; //监听的port //better 每个连接存下来，不在每个包中单独发送
    uint16_t port; //监听的port //better 每个连接存下来，不在每个包中单独发送
    uint16_t type;  //req/rsp
};


class CIdcMatcher;
struct CDownstreamConn : CNetConnPkgBuf<CDownstreamConn, NetPkgHaed, _4K>
{
  CDownstreamConn(int fd, CIdcMatcher *owner)
      :m_fd(fd), m_owner(owner)
  {}

  bool HandleNetPkg(const NetPkgHaed *pkgHead)
  {
    switch (pkgHead->cmdId)
    {
    case MSG_MATCHINFO:
        return HandleMatchInfoMsg(pkgHead->GetMsgHead(), pkgHead->GetMsgLen());
    case MSG_TEST:
        return HandleTestMsg(pkgHead->GetMsgHead(), pkgHead->GetMsgLen());

      default:
        LOG_ERR("conn %d get a unknown cmd %d, will be close it", m_fd, pkgHead->cmdId);
        return false;
    }
  }

  bool HandleMatchInfoMsg(const char *data, size_t dataLen)
  {
    const MatchInfoMsg *msg = (MatchInfoMsg*)data;
    //unlikey
    if (sizeof(MatchInfo) % dataLen != 0)
    {
      LOG_ERR("bad matchInfo msg len error,fd:%d close it", m_fd);
      return false;
    }

    size_t infoCnt = dataLen >> sizeof(MatchInfo);

    for(size_t i=0; i < infoCnt; ++i)
    {
      m_owner->Match(msg->infos[i], this);
    }
    return true;
  }


  bool HandleTestMsg(const char *data, size_t dataLen)
  {
    const TestMsg *msg = (TestMsg*)data;
    printf("get msg len:%d %s\n", msg->len, msg->msg);
    return true;
  }


 private:
  const int m_fd = -1;
  CIdcMatcher *m_owner=nullptr;
};

#endif
