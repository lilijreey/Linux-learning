
#ifndef MESSAGE_DEF_H_
#define MESSAGE_DEF_H_

#include <stdint.h>
enum {
    MSG_MATCHINFO,
    MSG_TEST,

    MAX_MSG_LEN = 4 << 10,

};


//定长协议,变长协议
//
struct NetPkgHaed
{
  uint16_t pkgLen; //包括包头长度
  uint16_t magic; //crc
  uint8_t  cmdId;
  char msg[0];

  bool IsVaildPkg() const
  {
    return magic == 0x9981U && pkgLen > sizeof(this) && pkgLen <= MAX_MSG_LEN;
  }

  const char *GetMsgHead() const 
  {
      return msg;
  }

  size_t GetMsgLen() const 
  {
    return pkgLen - sizeof(*this); 
  }
} __attribute__((packed)) ; 


struct MatchInfo
{
    uint64_t infoKey;
    uint8_t dir;   //in/out
    uint8_t type;  //req/rsp
    uint16_t port; //listen port

}__attribute__((packed));

struct MatchInfoMsg
{
    //uint32_t infoCnt; //MatchInfo大小固定，不写长度
    MatchInfo infos[0];

} __attribute__((packed)) ; 


struct MatchedInfo
{
    uint64_t infoKey;
    uint32_t rspIp;
    uint16_t rspPort;
    uint16_t dir;
} __attribute__((packed)) ; 


//匹配到的数据,从IDCMatcher 发送到IdcMatchReciver
struct MatchedInfoMsg
{
    uint32_t infoCnt;
    MatchedInfo infos[0];
} __attribute__((packed)) ; 

struct TestMsg
{
    uint32_t len;
    char msg[0];
} __attribute__((packed)) ; 




#endif /* ifndef SYMBOL */
