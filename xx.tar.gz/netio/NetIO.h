
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/epoll.h>
#include <string.h>
#include <string>
#include <unordered_map>
#include <vector>
#include <functional>
//#include "CommUtils.h"


#define LOG_INFO printf
#define LOG_ERR printf
#define LOG_WARN printf
#define LOG_DBG printf
#define ErrnoStr strerror(errno)

#ifdef DEV_ENV
#define dev_env if(true)
#else
#define dev_env if(false)
#endif

template <typename T>
void Bzero(T &var)
{
    bzero(&var, sizeof(T));
}

inline static bool IsNonblockingFd(int fd)
{
    int flags = fcntl(fd, F_GETFL, 0);
    if (-1 == flags)
        return false;

    return flags & O_NONBLOCK;
}

inline static bool IsBlockingFd(int fd)
{
    return not IsNonblockingFd(fd);
}


inline static
bool SetSocketNonbockable(int fd, bool isNonBlock = true)
{
    int flags = fcntl(fd, F_GETFL, 0);
    if (-1 == flags) 
    {
        return false;
    }

    flags = isNonBlock ? (flags | O_NONBLOCK) : (flags & ~O_NONBLOCK);

    return -1 != fcntl(fd, F_SETFL, flags);
}


static inline int GetSocketErr(int fd)
{
    int val;
    socklen_t len = sizeof(val);
    if (-1 == getsockopt(fd, SOL_SOCKET, SO_ERROR, &val, &len))
    {
        return -1;
    }
    return val;
}

    //if (netty_unix_socket_getOption(env, fd, SOL_SOCKET, SO_ERROR, &optval, sizeof(optval)) == -1) {

//XXX ipv4 type
int Listen(const std::string &ip, uint16_t port, int sockopt=0);
int Accept(int listenFd, sockaddr *addr=nullptr, socklen_t *addrlen=nullptr);

ssize_t NetRecv(int sockfd, void *buf, size_t len, size_t &recvLen, int flags =0);


class CEpoll
{
public:
 static inline bool IsErrEv(int events)
 {
     return events & EPOLLERR;
 }

 public:
    CEpoll(int maxevents=1024);
    ~CEpoll();

    using EvHandler = std::function<bool(CEpoll *, const int fd, const int events)> ;

    inline bool IsOpen() const
    {
        return m_epfd != -1;
    }

    inline bool IsExistFd(int fd) const
    {
        return m_watchers.find(fd) != m_watchers.end();
    }

    size_t GetAddFdCount() const 
    {
        return m_watchers.size();
    }

    bool AddFd(int fd, int event, const EvHandler &cb);
    bool RemoveFd(int fd);
    bool AddReadFd(int fd, const EvHandler &cb)  { return AddFd(fd, EPOLLIN, cb); }
    bool AddWriteFd(int fd, const EvHandler &cb) { return AddFd(fd, EPOLLOUT, cb); } 
    bool AddRWFd(int fd, const EvHandler &cb)    { return AddFd(fd, EPOLLIN | EPOLLOUT, cb); }

    //fd 必须存在
    bool ModEv(int fd, int events); //更改事件
    bool ModEvRead(int fd)  {return ModEv(fd, EPOLLIN); }
    bool ModEvWrite(int fd) {return ModEv(fd, EPOLLOUT);}
    bool ModEvRW(int fd)    {return ModEv(fd, EPOLLIN | EPOLLOUT); }

    //bool DelEv(int fd);

    bool ModEvHandler(int fd, const EvHandler &cb);//




    bool Wait(int timeout);

    //void RemoveAllFd()
    //{
    //    //TODO

    //}


    //如果立即失败返回-1,如果成功或者EINPROGRASS
    //则会返回创建的fd,这时有可能还在连接中，当没有立即失败则通过cb回调，
    //回调cb之前，fd已从epoll中移除(不管成功与否),
    int TcpNonblockConnect(const std::string &ip, uint16_t port, const EvHandler &cb);

 private:
    CEpoll(CEpoll &) = delete;
    CEpoll& operator=(CEpoll &) = delete;

    struct EvWatcher
    {
        EvWatcher(int _fd, const EvHandler &cb)
            :fd(_fd),evHandler(cb)
        {
        }
        int fd=-1;
        EvHandler evHandler;

        int oldFd;


        EvWatcher(EvWatcher&) = delete;
        EvWatcher& operator=(EvWatcher&) = delete;
    };

    int m_epfd = -1;
    int m_maxevents=1024;
    epoll_event *m_events = nullptr;
    std::unordered_map<int/*fd*/, EvWatcher*> m_watchers;
    bool m_waiting;
    std::vector<EvWatcher*> m_freeWatchers;
};


struct EvHandlerPipeline
{

    std::vector<CEpoll::EvHandler> line;
};
