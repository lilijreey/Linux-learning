
#include <stdio.h>
#include <assert.h>
#include "NetIO.h"

bool HandleEv(CEpoll *epoll, const int fd, const int events)
{
    if (CEpoll::IsErrEv(events))
    {
        int err = GetSocketErr(fd);
        printf("conn %d has a error %d %s, close it\n", fd, err, strerror(err));
        return false;
    }

    if (events & EPOLLOUT)
    {
        printf("write able todo.. \n");

    }

    if (events & EPOLLIN)
    {
        char buf[215];
        size_t recvLen =0;
        int ret = NetRecv(fd, buf, 214, recvLen);
        if (ret <= 0)
        {
            printf("socket %d close by peer ret:%d, cloes it", fd, ret);
            return false;
        }

        buf[recvLen] = '\0';
        printf("fd %d recv %lu:%s\n", fd, recvLen, buf);
    }
    return true;

}


bool sendData(CEpoll *epoll, int fd, int events)
{
    if (CEpoll::IsErrEv(events))
    {
        int err = GetSocketErr(fd);
        printf("fd %d %s\n", fd, strerror(err));
        //TODO 重连
        
        return false;
    }

    printf("fd %d send \n", fd);
    if (-1 == send(fd, "hello\n", 6, MSG_NOSIGNAL))
    {
        printf("send fd %d failed %s\n", fd, ErrnoStr);
        return false;
    }

    return true;
}

class CEpollDefaultHandler
{

};

//EvHandlerChine
bool AutoReconnect(CEpoll *epoll, int fd, int events)
{
    if (not epoll->IsErrEv(events))
    {
        if (events & EPOLLERR)
        {
            Conn *cnn = getConn();
            if (conn == nullptr)
            {
                return CLOSE_FD;
            }
            conn->HandleConnClosed();
        }

    }
}

int main(int argc, char *argv[])
{
    CEpoll epoll(23);

    //epoll.TcpAsyncConnect("127.0.0.1", 3345, AutoConnect(3,5,
    int fd = epoll.TcpNonblockConnect("127.0.0.1", 3345, 
                                 [](CEpoll *epoll, int fd, int events){
                                 if (CEpoll::IsErrEv(events))
                                 {
                                 int err = GetSocketErr(fd);
                                 printf("connect failed %s\n", strerror(err));
                                 return false;
                                 }
                                 printf("connect 127.0.0.1:3345 succcessed\n");
                                 //assert(not epoll->IsExistFd(fd));
                                 if (-1 == send(fd, "12345\n", 6, MSG_NOSIGNAL))
                                 {
                                 printf("send fd %d failedxx %s\n", fd, ErrnoStr);
                                 return false;
                                 }
                                 //assert(epoll->ModEvRead(fd, AutoReconnect));
                                 return true;
                                 //epoll->SetEvHandler(fd, )
                                 });

    printf("\n");
    if (fd != -1)
    {
        printf("connect fd %d ok\n", fd);
    }

    //int fd = TcpSocket("127.0.0.1", 3345);
    //assert(SetSocketNonbockable(fd));


    while (true)
    {
        if (not epoll.Wait(-1))
        {
            printf("epoll wait error exit");
            break;
        }

    }



    
    return 0;
}
