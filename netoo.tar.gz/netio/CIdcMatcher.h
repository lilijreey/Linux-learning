/**
 * @file     CIdcMatcher.h
 *           
 *
 * 进行IDC级的匹配
 * @author   lili <lilijreey@gmail.com>
 * @date     07/01/2018 07:51:47 PM
 *
 */

//Link

#include "NetIO.h"

//IdcMatcher
//LocalMatcher

//IdcMatchedInfoReceiver// 发送本机matche info 到对应的IDC 节点
//IdcMatchedInfoSender //接受上游IDC节点返回的匹配信息

//HttpInfoSender
//HttpInfoReceiver

//void HandlePkg()

//class CIdcMatcherListenr : ListenerHandler
//{
//    void Init(CEpoll *epoll, constd::string)

//};

#define ASSERT_RET(exp, ret) if (not exp) return ret

//下游FlowLink节点链接

template <size_t MAX_MSG_LEN>
struct NetPkgHaed_
{
  uint16_t pkglen; //包括包头长度
  uint16_t magic; //crc
  uint8_t cmdId;
  uint8_t ver; //版本号

  bool IsNotVaildPkg() const
  {
    return magic != 0x9981 && pkgLen > sizeof(this) && pkgLen <= MAX_MSG_LEN;
  }

  char *GetMsgHead() const {
    return this + sizeof(*this));
  }

  size_t GetMsgLen() const {
    return pkgLen - sizeof(*this); 
  }
}; //TODO 一字节对齐



struct MatchInfo
{
  uint64_t hash;
  uint32_t nodeIp;
  uint32_t nodePort;
};

struct MatchInfoMsg
{
  uint32_t matchInfoCnt;
  MatchInfo infos[0];

  const MatchInfo *GetMatchInfo(int index)
  {
    return infos + index;
  }
};



class NetBuffer : NoCopyable
{
  uint32_t GetReadableLen();
  uint32_t GetWritableLen();
  uint32_t GetData();
  uint32_t GetDataLen();
  bool IsReadable();
  DiscardReadedData();
  Clear();
  //Dup
  //Slice();



  uint32_t m_readPos;
  uint32_t m_writePos;
  uint32_t m_capacity; //模板参数

};

//PkgBuffer : NetBUffer 实现package, unpackage
//


struct CDownstreamConn :, NoCopyable
{
  CDownstreamConn(int fd)
      :m_fd(fd)
  {}

  bool Recv()
  {
    m_recvBuf;

    if (m_recvBuf.GetWritableLen() < MaxPkgLen)
    {
      m_recvBuf.DiscardReadedData();
    }

    size_t recvLen;
    if (NewRecv(fd, m_recvBuf.getWritPos(), m_recBuf.GetWritableLen(); recvLen) <= 0)
    {
      LOG_DBG("downstream %d recv <= 0 %d close it", fd );
      return false;
    }


    while (IsHasCompletePkg(buf))
    {
      MsgPkgHead *pkgHead = GetNextPkg(buf);
      
      if (pkgHead->IsNotVaildPkg())
      {
        LOG_ERR("fd %d get a unvalied pkg close it", fd);
        goto error;
      }

      //todo try is better?
      if (not DispatchAppMsg(MsgPkgHead))
      {
        goto error;
      }
    }

    return true;
  }

  bool DispatchAppMsg(const MsgPkgHead *pkgHead)
  {
    //todo register
    
    switch (pkgHead.cmdId)
    {
      case MATCH_INFO_MSG:
        recv_buf.ReadPosInc(pkgHead->pkglen);
        return HandleMatchInfoMsg(pkgHead->GetMsgHead(), pkgHead->GetMsgLen());

      default:
        LOG_ERR("conn %d get a unknown cmd %d, will be close it", m_fd, pkgHead.cmdId);
        return false;
    }
  }

  bool HandleMatchInfoMsg(const char *data, size_t dataLen)
  {
    MatchInfoMsg *msg = (MatchInfoMsg*)data;
    //unlikey
    if (msg->matchInfoCnt * sizeof(MatchInfo) != dataLen)
    {
      LOG_ERR("bad matchInfo msg len error, close it", m_fd);
      return false;
    }

    for(int i=0; i< msg->matchInfoCnt; ++i)
    {
      m_owner->MatchedInfo(msg->infos[i], this);
    }
  }

 private:
  const m_fd = -1;
};

void MatchedInfo(const MatchInfo *info, UpdwonStreamConn *conn)
{
  IdcMatchInfo *other = m_table.getMatcher(info);
  if (other == nullptr)
  {
    //not find matched
    return ;
  }

  table.erase(other);

  if (info->GetIp() == other->GetIp())
  {
    //same ip, matcher by local mather
    return;
  }

  UpdwonStreamConn *reqConn, *rspConn;
  if (info.type = HTTP_REQ)
  {
    reqConn = info;
    rspConn = other;
  } 
  else
  {
    reqConn = other;
    rspConn = info;
  }

  repConn->SendMatchedInfo(rspConn);
}

SendMatchedInfoToReqNode(info, other);
{
  auto fd = info->getFd();

  auto it = m_downConns.find(it);
  if (it == m_downConns.end())
  {
    LOG_DBG("");
    //连接已断, TODO 记录这种情况
    return
  }

  return it->second->SendPkg(PackageInfo(other)))

}


//NetBuff
//PkgBuff

bool SendPkg( const char *data, size_t dataLen)
{
  //if ()
  buf= getSendBuf();
  buf.append(data, dataLen);

  //if (send)
  
  //以及发送还是缓存??
  //Conn.Flush
  //if (NowMsec > )

  if (-1 == NetSend(buf.GetData(), buf.GetDataLen()))
  {
    LOG_ERR("send data fd faild %d, close it", fd, ErrnoStr);
    return false;
  }
}




class CIdcMatcher : public ListenerHandler, public EpollHandler, NoCopyable
{
 public:
  bool Init()
  {
      m_listenFd = Listen(m_ip, m_port);
      ASSERT_RET(m_listenFd != -1, false);

      m_epoll = new CEpoll(1024);
      ASSERT_RET(m_epoll->IsOpen(), false);
      ASSERT_RET(-1 != m_epoll->AddReadFd(m_listenFd, ListenerHandler::GetEvHandler()), false);

      //TODO RegisterNode to ZK

      return true;
  }

 public:
  //ListenerHandler cb
  virtual bool OnAcceptSuccessed(CEpoll *epoll, int fd, sockaddr_in addr, socklen_t addrlen)  override
  {
    if (m_downConns.count(fd))
    {
      LOG_ERR("fd %d already in m_downConns, shoud not occus this, close it");
      return false;
    }

    auto conn = new DownstreamConn(fd);
    epoll->AddReadFd(fd, EpollHandler::GetEvHandler());
    m_downConns[fd] = conn;

    LOG_INFO("accept a new conn fd:%d", fd) ;//TODO ip
    return true;
  }

  virtual void OnListenErr(CEpoll *_epoll, const int listenFd, const int err) override
  {
    //relisten TODO
    LOG_ERROR("listen fd %d occus a error %s, exit process", listenFd, StrError(err));
    //TODO UnRegNodeFromZk()
    //StopProcess();
  }


 public:
  //conn cb
  virtual bool OnEpollIn(CEpoll *epoll, int fd) override
  {
    auto conn = m_downConns[fd];
    if (conn == nullptr)
    {
      LOG_INFO("can not find conn:%d, show not occus this, close it");
      m_downConns.earse(fd);
      return false;
    }

    return conn->Recv();
  }

  virtual bool OnEpollOut(CEpoll *epoll, int fd) override
  {
    LOG_DBG("OnEpollOut fd %d default close it\n", fd);
    //TODO
    return false;
  }

  virtual void OnBeforeCloseFd(CEpoll *epoll, int fd) override
  {
    LOG_INFO("downstream %d will be closed", fd);
    auto it = m_downConns.find(fd);
    if (it == m_downConns.end())
      return;

    delete it->second; //upstreamConn
    m_downConns.earse(it);
  }

 private:
  CEpoll *m_epoll = nullptr;
  int m_listenFd = -1;
  std::string m_ip;
  uint16_t m_port ;

  std::unordered_map<int/*conn fd */, CDownstreamConn *> m_downConns;
};


int main(int argc, char *argv[])
{
    CIdcMatcher matcher;

    ASSERT(matcher.Init(), false);
    
    matcher
    return 0;
}





