
#include <unistd.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/epoll.h>
#include <string.h>
#include <string>
#include <unordered_map>
#include <vector>
#include <functional>
#include "Utils.h"

//#include "CommUtils.h"

/* @file 
 * 提供了一组基于Epoll的网络编程工具,
 * 基于正交于可组合设计，对使用场景做最小约束
 */

#define LOG_INFO printf
#define LOG_ERR printf
#define LOG_WARN printf
#define LOG_DBG printf
#define ErrnoStr strerror(errno)

#ifdef DEV_ENV
#define dev_env if(true)
#else
#define dev_env if(false)
#endif

template <typename T>
void Bzero(T &var)
{
    bzero(&var, sizeof(T));
}

inline static bool IsNonblockingFd(int fd)
{
    int flags = fcntl(fd, F_GETFL, 0);
    if (-1 == flags)
        return false;

    return flags & O_NONBLOCK;
}

inline static bool IsBlockingFd(int fd)
{
    return not IsNonblockingFd(fd);
}


inline static
bool SetSocketNonbockable(int fd, bool isNonBlock = true)
{
    int flags = fcntl(fd, F_GETFL, 0);
    if (-1 == flags) 
    {
        return false;
    }

    flags = isNonBlock ? (flags | O_NONBLOCK) : (flags & ~O_NONBLOCK);

    return -1 != fcntl(fd, F_SETFL, flags);
}


static inline int GetSocketErr(int fd)
{
    int val;
    socklen_t len = sizeof(val);
    if (-1 == getsockopt(fd, SOL_SOCKET, SO_ERROR, &val, &len))
    {
        return -1;
    }
    return val;
}

    //if (netty_unix_socket_getOption(env, fd, SOL_SOCKET, SO_ERROR, &optval, sizeof(optval)) == -1) {

//XXX ipv4 type
int Listen(const std::string &ip, uint16_t port, int sockopt=0);
int Accept(int listenFd, sockaddr *addr=nullptr, socklen_t *addrlen=nullptr);

inline static ssize_t NetRecv(int sockfd, void *buf, size_t len, size_t &recvLen, int flags = 0)
{
    recvLen = 0;
    while (recvLen < len)
    {
        ssize_t ret = ::recv(sockfd, (char*)buf+recvLen, len-recvLen, flags);
        if (ret > 0)
        {
            recvLen += ret;
        } 
        else if (ret == -1)
        {
            if (errno == EAGAIN || errno == EWOULDBLOCK)
                return 1; //表示无错误
            if (errno == EINTR)
                continue;

            return -1;
        }
        else
        {
            LOG_DBG("fd %d  recv 0 ret:%ld", sockfd, ret);
            //(ret == 0)
            return 0;
        }
    }
    return 1;
}

//发送数据，直到发送完毕或者返回错误,如果返回EAGAIN, 返回已发送长度jj
inline static
ssize_t NetSend(int sockfd, const void *data, size_t dataLen, int flags=0)
{
  size_t sendLen=0;
  while (sendLen < dataLen)
  {
    ssize_t ret = ::send(sockfd, data +sendLen, dataLen - sendLen, flags);
    switch (ret == -1)
    {
    case EAGAIN:
    case EWOULDBLOCK:
      return sendLen;
    case EINTR:
      continue;
    default:
      return -1;
    }
    sendLen += ret;
  }
  return sendLen;

}


class CEpoll
{
public:
 static inline bool IsErrEv(int events)
 {
     return events & EPOLLERR;
 }


 public:
    CEpoll(int maxevents=1024);
    ~CEpoll();

    //TODO 考虑模板类型
    using EvHandler = std::function<bool(CEpoll *, const int fd, const int events)> ;


    inline bool IsOpen() const
    {
        return m_epfd != -1;
    }

    inline bool IsExistFd(int fd) const
    {
        return m_watchers.find(fd) != m_watchers.end();
    }

    size_t GetAddFdCount() const 
    {
        return m_watchers.size();
    }

    bool AddFd(int fd, int event, const EvHandler &cb);
    bool RemoveFd(int fd);
    bool AddReadFd(int fd, const EvHandler &cb)  { return AddFd(fd, EPOLLIN, cb); }
    bool AddWriteFd(int fd, const EvHandler &cb) { return AddFd(fd, EPOLLOUT, cb); } 
    bool AddRWFd(int fd, const EvHandler &cb)    { return AddFd(fd, EPOLLIN | EPOLLOUT, cb); }

    //fd 必须存在
    bool ModEv(int fd, int events); //更改事件
    bool ModEv(int fd, int events, const EvHandler &cb); //更改事件,并且改变回调

    bool ModEvRead(int fd, const EvHandler &cb)  {return ModEv(fd, EPOLLIN, cb); }
    bool ModEvWrite(int fd) {return ModEv(fd, EPOLLOUT);}
    bool ModEvRW(int fd)    {return ModEv(fd, EPOLLIN | EPOLLOUT); }

    bool EnableEv(int fd, int events);
    bool EnableOutEv(int fd) {return EnableEv(fd, EPOLLLOUT);}

    bool DisableEv(int fd, int events);
    bool DisableOutEv(int fd) {return DisableEv(fd, EPOLLLOUT);}


    bool ModEvHandler(int fd, const EvHandler &cb);//
    static std::string Events2Str(const int events);



    bool Wait(int timeout);

    //void RemoveAllFd()
    //{
    //    //TODO

    //}

    //Socket 接口

    //立即失败返回-1
    //其他会回调cb处理，回调cb是fd,已加入epoll,但是无监听,
    //如果链接成功，则需要调用ModEv方法添加事件
    int TcpNonblockConnect(const std::string &ip, uint16_t port, const EvHandler &cb);


 private:
    CEpoll(CEpoll &) = delete;
    CEpoll& operator=(CEpoll &) = delete;

    struct EvWatcher
    {
        EvWatcher(int _fd, int _events, const EvHandler &cb)
            :fd(_fd),events(_events), evHandler(cb)
        {
        }
        int fd=-1;
        int events; //same as ev.events
        EvHandler evHandler;

        int oldFd;


        EvWatcher(EvWatcher&) = delete;
        EvWatcher& operator=(EvWatcher&) = delete;
    };

    int m_epfd = -1;
    int m_maxevents=1024;
    epoll_event *m_events = nullptr;
    bool m_waiting = false;
    std::unordered_map<int/*fd*/, EvWatcher*> m_watchers;
    std::vector<EvWatcher*> m_freeWatchers;
};


//表示该类型对象可以处理Epoll事件
class EpollHandable
{
 public:
  //返回一个可供CEpoll回调的对象
  virtual CEpoll::EvHandler GetEvHandler() = 0;
  //TODO 只是实现一个约定接口，是否可以不需要用虚函数

 public:
  virtual ~EpollHandable() {}
};



//抽象事件处理的主要的几种方式
//通用处理,一般用于业务
class EpollHandler : public EpollHandable
{
 public:
  virtual ~EpollHandler() {}
 protected:
  virtual bool OnEpollErr(CEpoll *epoll, int fd) 
  {
    int err = GetSocketErr(fd);
    LOG_DBG("OnEpollErr fd %d %s, default close it\n", fd, strerror(err));
    return false;
  }
  virtual bool OnEpollIn (CEpoll *epoll, int fd) 
  {
    LOG_DBG("OnEpollIn fd %d default close it\n", fd);
    return false;
  }
  virtual bool OnEpollOut(CEpoll *epoll, int fd)
  {
    LOG_DBG("OnEpollOut fd %d default close it\n", fd);
    return false;
  }
  virtual bool OnEpollHup(CEpoll *epoll, int fd) 
  {
    LOG_DBG("OnEpollHup fd %d default close it\n", fd);
    return false;
  }

  //在删除fd之前回调该函数，一般用于通知上游清理相关资源
  virtual void OnBeforeCloseFd(CEpoll *epoll, int fd) {
    LOG_DBG("OnBeforeCloseFd fd %d\n", fd);
  }

 public:
  bool HandleEv(CEpoll *epoll, int fd, int events)
  {
    if (events & EPOLLERR) 
    {
      OnEpollErr(epoll, fd);
      OnBeforeCloseFd(epoll, fd);
      return false;
    }

    if (events & EPOLLHUP) 
    {
      OnEpollHup(epoll, fd);
      OnBeforeCloseFd(epoll, fd);
      return false;
    }

    if (events & EPOLLIN)
    {
      if (not OnEpollIn(epoll, fd))
      {
        OnBeforeCloseFd(epoll, fd);
        return false;
      }
    }

    if (events & EPOLLOUT)
    {
      if (not OnEpollOut(epoll, fd))
      {
        OnBeforeCloseFd(epoll, fd);
        return false;
      }
    }


    return true;
  }

  virtual CEpoll::EvHandler GetEvHandler() override final
  {
    return std::bind(&EpollHandler::HandleEv, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3);
  }

};



//连接处理
class ConnectHandler : public EpollHandable
{
 public:
  virtual void OnConnectFailed(CEpoll *epoll, int fd) {}
  virtual bool OnConnectSuccessed(CEpoll *epoll, int fd) =0;

  //example code
  //virtual void OnConnectFailed(CEpoll *epoll, int fd) override
  //{
  //  int err = GetSocketErr(fd);
  //  LOG_INFO("connect ip:%s port:%d failed %s\n", m_ip.c_str(), m_port, strerror(err));
  //}

  //virtual int OnConnectSuccessed(CEpoll *epoll, int fd) override
  //{
  //  epoll->ModEv(fd, EPOLLIN, EpollHandler::GetEvHandler());
  //  return 1;
  //}

 public:
  virtual ~ConnectHandler() {}

  bool HandleEv(CEpoll *epoll, int fd, int events)
  {
    if (events & EPOLLERR || events & EPOLLHUP)
    {
      OnConnectFailed(epoll, fd);
      return false;
    }

    //dev_env {
    //  assert(events & EPOLLIN == 0);
    //}

    if (events & EPOLLOUT)
    {
      return OnConnectSuccessed(epoll, fd);
    } 

    LOG_WARN("has a unexcpt events %s", epoll->Events2Str(events).c_str());
    return false;
  }

  virtual CEpoll::EvHandler GetEvHandler() override final
  {
    return std::bind(&ConnectHandler::HandleEv, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3);
  }

};


//监听处理
class ListenerHandler : public EpollHandable
{
 public:
  //accept成功回调
  virtual bool OnAcceptSuccessed(CEpoll *epoll, int fd, sockaddr_in addr, socklen_t addrlen) = 0;

  //accept返回错误
  virtual void OnAcceptFaild(CEpoll *epoll, const int listenFd, const int err)
  {
    LOG_INFO("listen fd %d accept failed %s", listenFd, strerror(err));
  }

  //监听fd出现错误
  virtual void OnListenErr(CEpoll *epoll, const int listenFd, const int error)
  {
    LOG_ERR("listenFd %d has error will be closed", listenFd);
  }


 public:
  //~ListenerHandler() {}

  bool HandleEv(CEpoll *epoll, int listenFd, int events)
  {
    if (events & EPOLLERR || events & EPOLLHUP)
    {
      OnListenErr(epoll, listenFd, GetSocketErr(listenFd));
      return false; //close listenFd
    }

    if (events & EPOLLIN)
    {
      sockaddr_in addr;
      socklen_t addrlen;
      int newFd = accept4(listenFd, (sockaddr*)&addr, &addrlen, SOCK_NONBLOCK);
      if (-1 == newFd)
      {
        if (errno == EAGAIN || 
            errno == EWOULDBLOCK ||
            errno == EINTR)
          return true;

        OnAcceptFaild(epoll, listenFd, errno);
        return true;
      }

      return OnAcceptSuccessed(epoll, newFd, addr, addrlen);
    } 

    LOG_WARN("listenFd %d has a unexcpt events %s", listenFd, epoll->Events2Str(events).c_str());
    return true;
  }

  virtual CEpoll::EvHandler GetEvHandler() override final
  {
    return std::bind(&ListenerHandler::HandleEv, this, std::placeholders::_1, std::placeholders::_2, std::placeholders::_3);
  }

};

struct EvHandlerPipeline
{

    std::vector<CEpoll::EvHandler> line;
};





// 提供两种通用固定大小Buffer 
template <size_t BUF_SIZE>
struct NetBuf // like netty channel
{

    size_t GetCapacity() const {return BUF_SIZE;}
    uint32_t GetReadableLen() const { return m_writePos - m_readPos; }
    uint32_t GetWritableLen() const
    {
        assert(BUF_SIZE >= m_writePos);
        //DEV_ASSERT(BUF_SIZE >= m_writePos);
        return BUF_SIZE - m_writePos;
    }

    //不检验参数，请保证参数有效
    void* ReadData(size_t len) 
    { 
        void *data = m_buf + m_readPos;
        m_readPos += len;
        DEV_ASSERT(m_readPos <= m_writePos);
        return data;
    }
    const char * PeekData() const 
    {
        return m_buf + m_readPos;
    }

    void DiscardReadedData()
    {
        const uint32_t unreadLen = GetReadableLen();
        if (unreadLen != 0)
        {
          memmove(m_buf, m_buf+m_readPos, unreadLen);
        }
        LOG_DBG("fixupMemory unreadLen:%u readPos:%u writepos:%u", unreadLen, m_readPos, m_writePos);
        m_readPos = 0;
        m_writePos = unreadLen;
    }


 protected:
    //
    //   +----------+---------------+--------------+
    //   |readedData| readableData  | writeableLen |
    //   +----------+---------------+--------------+
    //             /             /                /
    //      m_readPos      m_writePos     BUF_SIZE 最大长度
    // m_readPos 永远指向一个包的头部
    //   
    uint32_t m_writePos        =0;	//可写入位置
    uint32_t m_readPos         =0;  //未读数据位置 m_readPos <= m_writePos
    char m_buf[BUF_SIZE];

};

template <typename PkgHead, size_t BUFF_SIZE, size_t PKG_HEAD_LEN=sizeof(PkgHead)>
struct  NetPkgRecvBuf: public NetBuf<BUFF_SIZE>
{
    bool Recv(int fd) //ReadFd?
    {
        if (this->GetWritableLen() < PKG_HEAD_LEN)
        {
            this->DiscardReadedData();
        }

        size_t recvLen = 0; 

        if (NetRecv(fd, this->m_buf+this->m_writePos, this->GetWritableLen(), recvLen))
        {
            this->m_writePos += recvLen;
            return true;
        }
        return false;
    }

    //如果头不足返回nullptr
    const PkgHead* PeekNextPkgHead() const
    {
        if (this->GetReadableLen() < PKG_HEAD_LEN)
        {
            return nullptr;
        }
        return (PkgHead*)(this->PeekData());
    }

    //请保证pkgLen的正确性,如果没有返回
    const PkgHead* ReadNextPkg(size_t pkgLen)
    {
        return (PkgHead*)(this->ReadData(pkgLen));
    }

    bool IsHasCompletePkg(size_t pkgLen) const
    {
        return this->GetReadableLen() >= pkgLen;
    }

};


template <typename PkgHead, size_t BUFF_SIZE, size_t PKG_HEAD_LEN=sizeof(PkgHead)>
struct NetPkgSendBuf
{

    //
    //                     m_pkgHeaderPos
    //                                 \
    //                  | sendableLen  | pkgLen| 
    //   +---+----------+--------------+-------+--------------+
    //   |   |sendedData| readableData         | writeableLen |
    //   +---+----------+--------------+-------+--------------+
    //              /                         /              /
    //      m_readPos                      m_writePos     BUF_SIZE 最大长度
    // 头部预留PKG_HEAD_LEN长度的空间,利于打包
    // m_readPos 已发送数据的下一个
    // m_pkgPos  指向正在写入的数据的包头，m_pkgPos指向的数据不会被发送 
    // m_writePos 指向下一个将写入的地址
    //   

  inline void DiscardSendedData()
  {
    const uint32_t len = GetReadableLen();
    memmove(m_buf, m_buf+m_readPos, len);
    LOG_DBG("fixupMemory pkgLen:%u readPos:%u pkg:%u, writepos:%u", len, m_readPos, m_pkgn, m_writePos);
    m_pkgPos = 0;
    m_readPos = 0;
    m_writePos = len;
  }


    uint32_t m_readPos         =0
    uint32_t m_pkgPos          =0;	
    uint32_t m_writePos        =PKG_HEAD_LEN;	//预留一个包头
    char m_buf[BUF_SIZE];

    uint32_t GetSendableLen() const
    {
      assert(m_writePos >= m_readPos);
      assert(m_pkgPos   >= m_readPos);
      return (m_pkgPos - m_readPos);
    }

    uint32_t GetWritableLen() const
    {
      assert(BUFF_SIZE >= m_writePos);
      return BUFF_SIZE - m_writePos;
    }

    uint32_t GetPkgLen() const
    {
      assert(m_writePos >= m_pkgPos);
      return m_writePos - m_pkgPos;
    }

    PkgHead *GetPkgHead()
    {
      return (PkgHead *)(m_buf + m_pkgPos);
    }

    GetData();
    GetSendableLen();

    void ReadData(size_t len);
    {
        m_readPos += len;
        DEV_ASSERT(m_readPos <= m_writePos);
        //DEV_ASSERT(m_readPos <= m_writePos);
        return data;
    }



    //Append 写入数据,支持可变参数,返回写入数据的长度
    //不检查是否越界

    inline size_t Append(const void *data, size_t dataLen)
    {
      //TODO check overbound
      memcpy(buf+pos, data, len);
      pos += dataLen;
      return dataLen;
    }

    //Append(arry)
    template <typename T>
    size_t Append(const T* a)
    {
      static_assert(std::is_pod<T>, "need POD type");
      return Append(a, sizeof(T));
    }

    //Append(3)
    template <typename T>
    void Append(T&& a)
    {
      static_assert(std::is_pod<T>, "need POD type");
      *( typename std::remove_reference<T>::type *)(buf + pos) = a;
      pos += sizeof(T);
    }

    //Append(3,54, 32L, obj) 参数需要是POD类型
    template<typename T, typename ...Args>
    void Append(T&& a, Args... args)
    {
      return Append(std::forward<T>(a)) + Append(args...);
    }

    //调用后之前的数据将允许被发送,一般在打包后调用
    //预留一个PKG_HEAD_LEN长度空间，可以使用GetPkgHead返回包头指针
    void BuildNextPkg()
    {
      assert(m_pos <= m_writePos);
      m_pos = m_writePos;
      m_writePos += PKG_HEAD_LEN;
      //TODO 调整内存布局
    }
};



  //用法，
  //2.写入数据
  //3.打包, 打好后调用makeNewPkg,
  //4.发送
  

  PkgHead * head  = buf.GetPkgHead();
  //打包
  head->cmd = xxx;
  head->len = buf.GetPkgLen();
  buf.packPkg(); //更新pkgPos 到m_writePos
  buf.Send();


MarkPkgHeader
GetPkgHeader
GetPkgLen


//struct CDownstreamConn : CTcpPkgRWder<CNetPkg, CDownstreamConn>
//                         ;

struct PkgHanderInter
{
  bool PkgHander()

}


//提供读写buff, 打包，接包，功能,配置Epoll使用
//Subclass 需要实现 //bool DispatchPkgMsg(const NetPkgHaed *pkgHead),函数，
//使用CRTP,实现编译期重载
template <typename Subclass, typename PkgHead, size_t RecvBuffSize, size_t SendBuffSize = RecvBuffSize>
struct CNetPkgRWer: NoCopyable
{
 public:

  //如果有完整包将会回调HandlePkg
  bool RecvAndParse(int sockFd)
  {
      if (not m_recvBuf.Recv(sockFd))
      {
          LOG_DBG("downstream %d recv <= 0 close it", sockFd);
          return false;
      }

      while (const PkgHead *pkgHead = m_recvBuf.PeekNextPkgHead())
      {
          if (not pkgHead->IsVaildPkg())
          {
              LOG_ERR("fd %d get a unvalied pkg close it", sockFd);
              return false;
          }

          if (not m_recvBuf.IsHasCompletePkg(pkgHead->pkgLen))
          {
              return true;
          }

          m_recvBuf.ReadNextPkg(pkgHead->pkgLen);

          if (not stataic_cast<Subclass>(*this)->HandleNetPkg(pkgHead, this))
          {
              return false;
          }
      }

      return true;
  }


  //下发成功返回true,false表示出现错误，需要关闭对象
  bool SendBuffData()
  {
    //发送给定长度数据，直到发送完毕(非阻塞),或者返回EAGIN,或者出错
    assert(m_pkgPos >= m_readPos);

    const size_t dataLen = buf.GetSendableLen()
        //ssize_t ret = NetSend(sockFd, m_buf + m_readPos, dataLen, MSG_NOSIGNAL);
        ssize_t ret = NetSend(sockFd, buf.GetData(), dataLen, MSG_NOSIGNAL);
    if (ret == -1)
    {
      LOG_ERR("conn %d send occur error :%s, will close it");
      return false;
    }
    buf.ReadData(ret);

    assert(ret <= dataLen);

    if (ret != dataLen)
    { 
      m_owner->
    }
    //每次都整理位置，可优化
    DiscardSendedData();
  }


 protected:
  using NetRecvBuf = NetPkgBuf<PkgHead, RecvBuffSize>;
  using NetSendBuf = NetPkgBuf<PkgHead, SendBuffSize>;

  NetRecvBuf m_recvBuf;
  NetSendBuf m_sendBuf;
};
